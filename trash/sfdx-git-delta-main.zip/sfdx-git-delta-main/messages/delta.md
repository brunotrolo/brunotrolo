# summary

Generate incremental package manifest and source content

# description

Use two git commit reference to generate the package corresponding to what has changed in between

# examples

- Build incremental manifest from the previous commit

<%= config.bin %> <%= command.id %> --from "origin/development" --output-dir incremental

- Build incremental manifest and source from the development branch

<%= config.bin %> <%= command.id %> --from "origin/development" --generate-delta --output-dir incremental

- Build incremental manifest from where the current branch diverged from main

<%= config.bin %> <%= command.id %> --from "main" --merge-base --output-dir incremental

# flags.to.summary

commit sha to where the diff is done

# flags.from.summary

commit sha from where the diff is done

# flags.merge-base.summary

diff from the merge base of --from and --to instead of --from itself (git three-dot semantics)

# flags.repo.summary

git repository location

# flags.output.summary

source package specific output

# flags.source.summary

source folders focus location relative to --repo-dir

# flags.source.description

You can use this flag multiple times to include different folders that contain source files. Each path should be relative to --repo-dir.

The folder can exist or not.
* If the folder exists, its contents will be processed.
* If the folder doesn't exist, it usually won't show any output—unless the folder was recently deleted and is part of a diff, in which case changes may still be picked up.

Each value must be a literal repository-relative path: wildcards (`*`, `?`, `[`), git pathspec magic (`:(...)`), absolute paths, `..` and the empty string are all rejected. Matching is rooted at the repository root, so `--source-dir force-app` does not match `nested/force-app/...`.

# flags.ignore.summary

file listing paths to explicitly ignore for any diff actions

# flags.ignore-destructive.summary

file listing paths to explicitly ignore for any destructive actions

# flags.api-version.summary

salesforce metadata API version, default to sfdx-project.json "sourceApiVersion" attribute or latest version

# flags.generate-delta.summary

generate delta files in [--output-dir] folder

# flags.ignore-whitespace.summary

ignore git diff whitespace (space, tab, eol) changes

# flags.include.summary

file listing paths to explicitly include for any diff actions

# flags.include-destructive.summary

file listing paths to explicitly include for any destructive actions

# flags.additional-metadata-registry.summary

file containing additional metadata definitions to add to the registry

# flags.changes-manifest.summary

path to a JSON file grouping changed components by kind (add, modify, delete, rename); setting this flag also enables git rename detection

# error.ParameterIsNotGitSHA

--%s is not a valid sha pointer: '%s' (If in CI/CD context, check the fetch depth is properly set)

# error.ParameterIsNotCommit

--%s must resolve to a commit: '%s' resolves to a %s. Use a commit sha, a branch, or a tag that points to a commit

# error.MergeBaseNotFound

no merge base found between --from '%s' and --to '%s' (If in CI/CD context, check the fetch depth is properly set)

# error.PathIsNotGit

'%s' is not a git repository

# error.ChangesManifestNotAFile

--changes-manifest must point to a file path, '%s' already exists and is not a regular file

# error.ChangesManifestStatFailed

--changes-manifest: cannot inspect '%s': %s

# error.SourceDirIsEmpty

--source-dir does not accept an empty value; use '.' to scope the whole repository (received: '%s')

# error.SourceDirIsAbsolute

--source-dir must be a path relative to --repo-dir, not an absolute path (received: '%s')

# error.SourceDirEscapesRepository

--source-dir does not accept '..' path segments; use a literal repository-relative path instead (received: '%s')

# error.SourceDirContainsWildcard

--source-dir does not accept wildcards (*, ?, [); repeat --source-dir once per folder, or use --include-file/--ignore-file to filter by pattern (received: '%s')

# error.SourceDirUsesPathspecMagic

--source-dir does not accept git pathspec magic (e.g. ':(exclude)', ':!'); use a literal repository-relative path instead (received: '%s')

# warning.ApiVersionDefaulted

No API version found (no --api-version flag, no sourceApiVersion in sfdx-project.json), using '%s'

# error.ApiVersionRetrievalFailed

Unable to resolve the Salesforce API version. Provide one with --api-version, or set "sourceApiVersion" in sfdx-project.json. Caused by: %s

# error.ApiVersionLookupUnusable

The appexchange org returned '%s', which is not a usable Salesforce API version

# warning.MalformedXML

could not process '%s', please ensure it is properly formatted xml in both '%s' and '%s' revision

# warning.FlowDeleted

Attempt to delete the flow '%s' via destructiveChanges.xml may not work as expected (see https://github.com/scolladon/sfdx-git-delta#handle-flow-deletion)

# warning.DigitalExperienceBundleDeletion

Deleting the DigitalExperienceBundle '%s' via destructiveChanges.xml requires the related Experience site to be deactivated first for the deployment to succeed

# warning.SourceDirMatchedNothing

No changes found under '%s' between '%s' and '%s'

# info.CommandIsRunning

Generating incremental package

# info.CommandSuccess

Success

# info.CommandFailure

Failure

# info.EncourageSponsorship

💡 Enjoying sfdx-git-delta?
Your contribution helps us provide fast support 🚀 and high quality features 🔥
Become a sponsor: https://github.com/sponsors/scolladon 💙
# warning.IgnoredMoveCheckSkipped

Could not read the file list at '%s', so %s component(s) moved into an ignored directory could not be confirmed as moves and are reported as deletions. Check that --to resolves to a readable commit.

# warning.TreeIndexUnavailable

Could not build the file tree index for '%s', so components that still exist there may be listed in destructiveChanges.xml as deleted. Check that the commit's tree objects are present locally (a partial clone created with --filter may not have them).

# warning.UndeletableComponentsOmitted

The Metadata API cannot delete '%s' components, so destructiveChanges.xml omits '%s'. Remove them from the target org manually in Setup.
