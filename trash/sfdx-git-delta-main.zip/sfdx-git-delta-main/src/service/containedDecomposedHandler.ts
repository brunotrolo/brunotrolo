'use strict'
import { join, ParsedPath, parse } from 'node:path/posix'
import { PATH_SEP } from '../constant/fsConstants.js'
import { METAFILE_SUFFIX } from '../constant/metadataConstants.js'
import type { CopyOperation, HandlerResult } from '../types/handlerResult.js'
import { CopyOperationKind } from '../types/handlerResult.js'
import type { RunContext } from '../types/runContext.js'
import { readDirs } from '../utils/fsHelper.js'
import type { MetadataElement } from '../utils/metadataElement.js'
import StandardHandler from './standardHandler.js'

// In .../PSName/childTypeDir/file, the PS name is 3 segments before the end
const PS_DIR_OFFSET_IN_SUBDIR = 3
// In .../PSName/file, the PS name is 2 segments before the end
const PS_DIR_OFFSET_FLAT = 2

export default class ContainedDecomposedHandler extends StandardHandler {
  protected holderFolder: ParsedPath | undefined

  constructor(changeType: string, element: MetadataElement, ctx: RunContext) {
    super(changeType, element, ctx)
    this._setholderFolder()
  }

  public override async collectAddition(): Promise<HandlerResult> {
    const result = await super.collectAddition()
    if (!this._isDecomposedFormat()) return result
    const copies = [...result.copies]
    this._collectDirCopy(copies, this._getHolderPath())
    return { ...result, copies }
  }

  public override async collectDeletion(): Promise<HandlerResult> {
    if (!this._isDecomposedFormat()) {
      return await super.collectDeletion()
    }
    if (await this._hasRelatedContent()) {
      return await this.collectModification()
    }
    return await super.collectDeletion()
  }

  protected _setholderFolder() {
    if (!this._isDecomposedFormat()) {
      this.holderFolder = parse(
        this.element.basePath
          .replace(METAFILE_SUFFIX, '')
          .replace(`.${this.element.type.suffix}`, '')
      )
      return
    }
    const isFlat = this.element.componentName === this.element.parentFolder
    const offset = isFlat ? PS_DIR_OFFSET_FLAT : PS_DIR_OFFSET_IN_SUBDIR
    const psDirIndex = this.element.parts.length - offset
    this.holderFolder = parse(
      this.element.parts.slice(0, psDirIndex + 1).join(PATH_SEP)
    )
  }

  protected _isDecomposedFormat() {
    const parsed = parse(this.element.basePath)
    return (
      !parsed.base.includes(`.${this.element.type.suffix}`) ||
      parsed.dir.split(PATH_SEP).pop() === parsed.name
    )
  }

  protected _collectDirCopy(copies: CopyOperation[], path: string): void {
    if (!this._shouldCollectCopies()) return
    copies.push({
      kind: CopyOperationKind.GitDirCopy,
      path,
      revision: this.config.to,
    })
  }

  protected _getHolderPath(): string {
    return join(this.holderFolder!.dir, this.holderFolder!.base)
  }

  protected async _hasRelatedContent(): Promise<boolean> {
    const files = await readDirs(this._getHolderPath(), this.ctx)
    return files.length > 0
  }

  protected override _getElementName() {
    return this.holderFolder!.base
  }

  protected override _isProcessable() {
    return true
  }
}
