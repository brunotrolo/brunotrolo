'use strict'
import { join, parse } from 'node:path/posix'

import { ADDITION, DELETION, MODIFICATION } from '../constant/gitConstants.js'
import { METAFILE_SUFFIX } from '../constant/metadataConstants.js'
import type { Config } from '../types/config.js'
import type {
  AddKind,
  CopyOperation,
  HandlerResult,
} from '../types/handlerResult.js'
import {
  ChangeKind,
  CopyOperationKind,
  emptyResult,
  ManifestTarget,
} from '../types/handlerResult.js'
import type { RunContext } from '../types/runContext.js'
import { getErrorMessage, wrapError } from '../utils/errorUtils.js'
import { log } from '../utils/LoggingDecorator.js'
import { Logger, lazy } from '../utils/LoggingService.js'
import type { MetadataElement } from '../utils/metadataElement.js'

const CHANGE_KIND_BY_GIT_TYPE: Readonly<Record<string, AddKind>> = {
  [ADDITION]: ChangeKind.Add,
  [MODIFICATION]: ChangeKind.Modify,
  [DELETION]: ChangeKind.Delete,
}

/**
 * Strategy pattern base for metadata type handlers.
 * Each Salesforce metadata type may need unique diff-collection behavior
 * (e.g. custom element naming, parent object detection, deletion warnings).
 * Subclasses override specific hooks (_getElementName, _isProcessable,
 * collectAddition, collectDeletion, etc.) — even thin subclasses that override
 * a single method justify their existence because they are selected at runtime
 * by TypeHandlerFactory based on metadata type definitions.
 */
export default class StandardHandler {
  constructor(
    protected readonly changeType: string,
    protected readonly element: MetadataElement,
    protected readonly ctx: RunContext
  ) {}

  protected get config(): Config {
    return this.ctx.config
  }

  @log
  public async collect(): Promise<HandlerResult> {
    if (!this._isProcessable()) {
      return emptyResult()
    }
    try {
      switch (this.changeType) {
        case ADDITION:
          return await this.collectAddition()
        case DELETION:
          return await this.collectDeletion()
        case MODIFICATION:
          return await this.collectModification()
        default:
          return emptyResult()
      }
    } catch (error) {
      const message = `${this.element.basePath}: ${getErrorMessage(error)}`
      // Stryker disable CallExpression -- equivalent: removing either log call entirely is unobservable, because this file's tests mock LoggingService and assert on the wrapped warning in result.warnings via wrapError; asserting the emission itself would couple them to logging plumbing, which this project deliberately avoids
      // Stryker disable next-line StringLiteral -- equivalent: lazy log content is observability only; tests assert on the wrapped warning message in result.warnings via wrapError, not on the lazy log line
      Logger.warn(lazy`${message}`)
      Logger.debug(
        // Stryker disable next-line StringLiteral,ArrowFunction -- equivalent: same as above, debug log is observability only
        lazy`${this.constructor.name}.collect: ${this.changeType} ${this.element.type.xmlName} '${this.element.basePath}' failed: ${() => getErrorMessage(error)}`
      )
      // Stryker restore CallExpression
      return { elements: [], copies: [], warnings: [wrapError(message, error)] }
    }
  }

  public async collectAddition(): Promise<HandlerResult> {
    const copies: CopyOperation[] = []
    this._collectCopyWithMetaFile(copies, this.element.basePath)
    return {
      elements: [this._collectManifestElement(ManifestTarget.Package)],
      copies,
      warnings: [],
    }
  }

  public async collectDeletion(): Promise<HandlerResult> {
    return {
      elements: [
        this._collectManifestElement(ManifestTarget.DestructiveChanges),
      ],
      copies: [],
      warnings: [],
    }
  }

  public async collectModification(): Promise<HandlerResult> {
    return await this.collectAddition()
  }

  protected _getElementName() {
    return this.element.componentName
  }

  // Public accessor used by the rename resolver — lets main.ts map a rename
  // path pair back to (type, member) without running collect() side-effects.
  public getElementDescriptor(): { type: string; member: string } {
    return {
      type: this.element.type.xmlName!,
      member: this._getElementName(),
    }
  }

  protected _collectManifestElement(target: ManifestTarget) {
    return {
      target,
      ...this.getElementDescriptor(),
      changeKind: this._getChangeKind(),
    }
  }

  protected _getChangeKind(): AddKind {
    // collect()'s switch guarantees changeType is ADDITION | MODIFICATION |
    // DELETION before _collectManifestElement runs, so the lookup always hits.
    return CHANGE_KIND_BY_GIT_TYPE[this.changeType]!
  }

  protected _collectCopyWithMetaFile(
    copies: CopyOperation[],
    src: string
  ): void {
    if (this._delegateFileCopy()) {
      this._collectCopy(copies, src)
      if (this._shouldCopyMetaFile(src)) {
        this._collectCopy(copies, this._getMetaTypeFilePath(src))
      }
    }
  }

  protected _collectCopy(copies: CopyOperation[], path: string): void {
    if (!this._shouldCollectCopies()) return
    copies.push({
      kind: CopyOperationKind.GitCopy,
      path,
      revision: this.config.to,
    })
  }

  protected _shouldCollectCopies(): boolean {
    return this.config.generateDelta
  }

  protected _getMetaTypeFilePath(path: string) {
    const parsedPath = parse(path)
    return join(
      parsedPath.dir,
      `${parsedPath.name}.${this.element.type.suffix}${METAFILE_SUFFIX}`
    )
  }

  protected _shouldCopyMetaFile(path: string): boolean {
    return (
      this.element.type.metaFile === true &&
      !`${path}`.endsWith(METAFILE_SUFFIX)
    )
  }

  protected _isProcessable() {
    return this.element.type.suffix === this.element.extension
  }

  protected _delegateFileCopy() {
    return true
  }

  protected _parentFolderIsNotTheType() {
    return this.element.parentFolder !== this.element.type.directoryName
  }

  public toString() {
    return `${this.constructor.name}: ${this.changeType} -> ${this.element.basePath}`
  }
}
