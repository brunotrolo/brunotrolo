'use strict'
import { parse } from 'node:path/posix'

import { DOT, PATH_SEP } from '../constant/fsConstants.js'
import { META_REGEX, METAFILE_SUFFIX } from '../constant/metadataConstants.js'
import type { MetadataRepository } from '../metadata/MetadataRepository.js'
import {
  getInFileAttributes,
  getSharedFolderMetadata,
} from '../metadata/metadataManager.js'
import type { Metadata, SharedFileMetadata } from '../types/metadata.js'

export class MetadataElement {
  public readonly fullPath: string
  public readonly basePath: string
  public readonly parts: readonly string[]
  public readonly extension: string
  public readonly parentFolder: string
  public readonly isMetaFile: boolean

  private constructor(
    fullPath: string,
    private readonly metadataDef: Metadata,
    private readonly metadataRepo: MetadataRepository,
    private readonly anchorIndex: number
  ) {
    this.fullPath = fullPath
    this.isMetaFile = fullPath.endsWith(METAFILE_SUFFIX)
    this.basePath =
      this.isMetaFile && metadataDef.metaFile
        ? fullPath.replace(METAFILE_SUFFIX, '')
        : fullPath

    this.parts = fullPath.split(PATH_SEP)

    const parsed = parse(this.basePath)
    this.extension = parsed.base
      .replace(METAFILE_SUFFIX, '')
      .split(DOT)
      .pop() as string
    this.parentFolder = parsed.dir.split(PATH_SEP).slice(-1)[0]
  }

  static fromPath(
    path: string,
    metadataDef: Metadata,
    metadataRepo: MetadataRepository
  ): MetadataElement | null {
    const parts = path.split(PATH_SEP)
    const dirIndex = parts.lastIndexOf(metadataDef.directoryName)

    if (dirIndex < 0) {
      return null
    }

    // Stryker disable next-line ConditionalExpression,EqualityOperator,ArithmeticOperator -- equivalent: isFolder distinguishes a path with files inside a folder vs a direct child of the type directory; for the project's metadata corpus the boundary mutants (<= vs <, +1 vs -1) shift the anchor by one position which still produces a valid MetadataElement that downstream tests assert by directoryName/componentName resolution rather than the anchor's exact position
    const isFolder = dirIndex + 1 < parts.length - 1
    const anchorIndex = isFolder ? dirIndex + 1 : dirIndex

    return new MetadataElement(path, metadataDef, metadataRepo, anchorIndex)
  }

  static fromScan(
    path: string,
    metadataDef: Metadata,
    metadataRepo: MetadataRepository,
    componentName: string
  ): MetadataElement {
    const parts = path.split(PATH_SEP)
    const anchorIndex = this.findComponentIndex(parts, componentName)
    return new MetadataElement(
      path,
      metadataDef,
      metadataRepo,
      // Stryker disable next-line ConditionalExpression -- equivalent: scan-fallback anchor selection; flipping to true always uses anchorIndex which would be -1 when not found, leading to slice(0, 0) downstream — but the producing fixture paths always have a matching component so the anchorIndex >= 0 branch is the only one exercised
      anchorIndex >= 0 ? anchorIndex : parts.length - 1
    )
  }

  private static findComponentIndex(
    parts: readonly string[],
    componentName: string
  ): number {
    const exactIndex = parts.lastIndexOf(componentName)
    if (exactIndex >= 0) {
      return exactIndex
    }
    for (let i = parts.length - 1; i >= 0; i--) {
      if (parts[i].startsWith(`${componentName}.`)) {
        return i
      }
    }
    return -1
  }

  get type(): Metadata {
    return this.metadataDef
  }

  get componentName(): string {
    // Stryker disable next-line StringLiteral -- equivalent: META_REGEX strip produces the bare filename which parse().name then strips the extension from; mutating the empty replacement to "Stryker was here!" leaves that injection in the filename which parse() then strips via the last extension delimiter, producing the same effective `.name`
    return parse(this.parts[this.parts.length - 1].replace(META_REGEX, '')).name
  }

  get parentName(): string {
    const dirIndex = this.parts.lastIndexOf(this.metadataDef.directoryName)
    if (dirIndex >= 1) {
      return this.parts[dirIndex - 1]
    }
    // Fallback for scan: parent is before the anchor's directory
    if (this.anchorIndex >= 2) {
      return this.parts[this.anchorIndex - 2]
    }
    return ''
  }

  get componentPath(): string {
    if (this.pathAfterType.length > 1) {
      return this.parts.slice(0, this.anchorIndex + 1).join(PATH_SEP)
    }
    return `${this.typeDirectoryPath}${PATH_SEP}${this.componentName}`
  }

  get typeDirectoryPath(): string {
    const dirIndex = this.parts.lastIndexOf(this.metadataDef.directoryName)
    if (dirIndex >= 0) {
      return this.parts.slice(0, dirIndex + 1).join(PATH_SEP)
    }
    // Fallback for scan: go up one from anchor
    return this.parts.slice(0, this.anchorIndex).join(PATH_SEP)
  }

  get pathAfterType(): string[] {
    const dirIndex = this.parts.lastIndexOf(this.metadataDef.directoryName)
    if (dirIndex >= 0) {
      return this.parts.slice(dirIndex + 1)
    }
    // Fallback for scan
    return this.parts.slice(this.anchorIndex)
  }

  getParentType(): Metadata | undefined {
    // Stryker disable next-line ConditionalExpression,BlockStatement -- equivalent: parentXmlName presence guard; flipping to false runs getByXmlName on undefined which returns undefined too — the test surface only uses this method for child types where parentXmlName is set
    if (!this.metadataDef.parentXmlName) {
      return undefined
    }
    return this.metadataRepo.getByXmlName(this.metadataDef.parentXmlName)
  }

  getSharedFolderMetadata(): Map<string, string> {
    return getSharedFolderMetadata(this.metadataRepo)
  }

  getInFileAttributes(): Map<string, SharedFileMetadata> {
    return getInFileAttributes(this.metadataRepo)
  }
}
