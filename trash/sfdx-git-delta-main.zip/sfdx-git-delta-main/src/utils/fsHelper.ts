'use strict'
import { join } from 'node:path/posix'

import GitAdapter from '../adapter/GitAdapter.js'
import type { Config } from '../types/config.js'
import type { FileGitRef } from '../types/git.js'
import type { RunContext } from '../types/runContext.js'

import { getErrorMessage } from './errorUtils.js'
import { outputFile } from './fsUtils.js'
import { buildIgnoreHelper } from './ignoreHelper.js'
import { Logger, lazy } from './LoggingService.js'

const writtenFiles = new Set<string>()

export const resetWrittenFiles = (): void => {
  writtenFiles.clear()
}

export const readPathFromGit = async (forRef: FileGitRef, config: Config) => {
  let utf8Data = ''
  try {
    const gitAdapter = GitAdapter.getInstance(config)
    utf8Data = await gitAdapter.getStringContent(forRef)
  } catch (error) {
    Logger.debug(
      // Stryker disable next-line StringLiteral,ArrowFunction -- equivalent: log content is observability only; tests assert on the empty-string return
      lazy`readPathFromGit failed for ${forRef.path}: ${() => getErrorMessage(error)}`
    )
  }
  return utf8Data
}

// Both read the run-owned tree reader for `config.to` — supplied by the
// caller (ultimately main.ts) rather than rebuilt here, so there is no
// scope for this lookup to disagree with whatever scope the index was
// actually built under. A revision nobody built an index for (or an index
// build that failed) degrades to false/[] rather than indexing lazily.
export const pathExists = async (
  path: string,
  ctx: RunContext
): Promise<boolean> => ctx.trees.pathExists(ctx.config.to, path)

export const readDirs = async (
  paths: string | string[],
  ctx: RunContext
): Promise<string[]> => ctx.trees.filesUnder(ctx.config.to, paths)

export const grepContentUnder = async (
  pattern: string,
  path: string | string[],
  config: Config
): Promise<string[]> => {
  const gitAdapter = GitAdapter.getInstance(config)
  return await gitAdapter.grepUnderPaths(pattern, path, config.to)
}

export const grepContentMatching = async (
  pattern: string,
  pathspecs: string | string[],
  config: Config
): Promise<string[]> => {
  const gitAdapter = GitAdapter.getInstance(config)
  return await gitAdapter.grepMatchingPathspecs(pattern, pathspecs, config.to)
}

export const contentIncludes = async (
  pattern: string,
  path: string,
  config: Config
): Promise<boolean> => {
  const results = await grepContentUnder(pattern, path, config)
  return results.length > 0
}

export const writeFile = async (
  path: string,
  content: string,
  config: Config
) => {
  if (writtenFiles.has(path)) {
    return
  }
  writtenFiles.add(path)

  const ignoreHelper = await buildIgnoreHelper(config)
  if (ignoreHelper.globalIgnore.ignores(path)) {
    return
  }
  await outputFile(join(config.output, path), content)
}
