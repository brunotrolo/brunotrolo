'use strict'
import {
  getErrorMessage,
  RepositoryRefusalError,
  SgdError,
} from '../utils/errorUtils.js'
import { sanitizeForMessage } from '../utils/messageSanitizer.js'

// Raw tsgit surfaces this module narrows away from GitAdapter's
// user-surfacing methods: a bad ref/oid rejects with `TsgitError` whose
// `data.code` is 'OBJECT_NOT_FOUND' and whose message is prefixed
// `OBJECT_NOT_FOUND:`; a repository tsgit refuses to open at all rejects
// with one of the codes in REFUSAL_MESSAGES below, carried the same way.
// Neither raw shape is release-compatible. tsgit never sets a top-level
// `error.code` — every code lives under `error.data.code`.
const OBJECT_NOT_FOUND_CODE = 'OBJECT_NOT_FOUND'
const OBJECT_NOT_FOUND_PREFIX = `${OBJECT_NOT_FOUND_CODE}:`

const NOT_A_REPOSITORY_CODE = 'NOT_A_REPOSITORY'
const REPOSITORY_FORMAT_VERSION_UNSUPPORTED_CODE =
  'REPOSITORY_FORMAT_VERSION_UNSUPPORTED'
const REPOSITORY_EXTENSIONS_UNSUPPORTED_CODE =
  'REPOSITORY_EXTENSIONS_UNSUPPORTED'
const REPOSITORY_EXTENSION_UNSUPPORTED_CODE = 'REPOSITORY_EXTENSION_UNSUPPORTED'

type TsgitDataError = { data?: { code?: unknown } } | null | undefined

const dataCodeOf = (error: unknown): unknown =>
  (error as TsgitDataError)?.data?.code

const isObjectNotFound = (error: unknown, message: string): boolean =>
  dataCodeOf(error) === OBJECT_NOT_FOUND_CODE ||
  message.startsWith(OBJECT_NOT_FOUND_PREFIX)

// tsgit renders every repository path down to its basename, so a mapped
// message has to be rebuilt from the path sgd itself opened. One sentence
// per condition, not per code: the three format refusals are not separately
// actionable — the user's move is the same for all three. The path is
// untrusted (it can come straight from --repo-dir), so it is sanitized
// here the same way ConfigValidator sanitizes error.PathIsNotGit's — that
// shared transformation is what keeps the two renderings byte-identical,
// which is what lets validateConfig's `new Set(errors)` collapse a
// same-repository refusal reported through both paths into one sentence.
const notARepository = (repoPath: string) =>
  `'${sanitizeForMessage(repoPath)}' is not a git repository`
const unreadableFormat = (repoPath: string) =>
  `'${sanitizeForMessage(repoPath)}' uses a repository format this version of sgd cannot read`

const REFUSAL_MESSAGES: ReadonlyMap<string, (repoPath: string) => string> =
  new Map([
    [NOT_A_REPOSITORY_CODE, notARepository],
    [REPOSITORY_FORMAT_VERSION_UNSUPPORTED_CODE, unreadableFormat],
    [REPOSITORY_EXTENSIONS_UNSUPPORTED_CODE, unreadableFormat],
    [REPOSITORY_EXTENSION_UNSUPPORTED_CODE, unreadableFormat],
  ])

const refusalMessageFor = (
  error: unknown,
  message: string
): ((repoPath: string) => string) | undefined => {
  for (const [code, render] of REFUSAL_MESSAGES) {
    if (dataCodeOf(error) === code || message.startsWith(`${code}:`)) {
      return render
    }
  }
  return undefined
}

/**
 * Normalizes a raw tsgit rejection into a release-compatible Error. Pure —
 * no I/O, never throws itself, always returns an Error for the caller to
 * rethrow — sgd's own `SgdError` instances come back by identity. `context`
 * identifies the operation (a ref, an oid, a range) and is interpolated into
 * object-lookup messages; `repoPath` identifies the repository and is
 * interpolated into repository-refusal messages instead, since tsgit
 * renders those down to a bare basename.
 */
export const mapTsgitError = (
  error: unknown,
  context: string,
  repoPath: string
): Error => {
  // sgd's own typed errors are already release-shaped; only raw tsgit
  // rejections need rewriting. Without this, a NotACommitError raised inside
  // an adapter method would leave it as a generic `git operation failed: …`
  // and ConfigValidator could not tell a non-commit from any other failure.
  if (error instanceof SgdError) return error
  const message = getErrorMessage(error)
  if (isObjectNotFound(error, message)) {
    return new Error(`${context}: not a valid git revision`)
  }
  const renderRefusal = refusalMessageFor(error, message)
  if (renderRefusal) {
    return new RepositoryRefusalError(renderRefusal(repoPath))
  }
  return new Error(`git operation failed: ${message}`)
}
