'use strict'
import { beforeAll, beforeEach, describe, expect, it, vi } from 'vitest'

import {
  createTreeReader,
  type TreeReader,
} from '../../../../src/adapter/treeReader'
import { MetadataRepository } from '../../../../src/metadata/MetadataRepository'
import { getDefinition } from '../../../../src/metadata/metadataManager'
import IncludeProcessor from '../../../../src/post-processor/includeProcessor'
import DiffLineInterpreter from '../../../../src/service/diffLineInterpreter'
import type { Config } from '../../../../src/types/config'
import {
  ChangeKind,
  CopyOperationKind,
  emptyResult,
  type HandlerResult,
  ManifestTarget,
} from '../../../../src/types/handlerResult'
import ChangeSet from '../../../../src/utils/changeSet'
import {
  buildIncludeHelper,
  IgnoreHelper,
} from '../../../../src/utils/ignoreHelper'
import { elementsOf } from '../../../__utils__/handlerResultView'
import { getConfig, getContext } from '../../../__utils__/testWork'

const { mockProcess, mockFilesUnder, mockGetFirstCommitRef } = vi.hoisted(
  () => ({
    // Matches DiffLineInterpreter.process's real signature — the mock must
    // accept the (lines, revisions?) it is actually called with so calls[]
    // captures the real argument shape, not an empty tuple.
    mockProcess:
      vi.fn<
        (
          lines: Iterable<string> | AsyncIterable<string>,
          revisions?: { from: string; to: string }
        ) => Promise<HandlerResult>
      >(),
    mockFilesUnder: vi.fn(),
    mockGetFirstCommitRef: vi.fn<() => Promise<string>>(),
  })
)

vi.mock('../../../../src/service/diffLineInterpreter', () => {
  return {
    default: vi.fn().mockImplementation(function () {
      return {
        process: mockProcess,
      }
    }),
  }
})

vi.mock('../../../../src/adapter/GitAdapter', () => ({
  default: {
    getInstance: vi.fn(() => ({
      getFirstCommitRef: mockGetFirstCommitRef,
    })),
  },
}))

vi.mock('../../../../src/utils/ignoreHelper')
const mockedBuildIncludeHelper = vi.mocked(buildIncludeHelper)

const mockKeep = vi.fn()
mockedBuildIncludeHelper.mockResolvedValue({
  keep: mockKeep,
} as unknown as IgnoreHelper)

// filesUnder moved off GitAdapter onto the run-owned TreeReader —
// IncludeProcessor reads it straight off `this.ctx.trees`.
const treeReader = {
  pathExists: vi.fn(),
  filesUnder: mockFilesUnder,
  children: vi.fn(),
} as unknown as TreeReader

describe('IncludeProcessor', () => {
  let config: Config
  let metadata: MetadataRepository

  beforeAll(async () => {
    metadata = await getDefinition({})
  })

  const includedManifest = {
    target: ManifestTarget.Package,
    type: 'ApexClass',
    member: 'Included',
    changeKind: ChangeKind.Add as ChangeKind.Add,
  }
  const includedCopy = {
    kind: CopyOperationKind.GitCopy as const,
    path: 'src/included.cls',
    revision: 'HEAD',
  }

  beforeEach(() => {
    config = getConfig()
    vi.clearAllMocks()
    mockProcess.mockResolvedValue({
      elements: [includedManifest],
      copies: [includedCopy],
      warnings: [],
    })
  })

  describe('process', () => {
    it('Given IncludeProcessor, When process is called, Then it is a no-op', async () => {
      // Arrange
      const sut = new IncludeProcessor(
        getContext({ config, metadata, trees: treeReader })
      )

      // Act & Assert
      await expect(sut.process(new ChangeSet())).resolves.toEqual({
        warnings: [],
      })
    })
  })

  describe('when no include is configured', () => {
    it('does not process include', async () => {
      // Arrange
      const sut = new IncludeProcessor(
        getContext({ config, metadata, trees: treeReader })
      )

      // Act
      const result = await sut.transformAndCollect(new ChangeSet())

      // Assert
      expect(elementsOf(result)).toEqual([])
      expect(mockedBuildIncludeHelper).not.toHaveBeenCalled()
    })
  })

  describe('when include is configured but the revision has no built tree index', () => {
    it('Then gathers no include lines (degrades to empty, not a throw)', async () => {
      // Arrange
      config.include = '.sgdinclude'
      const unbuiltTreeReader = createTreeReader(new Map())
      const sut = new IncludeProcessor(
        getContext({ config, metadata, trees: unbuiltTreeReader })
      )

      // Act
      const result = await sut.transformAndCollect(new ChangeSet())

      // Assert
      expect(result).toEqual(emptyResult())
      expect(mockProcess).not.toHaveBeenCalled()
    })
  })

  describe('when include is configured', () => {
    beforeAll(() => {
      mockFilesUnder.mockImplementation(() => ['test'])
    })

    describe('when no file matches the patterns', () => {
      beforeEach(() => {
        mockKeep.mockReturnValue(true)
      })
      it('Then returns an empty result', async () => {
        // Arrange
        config.include = '.sgdinclude'
        const sut = new IncludeProcessor(
          getContext({ config, metadata, trees: treeReader })
        )

        // Act
        const result = await sut.transformAndCollect(new ChangeSet())

        // Assert
        expect(result).toEqual(emptyResult())
      })

      it('Then does not call DiffLineInterpreter.process (kills L70 ConditionalExpression false)', async () => {
        // Arrange — keep returns true for all lines, so includeLines map is empty
        config.include = '.sgdinclude'
        const sut = new IncludeProcessor(
          getContext({ config, metadata, trees: treeReader })
        )

        // Act
        await sut.transformAndCollect(new ChangeSet())

        // Assert — emptyResult path taken, process never called
        expect(mockProcess).not.toHaveBeenCalled()
      })
    })

    describe('when file matches the patterns', () => {
      beforeEach(() => {
        mockKeep.mockReturnValue(false)
      })
      it('Then aggregates the processed manifest and copy into the result', async () => {
        // Arrange — from/to must differ, or asserting filesUnder was called
        // with config.to cannot tell that apart from config.from.
        config.include = '.sgdinclude'
        config.from = 'from-sha'
        config.to = 'to-sha'
        const sut = new IncludeProcessor(
          getContext({ config, metadata, trees: treeReader })
        )

        // Act
        const result = await sut.transformAndCollect(new ChangeSet())

        // Assert
        expect(elementsOf(result).length).toBeGreaterThan(0)
        expect(elementsOf(result)).toContainEqual(includedManifest)
        expect(result.copies).toContainEqual(includedCopy)
        expect(mockFilesUnder).toHaveBeenCalledWith('to-sha', config.source)
      })
    })

    describe('when multiple files match the patterns', () => {
      beforeEach(() => {
        mockFilesUnder.mockImplementation(() => ['test1', 'test2'])
        mockKeep.mockReturnValue(false)
      })
      it('Then aggregates at least one manifest entry per matched file', async () => {
        // Arrange
        config.include = '.sgdinclude'
        const sut = new IncludeProcessor(
          getContext({ config, metadata, trees: treeReader })
        )
        const baseline = elementsOf(
          await new IncludeProcessor(
            getContext({ config: getConfig(), metadata, trees: treeReader })
          ).transformAndCollect(new ChangeSet())
        ).length

        // Act
        const result = await sut.transformAndCollect(new ChangeSet())

        // Assert
        expect(elementsOf(result).length).toBeGreaterThan(baseline)
        expect(elementsOf(result)).toContainEqual(includedManifest)
      })
    })

    describe('when only additions match the patterns', () => {
      beforeEach(() => {
        mockFilesUnder.mockImplementation(() => ['test'])
        // Keep deletion lines, reject addition lines
        mockKeep.mockImplementation(((line: string) =>
          line.startsWith('D')) as typeof mockKeep)
      })
      it('Then collects include manifest entries (additions only)', async () => {
        // Arrange
        config.include = '.sgdinclude'
        const sut = new IncludeProcessor(
          getContext({ config, metadata, trees: treeReader })
        )

        // Act
        const result = await sut.transformAndCollect(new ChangeSet())

        // Assert
        expect(elementsOf(result)).toContainEqual(includedManifest)
      })

      it('Then calls process with ADDITION lines only, not DELETION (kills L78 ConditionalExpression false)', async () => {
        // Arrange
        config.include = '.sgdinclude'
        const sut = new IncludeProcessor(
          getContext({ config, metadata, trees: treeReader })
        )

        // Act
        await sut.transformAndCollect(new ChangeSet())

        // Assert — process called exactly once (for ADDITION), not twice
        expect(mockProcess).toHaveBeenCalledTimes(1)
      })
    })

    describe('when only deletions match the patterns', () => {
      beforeEach(() => {
        mockFilesUnder.mockImplementation(() => ['test'])
        // Keep addition lines, reject deletion lines
        mockKeep.mockImplementation(((line: string) =>
          line.startsWith('A')) as typeof mockKeep)
      })
      it('Then collects include manifest entries (deletions only)', async () => {
        // Arrange
        config.include = '.sgdinclude'
        const sut = new IncludeProcessor(
          getContext({ config, metadata, trees: treeReader })
        )

        // Act
        const result = await sut.transformAndCollect(new ChangeSet())

        // Assert
        expect(elementsOf(result)).toContainEqual(includedManifest)
      })

      it('Then calls process with DELETION lines only, not ADDITION (kills L86 ConditionalExpression true)', async () => {
        // Arrange
        config.include = '.sgdinclude'
        const sut = new IncludeProcessor(
          getContext({ config, metadata, trees: treeReader })
        )

        // Act
        await sut.transformAndCollect(new ChangeSet())

        // Assert — process called exactly once (for DELETION), not twice
        expect(mockProcess).toHaveBeenCalledTimes(1)
      })
    })

    describe('when include helper is called with correct changedLine format (kills L55 StringLiteral "")', () => {
      beforeEach(() => {
        mockFilesUnder.mockImplementation(() => ['myFile.cls'])
        mockKeep.mockReturnValue(false)
      })

      it('Then keep is called with TAB-separated changeType+path line', async () => {
        // Arrange
        config.include = '.sgdinclude'
        const sut = new IncludeProcessor(
          getContext({ config, metadata, trees: treeReader })
        )

        // Act
        await sut.transformAndCollect(new ChangeSet())

        // Assert — changedLine must be "A\tmyFile.cls" and "D\tmyFile.cls"
        // StringLiteral mutation "" would call keep("") instead
        expect(mockKeep).toHaveBeenCalledWith(
          expect.stringContaining('myFile.cls')
        )
        expect(mockKeep).toHaveBeenCalledWith(expect.stringContaining('\t'))
      })
    })

    describe('includeLines set initialization integrity (kills L57:15 true, L58:42 ArrayDeclaration)', () => {
      beforeEach(() => {
        mockFilesUnder.mockImplementation(() => ['file1.cls', 'file2.cls'])
        mockKeep.mockReturnValue(false) // all lines are included
      })

      it('When two files match, Then DiffLineInterpreter.process receives exactly 2 ADDITION lines (kills L57 true mutant)', async () => {
        // L57 mutant: if (true) → always reinitializes the array for each file,
        // so second file overwrites first → only 1 line per changeType.
        // Real: array initialized once, both lines pushed → 2 lines.
        config.include = '.sgdinclude'
        const sut = new IncludeProcessor(
          getContext({ config, metadata, trees: treeReader })
        )

        await sut.transformAndCollect(new ChangeSet())

        // ADDITION lines array should have exactly 2 entries (one per file)
        const additionCallArgs = mockProcess.mock.calls.find(call =>
          (call[0] as string[])[0]?.startsWith('A')
        )?.[0] as string[]
        expect(additionCallArgs).toHaveLength(2)
      })

      it('When one file matches, Then process is called with exactly [changeType+TAB+file] (kills L58 ArrayDeclaration ["Stryker was here"])', async () => {
        // L58 mutant: includeLines.set(changeType, ["Stryker was here"]) → stray entry
        // → process receives ["Stryker was here", "A\tfile.cls"] instead of ["A\tfile.cls"]
        mockFilesUnder.mockImplementation(() => ['only.cls'])
        config.include = '.sgdinclude'
        const sut = new IncludeProcessor(
          getContext({ config, metadata, trees: treeReader })
        )

        await sut.transformAndCollect(new ChangeSet())

        // The ADDITION lines passed to process must contain only the real line, not "Stryker was here"
        const additionLines = mockProcess.mock.calls.find(call =>
          (call[0] as string[])[0]?.startsWith('A')
        )?.[0] as string[]
        expect(additionLines).toEqual(['A\tonly.cls'])
      })
    })

    describe('_collectIncludes emptyResult guard (kills L70:9 false, L70:34 BlockStatement {})', () => {
      it('When includeLines is empty, Then emptyResult is returned (L70 false mutant would call process unnecessarily)', async () => {
        // L70:9 false: if(false) → always proceeds past the emptyResult guard
        // → getFirstCommitRef() and DiffLineInterpreter.process() would be called even with no lines
        // L70:34 {}: the emptyResult() return is a no-op → same effect
        mockKeep.mockReturnValue(true) // keep all = nothing included
        config.include = '.sgdinclude'
        mockFilesUnder.mockReturnValue(['test.cls'])
        const sut = new IncludeProcessor(
          getContext({ config, metadata, trees: treeReader })
        )

        const result = await sut.transformAndCollect(new ChangeSet())

        // process must NOT be called since includeLines is empty
        expect(mockProcess).not.toHaveBeenCalled()
        expect(result).toEqual(emptyResult())
      })
    })

    describe('results array initialization (kills L76:38 ArrayDeclaration ["Stryker was here"])', () => {
      it('When ADDITION and DELETION both match, Then merged result contains exactly the items from process calls (no stray entries)', async () => {
        // L76 mutant: results = ["Stryker was here"] → mergeResults gets stray string as first result
        // mergeResults("Stryker was here", actual) → manifests = [undefined, ...actual.manifests]
        // The exact manifests array would differ (has an undefined entry).
        mockFilesUnder.mockReturnValue(['file.cls'])
        mockKeep.mockReturnValue(false)
        config.include = '.sgdinclude'
        const sut = new IncludeProcessor(
          getContext({ config, metadata, trees: treeReader })
        )

        const result = await sut.transformAndCollect(new ChangeSet())

        // All manifests must be valid HandlerResult manifest objects (no undefined from stray entry)
        for (const m of elementsOf(result)) {
          expect(m).toBeDefined()
          expect(m).toMatchObject({ type: expect.any(String) })
        }
      })
    })

    describe('process revisions passed to DiffLineInterpreter (kills L79:79 and L87:79 ObjectLiteral {})', () => {
      const firstSHA = 'first-sha-000'

      beforeEach(() => {
        mockFilesUnder.mockReturnValue(['test'])
        mockGetFirstCommitRef.mockResolvedValue(firstSHA)
      })

      it('Then ADDITION process is called with from=firstSHA, to=config.to', async () => {
        // Arrange — keep only deletion lines so only ADDITION lines are collected
        config.include = '.sgdinclude'
        config.to = 'HEAD'
        mockKeep.mockImplementation(((line: string) =>
          line.startsWith('D')) as typeof mockKeep)
        const sut = new IncludeProcessor(
          getContext({ config, metadata, trees: treeReader })
        )

        // Act
        await sut.transformAndCollect(new ChangeSet())

        // Assert — kills ObjectLiteral {} replacing { from: firstSHA, to: config.to }
        expect(mockProcess).toHaveBeenCalledWith(
          expect.any(Array),
          expect.objectContaining({ from: firstSHA, to: 'HEAD' })
        )
      })

      it('Then DELETION process is called with from=config.to, to=firstSHA', async () => {
        // Arrange — keep only addition lines so only DELETION lines are collected
        config.include = '.sgdinclude'
        config.to = 'HEAD'
        mockKeep.mockImplementation(((line: string) =>
          line.startsWith('A')) as typeof mockKeep)
        const sut = new IncludeProcessor(
          getContext({ config, metadata, trees: treeReader })
        )

        // Act
        await sut.transformAndCollect(new ChangeSet())

        // Assert — kills ObjectLiteral {} replacing { from: config.to, to: firstSHA }
        expect(mockProcess).toHaveBeenCalledWith(
          expect.any(Array),
          expect.objectContaining({ from: 'HEAD', to: firstSHA })
        )
      })
    })

    describe('DELETION pass masks firstSHA out of trees, ADDITION pass does not', () => {
      const firstSHA = 'first-sha-000'
      const stillPath = 'force-app/lwc/still/still.js'

      beforeEach(() => {
        mockGetFirstCommitRef.mockResolvedValue(firstSHA)
        mockKeep.mockReturnValue(false) // keep neither: both ADDITION and DELETION lines are collected
      })

      it('Then the ADDITION DiffLineInterpreter is built on the original, unmasked ctx', async () => {
        // Arrange
        mockFilesUnder.mockReturnValue(['test'])
        config.include = '.sgdinclude'
        const ctx = getContext({ config, metadata, trees: treeReader })
        const sut = new IncludeProcessor(ctx)

        // Act
        await sut.transformAndCollect(new ChangeSet())

        // Assert
        const additionCtx = vi.mocked(DiffLineInterpreter).mock.calls[0][0]
        expect(additionCtx.trees).toBe(treeReader)
      })

      it('Then the DELETION DiffLineInterpreter is built on a ctx whose trees report firstSHA absent, although the real reader holds a live entry for it', async () => {
        // Arrange — pathExists really does answer true for (firstSHA,
        // stillPath) on the unmasked reader, proving the mask overrides a
        // real answer rather than matching an already-empty one.
        const liveAtFirstSHA: TreeReader = {
          pathExists: (rev, path) => rev === firstSHA && path === stillPath,
          filesUnder: () => [stillPath],
          children: () => [],
        }
        config.includeDestructive = '.sgdincludedestructive'
        const sut = new IncludeProcessor(
          getContext({ config, metadata, trees: liveAtFirstSHA })
        )

        // Act
        await sut.transformAndCollect(new ChangeSet())

        // Assert
        const deletionCtx = vi.mocked(DiffLineInterpreter).mock.calls[1][0]
        expect(deletionCtx.trees).not.toBe(liveAtFirstSHA)
        expect(deletionCtx.trees.pathExists(firstSHA, stillPath)).toBe(false)
      })
    })
  })

  describe('when includeDestructive is configured', () => {
    beforeAll(() => {
      mockFilesUnder.mockImplementation(() => ['test'])
    })
    describe('when no file matches the patterns', () => {
      beforeEach(() => {
        mockKeep.mockReturnValue(true)
      })
      it('Then returns an empty result', async () => {
        // Arrange
        config.includeDestructive = '.sgdincludedestructive'
        const sut = new IncludeProcessor(
          getContext({ config, metadata, trees: treeReader })
        )

        // Act
        const result = await sut.transformAndCollect(new ChangeSet())

        // Assert
        expect(result).toEqual(emptyResult())
      })
    })

    describe('when file matches the patterns', () => {
      beforeEach(() => {
        mockKeep.mockReturnValue(false)
      })
      it('Then collects the destructive include entry', async () => {
        // Arrange
        config.includeDestructive = '.sgdincludedestructive'
        const sut = new IncludeProcessor(
          getContext({ config, metadata, trees: treeReader })
        )

        // Act
        const result = await sut.transformAndCollect(new ChangeSet())

        // Assert
        expect(elementsOf(result)).toContainEqual(includedManifest)
      })
    })
  })
})
