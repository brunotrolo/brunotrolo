'use strict'
import { beforeAll, beforeEach, describe, expect, it, vi } from 'vitest'

import { MetadataRepository } from '../../../../src/metadata/MetadataRepository'
import { getDefinition } from '../../../../src/metadata/metadataManager'
import ObjectTranslation from '../../../../src/service/objectTranslationHandler'
import type { Config } from '../../../../src/types/config'
import {
  CopyOperationKind,
  ManifestTarget,
} from '../../../../src/types/handlerResult'
import type { DiffOutcome } from '../../../../src/utils/metadataDiff'
import { elementsOf } from '../../../__utils__/handlerResultView'
import { createElement } from '../../../__utils__/testElement'
import { getConfig, getContext } from '../../../__utils__/testWork'

const { mockRun, mockWriter } = vi.hoisted(() => ({
  mockRun: vi.fn<() => Promise<DiffOutcome>>(),
  mockWriter: vi.fn(),
}))

vi.mock('../../../../src/utils/metadataDiff', () => {
  return {
    default: vi.fn().mockImplementation(function () {
      return { run: mockRun }
    }),
  }
})

vi.mock('../../../../src/utils/fsHelper')

const objectType = {
  directoryName: 'objectTranslations',
  inFolder: false,
  metaFile: false,
  suffix: 'objectTranslation',
  xmlName: 'CustomObjectTranslation',
  pruneOnly: true,
}
const line =
  'A       force-app/main/default/objectTranslations/Account-es/Account-es.objectTranslation-meta.xml'
const parentObjectTranslationPath =
  'force-app/main/default/objectTranslations/Account-es/Account-es.objectTranslation-meta.xml'

// Flat layout: the objectTranslation file sits directly under the type
// directory with no component sub-folder. SDR resolves it to the same
// component (fullName 'Account-es') as the nested layout, so sgd must too.
const flatLine =
  'A       force-app/main/default/objectTranslations/Account-es.objectTranslation-meta.xml'
const flatObjectTranslationPath =
  'force-app/main/default/objectTranslations/Account-es.objectTranslation-meta.xml'

let config: Config
beforeEach(() => {
  vi.clearAllMocks()
  mockRun.mockResolvedValue({
    manifests: { added: [], modified: [], deleted: [] },
    hasPackageContent: true,
    writer: mockWriter,
  })
  config = getConfig()
})

describe('ObjectTranslation', () => {
  let globalMetadata: MetadataRepository
  beforeAll(async () => {
    globalMetadata = await getDefinition({})
  })

  describe('collect', () => {
    it('Given objectTranslation addition, When collect, Then includes ComputedContent for pruned translation XML', async () => {
      // Arrange
      const { changeType, element } = createElement(
        line,
        objectType,
        globalMetadata
      )
      const sut = new ObjectTranslation(
        changeType,
        element,
        getContext({ config })
      )

      // Act
      const result = await sut.collect()

      // Assert
      expect(elementsOf(result)).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            target: ManifestTarget.Package,
            type: 'CustomObjectTranslation',
            member: 'Account-es',
          }),
        ])
      )
      expect(
        result.copies.some(
          c =>
            c.kind === CopyOperationKind.StreamedContent &&
            c.path.includes('Account-es.objectTranslation')
        )
      ).toBe(true)
      expect(result.warnings).toHaveLength(0)
    })

    it('Given objectTranslation addition with generateDelta false, When collect, Then returns manifest without copies', async () => {
      // Arrange
      config.generateDelta = false
      const { changeType, element } = createElement(
        line,
        objectType,
        globalMetadata
      )
      const sut = new ObjectTranslation(
        changeType,
        element,
        getContext({ config })
      )

      // Act
      const result = await sut.collect()

      // Assert
      expect(elementsOf(result)).toHaveLength(1)
      expect(elementsOf(result)[0].target).toBe(ManifestTarget.Package)
      expect(result.copies).toHaveLength(0)
    })

    it('Given objectTranslation file addition, When collect, Then does NOT produce GitCopy operations', async () => {
      // Arrange
      const { changeType, element } = createElement(
        line,
        objectType,
        globalMetadata
      )
      const sut = new ObjectTranslation(
        changeType,
        element,
        getContext({ config })
      )

      // Act
      const result = await sut.collect()

      // Assert
      expect(
        result.copies.every(c => c.kind !== CopyOperationKind.GitCopy)
      ).toBe(true)
      expect(
        result.copies.some(c => c.kind === CopyOperationKind.StreamedContent)
      ).toBe(true)
    })

    it('Given objectTranslation addition with generateDelta true, When collect, Then _shouldCollectCopies allows ComputedContent', async () => {
      // Arrange
      config.generateDelta = true
      const { changeType, element } = createElement(
        line,
        objectType,
        globalMetadata
      )
      const sut = new ObjectTranslation(
        changeType,
        element,
        getContext({ config })
      )

      // Act
      const result = await sut.collect()

      // Assert
      expect(
        result.copies.some(c => c.kind === CopyOperationKind.StreamedContent)
      ).toBe(true)
    })

    it('Given writer is null, When collectAddition, Then does not push StreamedContent copy and pushes parent GitCopy', async () => {
      // Arrange — writer is null, so the `if (writer)` guard must prevent pushing StreamedContent
      // and the `else` branch must fall back to a parent GitCopy
      config.generateDelta = true
      // `writer: null` is deliberately out of DiffOutcome's contract (real
      // producers only ever omit the key or supply a function — see
      // MetadataDiff.run's `...(writer ? { writer } : {})`): it exercises
      // the `if (writer)` guard against a second falsy value distinct from
      // `undefined`, so a mutant weakening the guard to `!== undefined`
      // would still be caught.
      mockRun.mockResolvedValue({
        manifests: { added: [], modified: [], deleted: [] },
        hasPackageContent: true,
        writer: null,
      } as unknown as DiffOutcome)
      const { changeType, element } = createElement(
        line,
        objectType,
        globalMetadata
      )
      const sut = new ObjectTranslation(
        changeType,
        element,
        getContext({ config })
      )

      // Act
      const result = await sut.collectAddition()

      // Assert
      expect(
        result.copies.some(c => c.kind === CopyOperationKind.StreamedContent)
      ).toBe(false)
      expect(
        result.copies.some(
          c =>
            c.kind === CopyOperationKind.GitCopy &&
            c.path === parentObjectTranslationPath
        )
      ).toBe(true)
    })

    it('Given fieldTranslation-only addition and writer undefined, When collectAddition, Then pushes parent GitCopy and no parent StreamedContent', async () => {
      // Arrange — mirrors the #1341 regression: only a child fieldTranslation changed,
      // parent has no surviving pruned content, so buildWriter returns undefined
      config.generateDelta = true
      // Key omitted, not set to `undefined`: mirrors how MetadataDiff.run
      // actually builds DiffOutcome (`...(writer ? { writer } : {})`), and
      // avoids exactOptionalPropertyTypes rejecting an explicit undefined.
      mockRun.mockResolvedValue({
        manifests: { added: [], modified: [], deleted: [] },
        hasPackageContent: true,
      })
      const fieldTranslationLine =
        'A       force-app/main/default/objectTranslations/Account-es/BillingFloor__c.fieldTranslation-meta.xml'
      const { changeType, element } = createElement(
        fieldTranslationLine,
        objectType,
        globalMetadata
      )
      const sut = new ObjectTranslation(
        changeType,
        element,
        getContext({ config })
      )

      // Act
      const result = await sut.collectAddition()

      // Assert
      expect(
        result.copies.some(
          c =>
            c.kind === CopyOperationKind.GitCopy &&
            c.path === parentObjectTranslationPath
        )
      ).toBe(true)
      expect(
        result.copies.some(
          c =>
            c.kind === CopyOperationKind.StreamedContent &&
            c.path === parentObjectTranslationPath
        )
      ).toBe(false)
    })

    it('Given fieldTranslation-only addition, When collectAddition, Then does not push a copy for an unresolved parent meta path', async () => {
      // Arrange — the inherited meta-file copy must not emit a bogus "undefined.*"
      // path; the parent objectTranslation is handled by the writer/fallback branch
      config.generateDelta = true
      // Key omitted, not set to `undefined`: mirrors how MetadataDiff.run
      // actually builds DiffOutcome (`...(writer ? { writer } : {})`), and
      // avoids exactOptionalPropertyTypes rejecting an explicit undefined.
      mockRun.mockResolvedValue({
        manifests: { added: [], modified: [], deleted: [] },
        hasPackageContent: true,
      })
      const fieldTranslationLine =
        'A       force-app/main/default/objectTranslations/Account-es/BillingFloor__c.fieldTranslation-meta.xml'
      const { changeType, element } = createElement(
        fieldTranslationLine,
        objectType,
        globalMetadata
      )
      const sut = new ObjectTranslation(
        changeType,
        element,
        getContext({ config })
      )

      // Act
      const result = await sut.collectAddition()

      // Assert
      expect(result.copies.some(c => c.path.includes('undefined'))).toBe(false)
    })

    it('Given flat-layout objectTranslation addition, When collect, Then member is the component name without the file extension', async () => {
      // Arrange
      const { changeType, element } = createElement(
        flatLine,
        objectType,
        globalMetadata
      )
      const sut = new ObjectTranslation(
        changeType,
        element,
        getContext({ config })
      )

      // Act
      const result = await sut.collect()

      // Assert
      expect(elementsOf(result)).toEqual([
        expect.objectContaining({
          target: ManifestTarget.Package,
          type: 'CustomObjectTranslation',
          member: 'Account-es',
        }),
      ])
      expect(result.warnings).toHaveLength(0)
    })

    it('Given flat-layout objectTranslation addition, When collect, Then the StreamedContent copy targets the file itself', async () => {
      // Arrange
      config.generateDelta = true
      const { changeType, element } = createElement(
        flatLine,
        objectType,
        globalMetadata
      )
      const sut = new ObjectTranslation(
        changeType,
        element,
        getContext({ config })
      )

      // Act
      const result = await sut.collect()

      // Assert
      expect(
        result.copies.some(
          c =>
            c.kind === CopyOperationKind.StreamedContent &&
            c.path === flatObjectTranslationPath
        )
      ).toBe(true)
    })

    it('Given flat-layout objectTranslation addition and writer undefined, When collectAddition, Then the fallback GitCopy targets the file itself', async () => {
      // Arrange — the key is omitted rather than set to `undefined`, which is
      // both what `MetadataDiff.run` actually produces (`...(writer ? { writer } : {})`)
      // and the only spelling `exactOptionalPropertyTypes` accepts.
      config.generateDelta = true
      mockRun.mockResolvedValue({
        manifests: { added: [], modified: [], deleted: [] },
        hasPackageContent: true,
      })
      const { changeType, element } = createElement(
        flatLine,
        objectType,
        globalMetadata
      )
      const sut = new ObjectTranslation(
        changeType,
        element,
        getContext({ config })
      )

      // Act
      const result = await sut.collectAddition()

      // Assert
      expect(
        result.copies.some(
          c =>
            c.kind === CopyOperationKind.GitCopy &&
            c.path === flatObjectTranslationPath
        )
      ).toBe(true)
      expect(
        result.copies.some(c => c.path.includes('objectTranslations.'))
      ).toBe(false)
    })

    it('Given flat-layout objectTranslation deletion, When collect, Then destructive member is the component name', async () => {
      // Arrange
      const { changeType, element } = createElement(
        flatLine.replace('A ', 'D '),
        objectType,
        globalMetadata
      )
      const sut = new ObjectTranslation(
        changeType,
        element,
        getContext({ config })
      )

      // Act
      const result = await sut.collect()

      // Assert
      expect(elementsOf(result)).toEqual([
        expect.objectContaining({
          target: ManifestTarget.DestructiveChanges,
          type: 'CustomObjectTranslation',
          member: 'Account-es',
        }),
      ])
    })

    it('Given fieldTranslation addition, When collect, Then includes both file copies and ComputedContent', async () => {
      // Arrange
      const fieldTranslationLine =
        'A       force-app/main/default/objectTranslations/Account-es/BillingFloor__c.fieldTranslation-meta.xml'
      const { changeType, element } = createElement(
        fieldTranslationLine,
        objectType,
        globalMetadata
      )
      const sut = new ObjectTranslation(
        changeType,
        element,
        getContext({ config })
      )

      // Act
      const result = await sut.collect()

      // Assert
      expect(elementsOf(result)).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            target: ManifestTarget.Package,
            type: 'CustomObjectTranslation',
            member: 'Account-es',
          }),
        ])
      )
      expect(
        result.copies.some(c => c.kind === CopyOperationKind.StreamedContent)
      ).toBe(true)
      expect(
        result.copies.some(c => c.kind === CopyOperationKind.GitCopy)
      ).toBe(true)
      expect(result.warnings).toHaveLength(0)
    })
  })
})
