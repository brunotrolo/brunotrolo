'use strict'
import { beforeAll, beforeEach, describe, expect, it, vi } from 'vitest'

import { MetadataRepository } from '../../../../src/metadata/MetadataRepository'
import { getDefinition } from '../../../../src/metadata/metadataManager'
import InFileHandler from '../../../../src/service/inFileHandler'
import type { Config } from '../../../../src/types/config'
import {
  ChangeKind,
  CopyOperationKind,
  ManifestTarget,
} from '../../../../src/types/handlerResult'
import { elementsOf } from '../../../__utils__/handlerResultView'
import { createElement } from '../../../__utils__/testElement'
import { getConfig, getContext } from '../../../__utils__/testWork'

const { mockGetMessage, mockRun, mockWriter } = vi.hoisted(() => ({
  mockGetMessage: vi.fn(
    (_key: string, tokens?: string[]) =>
      `could not process '${tokens?.[0]}', please ensure it is properly formatted xml in both '${tokens?.[1]}' and '${tokens?.[2]}' revision`
  ),
  mockRun: vi.fn(),
  mockWriter: vi.fn(),
}))

vi.mock('../../../../src/utils/MessageService', () => {
  return {
    MessageService: vi.fn().mockImplementation(function () {
      return { getMessage: mockGetMessage }
    }),
  }
})

vi.mock('../../../../src/utils/metadataDiff', () => {
  return {
    default: vi.fn().mockImplementation(function () {
      return { run: mockRun }
    }),
  }
})

const workflowType = {
  childXmlNames: [
    'WorkflowFieldUpdate',
    'WorkflowFlowAction',
    'WorkflowKnowledgePublish',
    'WorkflowTask',
    'WorkflowAlert',
    'WorkflowSend',
    'WorkflowOutboundMessage',
    'WorkflowRule',
  ],
  directoryName: 'workflows',
  inFolder: false,
  metaFile: false,
  suffix: 'workflow',
  xmlName: 'Workflow',
}
const globalValueSetTranslationsType = {
  directoryName: 'globalValueSetTranslations',
  inFolder: false,
  metaFile: false,
  suffix: 'globalValueSetTranslation',
  xmlName: 'GlobalValueSetTranslation',
  pruneOnly: true,
}

let globalMetadata: MetadataRepository
beforeAll(async () => {
  globalMetadata = await getDefinition({})
})
let config: Config
beforeEach(() => {
  vi.clearAllMocks()
  config = getConfig()
})

describe('inFileHandler', () => {
  describe('when file is added', () => {
    let sut: InFileHandler
    beforeEach(() => {
      // Arrange
      const { changeType, element } = createElement(
        'force-app/main/default/workflows/Account.workflow-meta.xml',
        workflowType,
        globalMetadata
      )
      sut = new InFileHandler(changeType, element, getContext({ config }))
      mockRun.mockImplementation(() =>
        Promise.resolve({
          manifests: {
            added: [{ type: 'WorkflowFlowAction', member: 'test' }],
            modified: [],
            deleted: [],
          },
          hasPackageContent: true,
          writer: mockWriter,
        })
      )
    })
    it('should store the added metadata in the package', async () => {
      // Act
      const result = await sut.collectAddition()

      // Assert
      expect(elementsOf(result)).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            target: ManifestTarget.Package,
            type: 'Workflow',
            member: 'Account',
          }),
          expect.objectContaining({
            target: ManifestTarget.Package,
            type: 'WorkflowFlowAction',
            member: 'Account.test',
          }),
        ])
      )
      expect(
        elementsOf(result).some(
          m => m.target === ManifestTarget.DestructiveChanges
        )
      ).toBe(false)
      expect(
        result.copies.some(c => c.kind === CopyOperationKind.StreamedContent)
      ).toBe(true)
    })

    describe('when metadata in file is not packable', () => {
      describe('when file have comparable metadata', () => {
        beforeEach(() => {
          // Arrange
          const { changeType, element } = createElement(
            'force-app/main/default/globalValueSetTranslations/Numbers-fr.globalValueSetTranslation-meta.xml',
            globalValueSetTranslationsType,
            globalMetadata
          )
          sut = new InFileHandler(changeType, element, getContext({ config }))
          mockRun.mockImplementation(() =>
            Promise.resolve({
              manifests: {
                added: [{ type: 'ValueTranslation', member: 'Three' }],
                modified: [],
                deleted: [],
              },
              hasPackageContent: true,
              writer: mockWriter,
            })
          )
        })
        it('should only store file name and not the metadata in file', async () => {
          // Act
          const result = await sut.collectAddition()

          // Assert
          expect(
            elementsOf(result).some(
              m => m.target === ManifestTarget.DestructiveChanges
            )
          ).toBe(false)
          expect(elementsOf(result)).toEqual(
            expect.arrayContaining([
              expect.objectContaining({
                target: ManifestTarget.Package,
                type: 'GlobalValueSetTranslation',
                member: 'Numbers-fr',
              }),
            ])
          )
          const packageManifests = elementsOf(result).filter(
            m => m.target === ManifestTarget.Package
          )
          expect(packageManifests).toHaveLength(1)
          expect(
            result.copies.some(
              c => c.kind === CopyOperationKind.StreamedContent
            )
          ).toBe(true)
        })
      })

      describe('when file does not have comparable metadata but is not empty', () => {
        beforeEach(() => {
          // Arrange
          const { changeType, element } = createElement(
            'force-app/main/default/globalValueSetTranslations/Numbers-fr.globalValueSetTranslation-meta.xml',
            globalValueSetTranslationsType,
            globalMetadata
          )
          sut = new InFileHandler(changeType, element, getContext({ config }))
          mockRun.mockImplementation(() =>
            Promise.resolve({
              manifests: {
                added: [],
                modified: [],
                deleted: [],
              },
              hasPackageContent: true,
              writer: mockWriter,
            })
          )
        })
        it('should only store file name and not the metadata in file', async () => {
          // Act
          const result = await sut.collectAddition()

          // Assert
          expect(
            elementsOf(result).some(
              m => m.target === ManifestTarget.DestructiveChanges
            )
          ).toBe(false)
          expect(elementsOf(result)).toEqual(
            expect.arrayContaining([
              expect.objectContaining({
                target: ManifestTarget.Package,
                type: 'GlobalValueSetTranslation',
                member: 'Numbers-fr',
              }),
            ])
          )
          const packageManifests = elementsOf(result).filter(
            m => m.target === ManifestTarget.Package
          )
          expect(packageManifests).toHaveLength(1)
          expect(
            result.copies.some(
              c => c.kind === CopyOperationKind.StreamedContent
            )
          ).toBe(true)
        })
      })
    })
  })

  describe('when file is modified', () => {
    let sut: InFileHandler

    describe('when elements are added and deleted', () => {
      beforeEach(() => {
        // Arrange
        const { changeType, element } = createElement(
          'force-app/main/default/workflows/Account.workflow-meta.xml',
          workflowType,
          globalMetadata
        )
        sut = new InFileHandler(changeType, element, getContext({ config }))
        mockRun.mockImplementation(() =>
          Promise.resolve({
            manifests: {
              added: [{ type: 'WorkflowAlert', member: 'test' }],
              modified: [],
              deleted: [{ type: 'WorkflowAlert', member: 'deleted' }],
            },
            hasPackageContent: true,
            writer: mockWriter,
          })
        )
      })
      it('should store the added metadata in the package and deleted in the destructiveChanges', async () => {
        // Act
        const result = await sut.collectModification()

        // Assert
        expect(elementsOf(result)).toEqual(
          expect.arrayContaining([
            expect.objectContaining({
              target: ManifestTarget.Package,
              type: 'Workflow',
              member: 'Account',
            }),
            expect.objectContaining({
              target: ManifestTarget.Package,
              type: 'WorkflowAlert',
              member: 'Account.test',
            }),
            expect.objectContaining({
              target: ManifestTarget.DestructiveChanges,
              type: 'WorkflowAlert',
              member: 'Account.deleted',
            }),
          ])
        )
        expect(
          elementsOf(result).some(
            m =>
              m.target === ManifestTarget.DestructiveChanges &&
              m.type === 'Workflow'
          )
        ).toBe(false)
        expect(
          result.copies.some(c => c.kind === CopyOperationKind.StreamedContent)
        ).toBe(true)
      })
    })

    describe('when elements are deleted and nothing is added', () => {
      beforeEach(() => {
        // Arrange
        const { changeType, element } = createElement(
          'force-app/main/default/workflows/Account.workflow-meta.xml',
          workflowType,
          globalMetadata
        )
        sut = new InFileHandler(changeType, element, getContext({ config }))
        mockRun.mockImplementation(() =>
          Promise.resolve({
            manifests: {
              added: [],
              modified: [],
              deleted: [{ type: 'WorkflowAlert', member: 'deleted' }],
            },
            hasPackageContent: false,
          })
        )
      })
      it('should store the deleted in the destructiveChanges and not produce a copy', async () => {
        // Act
        const result = await sut.collectModification()

        // Assert
        const packageManifests = elementsOf(result).filter(
          m => m.target === ManifestTarget.Package
        )
        expect(packageManifests).toHaveLength(0)
        expect(elementsOf(result)).toEqual(
          expect.arrayContaining([
            expect.objectContaining({
              target: ManifestTarget.DestructiveChanges,
              type: 'WorkflowAlert',
              member: 'Account.deleted',
            }),
          ])
        )
        expect(
          elementsOf(result).some(
            m =>
              m.target === ManifestTarget.DestructiveChanges &&
              m.type === 'Workflow'
          )
        ).toBe(false)
        expect(
          result.copies.some(c => c.kind === CopyOperationKind.StreamedContent)
        ).toBe(false)
      })

      describe('when no metadata elements are added/deleted and the file does not contain attributes', () => {
        beforeEach(() => {
          // Arrange
          const { changeType, element } = createElement(
            'force-app/main/default/workflows/Account.workflow-meta.xml',
            workflowType,
            globalMetadata
          )
          sut = new InFileHandler(changeType, element, getContext({ config }))

          mockRun.mockImplementation(() =>
            Promise.resolve({
              manifests: {
                added: [],
                modified: [],
                deleted: [],
              },
              hasPackageContent: false,
            })
          )
        })
        it('nothing should be stored and no copy should be produced', async () => {
          // Act
          const result = await sut.collectModification()

          // Assert
          expect(elementsOf(result)).toHaveLength(0)
          expect(result.copies).toHaveLength(0)
        })
      })

      describe('when no metadata elements are added, some are deleted but the file contains attributes', () => {
        beforeEach(() => {
          // Arrange
          const { changeType, element } = createElement(
            'force-app/main/default/workflows/Account.workflow-meta.xml',
            workflowType,
            globalMetadata
          )
          sut = new InFileHandler(changeType, element, getContext({ config }))
          mockRun.mockImplementation(() =>
            Promise.resolve({
              manifests: {
                added: [],
                modified: [],
                deleted: [{ type: 'Workflow', member: 'Deleted' }],
              },
              hasPackageContent: false,
            })
          )
        })
        it('should store the deleted metadata in destructiveChanges and not produce a copy', async () => {
          // Act
          const result = await sut.collectModification()

          // Assert
          const packageManifests = elementsOf(result).filter(
            m => m.target === ManifestTarget.Package
          )
          expect(packageManifests).toHaveLength(0)
          expect(elementsOf(result)).toEqual(
            expect.arrayContaining([
              expect.objectContaining({
                target: ManifestTarget.DestructiveChanges,
                type: 'Workflow',
                member: 'Account.Deleted',
              }),
            ])
          )
          expect(
            result.copies.some(
              c => c.kind === CopyOperationKind.StreamedContent
            )
          ).toBe(false)
        })
      })
    })

    describe('when metadata in file is not packable', () => {
      describe('when file have comparable metadata', () => {
        beforeEach(() => {
          // Arrange
          const { changeType, element } = createElement(
            'force-app/main/default/globalValueSetTranslations/Numbers-fr.globalValueSetTranslation-meta.xml',
            globalValueSetTranslationsType,
            globalMetadata
          )
          sut = new InFileHandler(changeType, element, getContext({ config }))
          mockRun.mockImplementation(() =>
            Promise.resolve({
              manifests: {
                added: [{ type: 'ValueTranslation', member: 'Three' }],
                modified: [],
                deleted: [],
              },
              hasPackageContent: true,
              writer: mockWriter,
            })
          )
        })
        it('should only store file name and not the metadata in file', async () => {
          // Act
          const result = await sut.collectModification()

          // Assert
          expect(
            elementsOf(result).some(
              m => m.target === ManifestTarget.DestructiveChanges
            )
          ).toBe(false)
          expect(elementsOf(result)).toEqual(
            expect.arrayContaining([
              expect.objectContaining({
                target: ManifestTarget.Package,
                type: 'GlobalValueSetTranslation',
                member: 'Numbers-fr',
              }),
            ])
          )
          const packageManifests = elementsOf(result).filter(
            m => m.target === ManifestTarget.Package
          )
          expect(packageManifests).toHaveLength(1)
          expect(
            result.copies.some(
              c => c.kind === CopyOperationKind.StreamedContent
            )
          ).toBe(true)
        })
      })

      describe('when file does not have comparable metadata but is not empty', () => {
        beforeEach(() => {
          // Arrange
          const { changeType, element } = createElement(
            'force-app/main/default/globalValueSetTranslations/Numbers-fr.globalValueSetTranslation-meta.xml',
            globalValueSetTranslationsType,
            globalMetadata
          )
          sut = new InFileHandler(changeType, element, getContext({ config }))
          mockRun.mockImplementation(() =>
            Promise.resolve({
              manifests: {
                added: [],
                modified: [],
                deleted: [],
              },
              hasPackageContent: true,
              writer: mockWriter,
            })
          )
        })
        it('should only store file name and not the metadata in file', async () => {
          // Act
          const result = await sut.collectModification()

          // Assert
          expect(
            elementsOf(result).some(
              m => m.target === ManifestTarget.DestructiveChanges
            )
          ).toBe(false)
          expect(elementsOf(result)).toEqual(
            expect.arrayContaining([
              expect.objectContaining({
                target: ManifestTarget.Package,
                type: 'GlobalValueSetTranslation',
                member: 'Numbers-fr',
              }),
            ])
          )
          const packageManifests = elementsOf(result).filter(
            m => m.target === ManifestTarget.Package
          )
          expect(packageManifests).toHaveLength(1)
          expect(
            result.copies.some(
              c => c.kind === CopyOperationKind.StreamedContent
            )
          ).toBe(true)
        })
      })
    })
  })

  describe('when file is deleted', () => {
    let sut: InFileHandler
    beforeEach(() => {
      // Arrange
      const { changeType, element } = createElement(
        'force-app/main/default/workflows/Account.workflow-meta.xml',
        workflowType,
        globalMetadata
      )
      sut = new InFileHandler(changeType, element, getContext({ config }))
      mockRun.mockImplementation(() =>
        Promise.resolve({
          manifests: {
            added: [],
            modified: [],
            deleted: [{ type: 'WorkflowAlert', member: 'test' }],
          },
          hasPackageContent: false,
        })
      )
    })
    it('should store the deleted metadata in the destructiveChanges', async () => {
      // Act
      const result = await sut.collectDeletion()

      // Assert
      const packageManifests = elementsOf(result).filter(
        m => m.target === ManifestTarget.Package
      )
      expect(packageManifests).toHaveLength(0)
      expect(elementsOf(result)).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            target: ManifestTarget.DestructiveChanges,
            type: 'WorkflowAlert',
            member: 'Account.test',
          }),
        ])
      )
      expect(
        elementsOf(result).some(
          m =>
            m.target === ManifestTarget.DestructiveChanges &&
            m.type === 'Workflow'
        )
      ).toBe(false)
      expect(mockRun).toHaveBeenCalled()
      expect(
        result.copies.some(c => c.kind === CopyOperationKind.StreamedContent)
      ).toBe(false)
    })
    describe('when metadata in file is prune Only', () => {
      beforeEach(() => {
        // Arrange
        const { changeType, element } = createElement(
          'force-app/main/default/globalValueSetTranslations/Numbers-fr.globalValueSetTranslation-meta.xml',
          globalValueSetTranslationsType,
          globalMetadata
        )
        sut = new InFileHandler(changeType, element, getContext({ config }))
      })
      it('should only store file name and not the metadata in file', async () => {
        // Act
        const result = await sut.collectDeletion()

        // Assert
        const packageManifests = elementsOf(result).filter(
          m => m.target === ManifestTarget.Package
        )
        expect(packageManifests).toHaveLength(0)
        expect(elementsOf(result)).toEqual(
          expect.arrayContaining([
            expect.objectContaining({
              target: ManifestTarget.DestructiveChanges,
              type: 'GlobalValueSetTranslation',
              member: 'Numbers-fr',
            }),
          ])
        )
        expect(
          elementsOf(result).some(m => m.type === 'ValueTranslation')
        ).toBe(false)
        expect(mockRun).not.toHaveBeenCalled()
        expect(result.copies).toHaveLength(0)
      })
    })
  })
})

describe('inFileHandler collect', () => {
  let globalMetadata: MetadataRepository
  beforeAll(async () => {
    globalMetadata = await getDefinition({})
  })

  let config: Config

  beforeEach(() => {
    vi.clearAllMocks()
    config = getConfig()
  })

  it('Given added workflow with child elements, When collect, Then returns Package manifests and ComputedContent copy', async () => {
    // Arrange
    const { changeType, element } = createElement(
      'A       force-app/main/default/workflows/Account.workflow-meta.xml',
      workflowType,
      globalMetadata
    )
    const sut = new InFileHandler(changeType, element, getContext({ config }))
    mockRun.mockImplementation(() =>
      Promise.resolve({
        manifests: {
          added: [{ type: 'WorkflowFlowAction', member: 'test' }],
          modified: [],
          deleted: [],
        },
        hasPackageContent: true,
        writer: mockWriter,
      })
    )

    // Act
    const result = await sut.collect()

    // Assert
    expect(elementsOf(result)).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          target: ManifestTarget.Package,
          type: 'Workflow',
          member: 'Account',
        }),
        expect.objectContaining({
          target: ManifestTarget.Package,
          type: 'WorkflowFlowAction',
          member: 'Account.test',
        }),
      ])
    )
    expect(
      result.copies.some(c => c.kind === CopyOperationKind.StreamedContent)
    ).toBe(true)
    expect(result.warnings).toHaveLength(0)
  })

  it('Given added workflow with generateDelta false, When collect, Then returns manifests without copies', async () => {
    // Arrange
    config.generateDelta = false
    const { changeType, element } = createElement(
      'A       force-app/main/default/workflows/Account.workflow-meta.xml',
      workflowType,
      globalMetadata
    )
    const sut = new InFileHandler(changeType, element, getContext({ config }))
    mockRun.mockImplementation(() =>
      Promise.resolve({
        manifests: {
          added: [{ type: 'WorkflowFlowAction', member: 'test' }],
          modified: [],
          deleted: [],
        },
        hasPackageContent: true,
        writer: mockWriter,
      })
    )

    // Act
    const result = await sut.collect()

    // Assert
    expect(elementsOf(result).length).toBeGreaterThan(0)
    expect(result.copies).toHaveLength(0)
    expect(result.warnings).toHaveLength(0)
  })

  it('Given compare throws an error, When collect, Then returns warning with meaningful message', async () => {
    // Arrange
    config.from = 'commitA'
    config.to = 'commitB'
    const { changeType, element } = createElement(
      'A       force-app/main/default/workflows/Account.workflow-meta.xml',
      workflowType,
      globalMetadata
    )
    const sut = new InFileHandler(changeType, element, getContext({ config }))
    mockRun.mockImplementation(() =>
      Promise.reject(
        new Error("Cannot read properties of undefined (reading 'addChild')")
      )
    )

    // Act
    const result = await sut.collect()

    // Assert
    expect(elementsOf(result)).toHaveLength(0)
    expect(result.copies).toHaveLength(0)
    expect(result.warnings).toHaveLength(1)
    expect(mockGetMessage).toHaveBeenCalledWith('warning.MalformedXML', [
      'force-app/main/default/workflows/Account.workflow-meta.xml',
      'commitA',
      'commitB',
    ])
    expect(result.warnings[0].message).toContain(
      'force-app/main/default/workflows/Account.workflow-meta.xml'
    )
    expect(result.warnings[0].message).toContain('commitA')
    expect(result.warnings[0].message).toContain('commitB')
    expect(result.warnings[0].cause).toBeInstanceOf(Error)
  })

  it('Given added workflow, When collect, Then _delegateFileCopy returns false and no GitCopy operations are produced', async () => {
    // Arrange
    const { changeType, element } = createElement(
      'A       force-app/main/default/workflows/Account.workflow-meta.xml',
      workflowType,
      globalMetadata
    )
    const sut = new InFileHandler(changeType, element, getContext({ config }))
    mockRun.mockImplementation(() =>
      Promise.resolve({
        manifests: {
          added: [{ type: 'WorkflowFlowAction', member: 'test' }],
          modified: [],
          deleted: [],
        },
        hasPackageContent: true,
        writer: mockWriter,
      })
    )

    // Act
    const result = await sut.collect()

    // Assert
    expect(result.copies.every(c => c.kind !== CopyOperationKind.GitCopy)).toBe(
      true
    )
    expect(
      result.copies.some(c => c.kind === CopyOperationKind.StreamedContent)
    ).toBe(true)
  })

  it('Given modified workflow with added and deleted elements, When collect, Then returns both Package and DestructiveChanges manifests', async () => {
    // Arrange
    const { changeType, element } = createElement(
      'M       force-app/main/default/workflows/Account.workflow-meta.xml',
      workflowType,
      globalMetadata
    )
    const sut = new InFileHandler(changeType, element, getContext({ config }))
    mockRun.mockImplementation(() =>
      Promise.resolve({
        manifests: {
          added: [{ type: 'WorkflowAlert', member: 'added' }],
          modified: [],
          deleted: [{ type: 'WorkflowAlert', member: 'removed' }],
        },
        hasPackageContent: true,
        writer: mockWriter,
      })
    )

    // Act
    const result = await sut.collect()

    // Assert
    expect(elementsOf(result)).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          target: ManifestTarget.Package,
          type: 'WorkflowAlert',
          member: 'Account.added',
        }),
        expect.objectContaining({
          target: ManifestTarget.DestructiveChanges,
          type: 'WorkflowAlert',
          member: 'Account.removed',
        }),
      ])
    )
    expect(result.warnings).toHaveLength(0)
  })

  it('Given generateDelta false, When collect with changes, Then no StreamedContent copy is emitted', async () => {
    // Arrange
    config.generateDelta = false
    const { changeType, element } = createElement(
      'A       force-app/main/default/workflows/Account.workflow-meta.xml',
      workflowType,
      globalMetadata
    )
    const sut = new InFileHandler(changeType, element, getContext({ config }))
    mockRun.mockImplementation(() =>
      Promise.resolve({
        manifests: {
          added: [{ type: 'WorkflowFlowAction', member: 'test' }],
          modified: [],
          deleted: [],
        },
        hasPackageContent: true,
        writer: mockWriter,
      })
    )

    // Act
    const result = await sut.collect()

    // Assert
    expect(result.copies).toHaveLength(0)
    expect(mockWriter).not.toHaveBeenCalled()
  })

  it('Given generateDelta true with a writer, When collect runs, Then prune is called and ComputedContent is produced', async () => {
    // Arrange
    config.generateDelta = true
    const { changeType, element } = createElement(
      'A       force-app/main/default/workflows/Account.workflow-meta.xml',
      workflowType,
      globalMetadata
    )
    const sut = new InFileHandler(changeType, element, getContext({ config }))
    mockRun.mockImplementation(() =>
      Promise.resolve({
        manifests: {
          added: [{ type: 'WorkflowFlowAction', member: 'test' }],
          modified: [],
          deleted: [],
        },
        hasPackageContent: true,
        writer: mockWriter,
      })
    )

    // Act
    const result = await sut.collect()

    // Assert
    expect(
      result.copies.some(c => c.kind === CopyOperationKind.StreamedContent)
    ).toBe(true)
  })

  it('Given hasPackageContent=true with writer absent (generateDelta=false, packable child added), When collect runs, Then the parent container is added to package manifest', async () => {
    // Regression lock: under generateDelta=false the engine produces
    // hasPackageContent=true but no writer (no per-file pruned XML).
    // The handler MUST still emit the parent container so the file is
    // listed in package.xml — without it, Salesforce rejects the deploy
    // for any pre-existing sibling sub-element of the same parent.
    config.generateDelta = false
    const { changeType, element } = createElement(
      'A       force-app/main/default/workflows/Account.workflow-meta.xml',
      workflowType,
      globalMetadata
    )
    const sut = new InFileHandler(changeType, element, getContext({ config }))
    mockRun.mockResolvedValue({
      manifests: {
        added: [{ type: 'WorkflowAlert', member: 'NewAlert' }],
        modified: [],
        deleted: [],
      },
      hasPackageContent: true,
      // no writer — generateDelta=false produces no per-file pruned XML
    })

    // Act
    const result = await sut.collect()

    // Assert — parent Workflow container present in package manifest
    expect(elementsOf(result)).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          target: ManifestTarget.Package,
          type: 'Workflow',
          member: 'Account',
        }),
        expect.objectContaining({
          target: ManifestTarget.Package,
          type: 'WorkflowAlert',
          member: 'Account.NewAlert',
        }),
      ])
    )
    expect(
      result.copies.some(c => c.kind === CopyOperationKind.StreamedContent)
    ).toBe(false)
  })

  it('Given metadataDiff reports modified child elements, When collect runs, Then modified entries are added to the package manifest', async () => {
    // Regression lock: _collectCompareResult collects added, modified AND
    // deleted comparison buckets separately. Every other fixture in this
    // file leaves `modified` empty, so a removed modified-bucket collection
    // call would go unnoticed without this test.
    const { changeType, element } = createElement(
      'A       force-app/main/default/workflows/Account.workflow-meta.xml',
      workflowType,
      globalMetadata
    )
    const sut = new InFileHandler(changeType, element, getContext({ config }))
    mockRun.mockResolvedValue({
      manifests: {
        added: [],
        modified: [{ type: 'WorkflowAlert', member: 'ChangedAlert' }],
        deleted: [],
      },
      hasPackageContent: true,
      writer: mockWriter,
    })

    // Act
    const result = await sut.collect()

    // Assert
    expect(elementsOf(result)).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          target: ManifestTarget.Package,
          type: 'WorkflowAlert',
          member: 'Account.ChangedAlert',
          changeKind: ChangeKind.Modify,
        }),
      ])
    )
  })
})
