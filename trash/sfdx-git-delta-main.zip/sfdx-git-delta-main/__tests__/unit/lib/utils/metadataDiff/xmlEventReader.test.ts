'use strict'
import { afterEach, describe, expect, it, vi } from 'vitest'

import {
  parseFromSideSwallowing,
  parseToSidePropagating,
} from '../../../../../src/utils/metadataDiff/xmlEventReader'

vi.mock('../../../../../src/utils/LoggingService')

const PROFILE_WITH_ATTRS_AND_COMMENT = `<?xml version="1.0" encoding="UTF-8"?>
<Profile xmlns="http://soap.sforce.com/2006/04/metadata">
  <!-- a comment -->
  <fieldPermissions>
    <field>Account.Name</field>
    <editable>true</editable>
    <readable>true</readable>
  </fieldPermissions>
  <fieldPermissions>
    <field>Account.Description</field>
    <editable>false</editable>
    <readable>true</readable>
  </fieldPermissions>
  <fieldPermissions>
    <field>Contact.Email</field>
    <editable>true</editable>
    <readable>true</readable>
  </fieldPermissions>
</Profile>`

describe('xmlEventReader', () => {
  describe('parseToSidePropagating', () => {
    it('Given a Profile with three fieldPermissions and a root-level comment, When parseToSidePropagating runs, Then onElement is invoked per child and root capture contains the xmlns', async () => {
      // Arrange
      const calls: Array<[string, unknown]> = []
      const onElement = vi.fn((subType: string, element: unknown) => {
        calls.push([subType, element])
      })

      // Act
      const sut = await parseToSidePropagating(
        PROFILE_WITH_ATTRS_AND_COMMENT,
        onElement
      )

      // Assert
      expect(sut.rootKey).toBe('Profile')
      expect(sut.rootAttributes).toEqual({
        '@_xmlns': 'http://soap.sforce.com/2006/04/metadata',
      })
      const fieldPermissionsCalls = calls.filter(
        ([subType]) => subType === 'fieldPermissions'
      )
      expect(fieldPermissionsCalls).toHaveLength(3)
    })

    it('Given malformed XML, When parseToSidePropagating runs, Then the rejection propagates', async () => {
      // Arrange
      const source = '<Root><unclosed>'
      const onElement = vi.fn()

      // Act & Assert
      await expect(parseToSidePropagating(source, onElement)).rejects.toThrow()
    })

    it.each([
      ['unclosed root', '<Root><a>'],
      ['inner tag mismatch', '<Root><a></b></Root>'],
      ['multiple top-level roots', '<A/><B/>'],
      ['sibling after closed root', '<Root></Root><Sibling/>'],
      ['unterminated tag', '<Root'],
      ['closing tag before opening', '</Root>'],
      ['no name in open tag', '<>foo</>'],
      ['malformed close tag in body', '<Root></></Root>'],
      ['unterminated close tag', '<Root></Root'],
    ])(
      'Given %s, When parseToSidePropagating runs, Then it rejects',
      async (_label, source) => {
        const onElement = vi.fn()
        await expect(
          parseToSidePropagating(source, onElement)
        ).rejects.toThrow()
      }
    )

    it('Given trailing whitespace after the root close, When parseToSidePropagating runs, Then it is tolerated', async () => {
      // Arrange — exercises the trailing-whitespace branch of verifyTail.
      const onElement = vi.fn()
      const source = '<Root></Root>\n  \t\r\n'

      // Act
      const sut = await parseToSidePropagating(source, onElement)

      // Assert
      expect(sut.rootKey).toBe('Root')
    })

    it('Given a comment after the root close, When parseToSidePropagating runs, Then the trailing comment is tolerated', async () => {
      // Arrange — well-formed XML allows comments after the document root.
      const onElement = vi.fn()
      const source = '<Root></Root><!-- trailing -->'

      // Act
      const sut = await parseToSidePropagating(source, onElement)

      // Assert
      expect(sut.rootKey).toBe('Root')
    })

    it('Given an unterminated trailing comment, When parseToSidePropagating runs, Then it rejects naming the unterminated comment', async () => {
      // Arrange — comment opened after root close but never terminated.
      const onElement = vi.fn()
      const source = '<Root></Root><!-- never closed'

      // Act & Assert
      await expect(parseToSidePropagating(source, onElement)).rejects.toThrow(
        'unterminated comment after root close'
      )
    })

    it('Given trailing text after the root close, When parseToSidePropagating runs, Then it rejects naming the unexpected content', async () => {
      // Arrange — only a `<!--` opener may divert verifyTail from this error.
      const onElement = vi.fn()
      const source = '<Root></Root>extra'

      // Act & Assert
      await expect(parseToSidePropagating(source, onElement)).rejects.toThrow(
        'unexpected content after root close'
      )
    })

    it('Given a trailing `<!-->` whose dashes belong to its opener, When parseToSidePropagating runs, Then it rejects it as an unterminated comment', async () => {
      // Arrange — the `-->` search starts after the four-character opener,
      // so the opener's own dashes cannot close the comment.
      const onElement = vi.fn()
      const source = '<Root></Root><!-->'

      // Act & Assert
      await expect(parseToSidePropagating(source, onElement)).rejects.toThrow(
        'unterminated comment after root close'
      )
    })

    it('Given an unterminated comment holding a `>` before the root, When parseToSidePropagating runs, Then skipPrologueMisc does not skip it as a `<!...>` declaration and no root is found', async () => {
      // Arrange
      const onElement = vi.fn()
      const source = '<!-- never closed > <Root>x</Root>'

      // Act & Assert
      await expect(parseToSidePropagating(source, onElement)).rejects.toThrow(
        'to-side document has no root element'
      )
    })

    it('Given a DOCTYPE declaration after the XML declaration, When parseToSidePropagating runs, Then both the header and the root are captured', async () => {
      // Arrange — the `>` closing the XML declaration sits right before the
      // DOCTYPE, so the declaration's `>` search must start past its `<!`.
      const onElement = vi.fn()
      const source =
        '<?xml version="1.0"?><!DOCTYPE root SYSTEM "ext.dtd"><Root>x</Root>'

      // Act
      const sut = await parseToSidePropagating(source, onElement)

      // Assert
      expect(sut.rootKey).toBe('Root')
      expect(sut.xmlHeader).toEqual({ '?xml': { '@_version': '1.0' } })
    })

    it('Given a leading DOCTYPE declaration, When parseToSidePropagating runs, Then the prologue skips it and parses the root', async () => {
      // Arrange — exercises the `<!...>` branch in skipPrologueMisc.
      const onElement = vi.fn()
      const source = '<!DOCTYPE root SYSTEM "ext.dtd"><Root>x</Root>'

      // Act
      const sut = await parseToSidePropagating(source, onElement)

      // Assert
      expect(sut.rootKey).toBe('Root')
    })

    it('Given an unterminated DOCTYPE declaration, When parseToSidePropagating runs, Then it rejects', async () => {
      // Arrange — `<!DOCTYPE root` has no closing `>`, prologue bails.
      const onElement = vi.fn()
      const source = '<!DOCTYPE root'

      // Act & Assert
      await expect(parseToSidePropagating(source, onElement)).rejects.toThrow()
    })

    it('Given empty XML, When parseToSidePropagating runs, Then the rejection propagates', async () => {
      // Arrange
      const source = ''
      const onElement = vi.fn()

      // Act & Assert
      await expect(parseToSidePropagating(source, onElement)).rejects.toThrow()
    })
  })

  describe('parseFromSideSwallowing', () => {
    it('Given a valid source, When parseFromSideSwallowing runs, Then elements are emitted and RootCapture returned', async () => {
      // Arrange
      const calls: Array<[string, unknown]> = []
      const onElement = vi.fn((subType: string, element: unknown) => {
        calls.push([subType, element])
      })

      // Act
      const sut = await parseFromSideSwallowing(
        PROFILE_WITH_ATTRS_AND_COMMENT,
        onElement
      )

      // Assert
      expect(sut).not.toBeNull()
      expect(sut?.rootKey).toBe('Profile')
      expect(
        calls.filter(([subType]) => subType === 'fieldPermissions')
      ).toHaveLength(3)
    })

    it('Given a null source, When parseFromSideSwallowing runs, Then it resolves null', async () => {
      // Arrange
      const onElement = vi.fn()

      // Act
      const sut = await parseFromSideSwallowing(null, onElement)

      // Assert
      expect(sut).toBeNull()
      expect(onElement).not.toHaveBeenCalled()
    })

    it('Given an undefined source, When parseFromSideSwallowing runs, Then it resolves null', async () => {
      // Arrange
      const onElement = vi.fn()

      // Act
      const sut = await parseFromSideSwallowing(undefined, onElement)

      // Assert
      expect(sut).toBeNull()
    })

    it('Given an empty string source, When parseFromSideSwallowing runs, Then it resolves null without emission', async () => {
      // Arrange
      const onElement = vi.fn()

      // Act
      const sut = await parseFromSideSwallowing('', onElement)

      // Assert
      expect(sut).toBeNull()
      expect(onElement).not.toHaveBeenCalled()
    })

    it('Given a leading <!-- comment --> before the root, When parseFromSideSwallowing runs, Then skipPrologueMisc advances past it', async () => {
      // Arrange — leading comment between the declaration and the root.
      const onElement = vi.fn()
      const source = `<?xml version="1.0"?><!-- intro -->\n<Profile xmlns="http://soap.sforce.com/2006/04/metadata"><a/></Profile>`

      // Act
      const sut = await parseFromSideSwallowing(source, onElement)

      // Assert
      expect(sut?.rootKey).toBe('Profile')
      expect(onElement).toHaveBeenCalledWith('a', expect.any(Object))
    })

    it('Given an unterminated comment in the body, When parseFromSideSwallowing runs, Then streamRootChildren stops at the end of input after emitting the elements before it', async () => {
      const onElement = vi.fn()
      const source = `<Profile><a/><!-- truncated`
      const sut = await parseFromSideSwallowing(source, onElement)
      expect(sut).not.toBeNull()
      const tags = onElement.mock.calls.map(([tag]) => tag)
      expect(tags).toEqual(['a'])
    })

    it('Given input that throws inside driveParse, When parseFromSideSwallowing runs, Then its catch resolves null', async () => {
      // Arrange — Buffer-like source whose toString throws so the catch
      // arm in parseFromSideSwallowing fires.
      const onElement = vi.fn()
      const exploding = new Proxy({} as Buffer, {
        get(_target, prop) {
          if (prop === 'toString') {
            return () => {
              throw new Error('boom')
            }
          }
          return undefined
        },
      })

      // Act
      const sut = await parseFromSideSwallowing(exploding, onElement)

      // Assert
      expect(sut).toBeNull()
    })

    it('Given malformed XML, When parseFromSideSwallowing runs, Then it tolerates the partial tree (no balance check on the swallowing path)', async () => {
      // Arrange — `parseFromSideSwallowing` skips the balance-check pre-pass
      // for performance (saves an O(N) scan per from-side parse). txml is
      // tolerant of unclosed tags, so we get a partial RootCapture rather
      // than null. The caller treats this as best-effort prior content;
      // anything truly catastrophic still goes through the catch and
      // returns null. The strict failure contract lives on the to-side
      // (`parseToSidePropagating`) where the diff caller wires it to the
      // MalformedXML warning.
      const source = '<Root><unclosed>'
      const onElement = vi.fn()

      // Act
      const sut = await parseFromSideSwallowing(source, onElement)

      // Assert
      expect(sut).not.toBeNull()
      expect(sut?.rootKey).toBe('Root')
    })

    it('Given a Buffer source, When parseFromSideSwallowing runs, Then it decodes and emits elements', async () => {
      // Arrange
      const onElement = vi.fn()

      // Act
      const sut = await parseFromSideSwallowing(
        Buffer.from(PROFILE_WITH_ATTRS_AND_COMMENT, 'utf8'),
        onElement
      )

      // Assert
      expect(sut).not.toBeNull()
      expect(onElement).toHaveBeenCalled()
    })

    it('Given a document with only a comment at root, When parseFromSideSwallowing runs, Then no subType elements are emitted', async () => {
      // Arrange
      const onElement = vi.fn()
      const source = `<?xml version="1.0" encoding="UTF-8"?>
<Profile xmlns="http://soap.sforce.com/2006/04/metadata">
  <!-- only a comment -->
</Profile>`

      // Act
      const sut = await parseFromSideSwallowing(source, onElement)

      // Assert
      expect(sut?.rootKey).toBe('Profile')
      // #comment is an attribute-like key not a subType, so it is not emitted
      const nonCommentCalls = onElement.mock.calls.filter(
        ([subType]) => !(subType as string).startsWith('@_')
      )
      const subTypeCalls = nonCommentCalls.filter(
        ([subType]) => subType !== '#comment'
      )
      expect(subTypeCalls).toHaveLength(0)
    })

    it('Given a document with xml declaration, When parseFromSideSwallowing runs, Then xmlHeader is populated on RootCapture', async () => {
      // parsePrologue's `declaration ? parseDeclaration(...) : undefined` is a
      // ternary on a bare identifier, which Stryker does not mutate; this pins
      // the populated side of it directly.
      const onElement = vi.fn()
      const source = `<?xml version="1.0" encoding="UTF-8"?>\n<Profile xmlns="http://soap.sforce.com/2006/04/metadata"></Profile>`
      const sut = await parseFromSideSwallowing(source, onElement)
      expect(sut?.xmlHeader).toBeDefined()
      expect(sut?.xmlHeader?.['?xml']).toBeDefined()
    })

    it('Given a document without xml declaration, When parseFromSideSwallowing runs, Then xmlHeader is undefined', async () => {
      // The undefined side of the same parsePrologue ternary.
      const onElement = vi.fn()
      const source = `<Profile xmlns="http://soap.sforce.com/2006/04/metadata"></Profile>`
      const sut = await parseFromSideSwallowing(source, onElement)
      expect(sut?.xmlHeader).toBeUndefined()
    })

    it('Given a Buffer source with non-ASCII content, When parseFromSideSwallowing runs, Then it decodes correctly via toString utf8', async () => {
      // driveParse must decode a Buffer as utf8 rather than use it as a string.
      const onElement = vi.fn()
      const content = `<?xml version="1.0" encoding="UTF-8"?>\n<Profile xmlns="http://soap.sforce.com/2006/04/metadata">\n  <fieldPermissions>\n    <field>café</field>\n  </fieldPermissions>\n</Profile>`
      const buf = Buffer.from(content, 'utf8')
      const sut = await parseFromSideSwallowing(buf, onElement)
      expect(sut).not.toBeNull()
      expect(onElement).toHaveBeenCalledWith(
        'fieldPermissions',
        expect.objectContaining({ field: 'café' })
      )
    })
  })

  describe('parseToSidePropagating', () => {
    it('Given a document with xml declaration, When parseToSidePropagating runs, Then xmlHeader is populated', async () => {
      const onElement = vi.fn()
      const source = `<?xml version="1.0" encoding="UTF-8"?>\n<Profile xmlns="http://soap.sforce.com/2006/04/metadata"></Profile>`
      const sut = await parseToSidePropagating(source, onElement)
      expect(sut.xmlHeader).toBeDefined()
    })

    it('Given a document without root element (only declaration), When parseToSidePropagating runs, Then it rejects with "no root element"', async () => {
      // A document with no root element makes driveParse return null, which
      // parseToSidePropagating's null-capture guard turns into this rejection.
      const onElement = vi.fn()
      await expect(
        parseToSidePropagating('<?xml version="1.0"?>', onElement)
      ).rejects.toThrow('to-side document has no root element')
    })

    it('Given a string source, When parseToSidePropagating runs, Then driveParse uses it as-is and resolves', async () => {
      const onElement = vi.fn()
      const source = `<Root><child>val</child></Root>`
      const sut = await parseToSidePropagating(source, onElement)
      expect(sut.rootKey).toBe('Root')
      expect(onElement).toHaveBeenCalledWith('child', 'val')
    })

    it('Given a Buffer source, When parseToSidePropagating runs, Then driveParse decodes it and parses correctly', async () => {
      const onElement = vi.fn()
      const source = Buffer.from(`<Root><item>hello</item></Root>`, 'utf8')
      const sut = await parseToSidePropagating(source, onElement)
      expect(sut.rootKey).toBe('Root')
      expect(onElement).toHaveBeenCalledWith('item', 'hello')
    })

    it('Given a declaration with a no-value (boolean) attribute, When parseToSidePropagating runs, Then parseDeclaration round-trips the attribute as `true`', async () => {
      // Arrange — `<?xml standalone?>` produces a tNode with attribute
      // value === null. parseDeclaration's ternary maps that back to `true`.
      // (txml folds the trailing `?` into the attribute name; we just
      // assert the value mapping, not the exact name shape.)
      const onElement = vi.fn()
      const source = '<?xml standalone?><Root>x</Root>'

      // Act
      const sut = await parseToSidePropagating(source, onElement)

      // Assert — at least one declaration attribute round-trips as `true`
      const xmlHeader = sut.xmlHeader as Record<string, Record<string, unknown>>
      const declAttrs = xmlHeader['?xml']!
      expect(Object.values(declAttrs)).toContain(true)
    })

    it('Given a self-closing root element, When parseToSidePropagating runs, Then syntheticRootTag strips the slash and the attributes are captured', async () => {
      // Arrange — `<Root attr="x"/>` exercises the self-closing branch of
      // syntheticRootTag.
      const onElement = vi.fn()
      const source = '<Root attr="x"/>'

      // Act
      const sut = await parseToSidePropagating(source, onElement)

      // Assert
      expect(sut.rootKey).toBe('Root')
      expect(sut.rootAttributes).toEqual({ '@_attr': 'x' })
      expect(onElement).not.toHaveBeenCalled()
    })

    it('Given a root with a no-value (boolean) attribute, When parseToSidePropagating runs, Then parseRootAttributes renders the attribute as the string "true"', async () => {
      // Arrange — `<Root flag>x</Root>` round-trips the boolean attribute as
      // 'true'. The writer renders `attr="value"`, so the value must be a
      // string, not the JS literal `true`.
      const onElement = vi.fn()
      const source = '<Root flag>x</Root>'

      // Act
      const sut = await parseToSidePropagating(source, onElement)

      // Assert
      expect(sut.rootAttributes).toEqual({ '@_flag': 'true' })
    })
  })

  describe('parseDeclaration defensive guard', () => {
    // The txml mock must not outlive this test even when an assertion fails.
    afterEach(() => {
      vi.doUnmock('txml/txml')
      vi.resetModules()
    })

    it('Given a declaration string that produces no decl node, When parsePrologue runs, Then xmlHeader contains an empty header object', async () => {
      // Arrange — the XML_DECL_RE matches `<?xml ... ?>` shape but if the
      // captured slice produces no decl node (defensive guard), the
      // fallback returns an empty header object. txml does emit a `?xml`
      // node for a well-formed declaration, so the defensive arm is reached
      // by mocking txml and re-importing the module.
      vi.resetModules()
      vi.doMock('txml/txml', () => ({
        // First call (parseDeclaration) returns an empty tree → declNode
        // is undefined → !declNode branch fires.
        parse: vi.fn(() => []),
      }))
      const reader = await import(
        '../../../../../src/utils/metadataDiff/xmlEventReader'
      )
      const onElement = vi.fn()

      // Act — `<?xml ... ?>` triggers the regex match; the mocked txml
      // returns no decl node so the fallback fires.
      const sut = await reader.parseFromSideSwallowing(
        '<?xml version="1.0"?><Root/>',
        onElement
      )

      // Assert — parseRootAttributes tolerates the empty synthetic tree, so
      // the capture survives and carries the `!declNode` fallback header.
      expect(sut?.xmlHeader).toEqual({ '?xml': {} })
    })
  })
})
