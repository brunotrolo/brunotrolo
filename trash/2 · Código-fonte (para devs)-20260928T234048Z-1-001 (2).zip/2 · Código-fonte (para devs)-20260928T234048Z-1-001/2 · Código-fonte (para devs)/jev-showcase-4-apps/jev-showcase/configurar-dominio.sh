#!/usr/bin/env bash
# Troca o marcador <DOMINIO> pelo hostname da sua VPS em todos os arquivos de texto do pacote (macOS e Linux).
#
# Uso:   ./configurar-dominio.sh srv123456.hstgr.cloud
#        ./configurar-dominio.sh novo.exemplo.com.br --de srv123456.hstgr.cloud   (troca um hostname já configurado)
#
# Na Hostinger, o hostname da VPS (hPanel → VPS → Visão geral, no formato srvNNNNNN.hstgr.cloud) já resolve qualquer
# subdomínio (*.srvNNNNNN.hstgr.cloud), então jev.<hostname> e jev-planilha.<hostname> funcionam sem criar DNS.
# Com um domínio próprio, crie um registro A curinga (*.seudominio → IP da VPS) antes de publicar.
#
# O README.md da raiz e este script ficam como estão (eles explicam o marcador). Depois da troca, o script regera
# deploy/Caddyfile e deploy/docker-compose.yml com o node deploy/gen.mjs (se o Node estiver instalado).
set -euo pipefail
cd "$(dirname "$0")"

ANTIGO='<DOMINIO>'
NOVO=''
while [ $# -gt 0 ]; do
  case "$1" in
    --de) ANTIGO="${2:-}"; shift 2 ;;
    -h|--help) sed -n '2,12p' "$0"; exit 0 ;;
    *) NOVO="$1"; shift ;;
  esac
done
if [ -z "$NOVO" ] || [ -z "$ANTIGO" ]; then
  echo "uso: $0 <hostname>   (ex.: $0 srv123456.hstgr.cloud)" >&2
  exit 1
fi
# aceita também "https://host/" colado do navegador
NOVO=$(printf '%s' "$NOVO" | tr 'A-Z' 'a-z' | sed -E 's#^[a-z]+://##; s#/.*$##; s#\.$##')
if ! printf '%s' "$NOVO" | grep -Eq '^([a-z0-9]([a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$'; then
  echo "hostname inválido: $NOVO (use só letras, números, hífens e pontos, ex.: srv123456.hstgr.cloud)" >&2
  exit 1
fi

LISTA=$(mktemp); trap 'rm -f "$LISTA"' EXIT
find . \( -name node_modules -o -name .git -o -name .secrets -o -name scratch \) -prune -o \
  -type f ! -path ./README.md ! -path ./configurar-dominio.sh -print0 \
  | xargs -0 grep -lIF --null -e "$ANTIGO" > "$LISTA" || true
N=$(tr -cd '\0' < "$LISTA" | wc -c | tr -d ' ')
if [ "$N" = "0" ]; then
  echo "Nenhum arquivo com \"$ANTIGO\". Se o pacote já foi configurado, use: $0 $NOVO --de <hostname antigo>"
  exit 1
fi
# perl -pi funciona igual no macOS e no Linux (o sed -i não)
xargs -0 env ANTIGO="$ANTIGO" NOVO="$NOVO" perl -pi -e 's/\Q$ENV{ANTIGO}\E/$ENV{NOVO}/g' < "$LISTA"
echo "✓ $N arquivo(s): \"$ANTIGO\" → \"$NOVO\""

if command -v node >/dev/null 2>&1; then
  node deploy/gen.mjs
else
  echo "(Node não encontrado: o deploy/deploy.sh regera o Caddyfile e o docker-compose.yml na hora de publicar)"
fi
echo "Endereços: https://jev.$NOVO (login e índice dos demos) e https://jev-<app>.$NOVO"
