// Jev Gateway — único lugar que conhece a chave do OpenRouter.
// Todos os apps chamam POST /v1/decide aqui; o gateway aplica orçamento, limite por IP,
// cache opcional, retry e registra custo/latência de cada decisão.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const PORT = +(process.env.PORT || 8787);
const KEY = (process.env.OPENROUTER_API_KEY ||
  (process.env.OPENROUTER_KEY_FILE ? fs.readFileSync(process.env.OPENROUTER_KEY_FILE, 'utf8') : '')).trim();
const MODEL = process.env.JEV_MODEL || 'typesafe/jev-1.13';
const UPSTREAM = process.env.JEV_URL || 'https://openrouter.ai/api/alpha/decisions';
const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), 'data');
const BUDGET_TOTAL = +(process.env.BUDGET_TOTAL_USD || 12);      // teto de toda a vida do deploy
const BUDGET_DAILY = +(process.env.BUDGET_DAILY_USD || 3);       // teto por dia (UTC)
const APP_DAILY = +(process.env.APP_DAILY_USD || 1);             // teto por app por dia
let APP_CAPS = {};                                                // tetos diários específicos: {"cidade": 2}
try { APP_CAPS = JSON.parse(process.env.APP_CAPS_JSON || '{}'); } catch { console.error('[gateway] APP_CAPS_JSON inválido'); }
const appCap = (app) => +(APP_CAPS[app] ?? APP_DAILY);
const RATE_PER_MIN = +(process.env.RATE_PER_MIN || 240);         // chamadas por IP por minuto
const MAX_QUESTIONS = 160;
const MAX_BODY = 600_000;

if (!KEY) { console.error('[gateway] OPENROUTER_API_KEY ausente'); process.exit(1); }
fs.mkdirSync(DATA_DIR, { recursive: true });
const STATS_FILE = path.join(DATA_DIR, 'stats.json');
const USAGE_FILE = path.join(DATA_DIR, 'usage.jsonl');

const today = () => new Date().toISOString().slice(0, 10);
let stats = { since: new Date().toISOString(), total: { calls: 0, questions: 0, cost: 0, input_tokens: 0, errors: 0, cached: 0 }, days: {}, apps: {} };
try { stats = { ...stats, ...JSON.parse(fs.readFileSync(STATS_FILE, 'utf8')) }; } catch {}
let dirty = false;
setInterval(() => { if (dirty) { dirty = false; fs.writeFile(STATS_FILE, JSON.stringify(stats), () => {}); } }, 3000).unref();

function appStats(app) {
  return (stats.apps[app] ||= { calls: 0, questions: 0, cost: 0, input_tokens: 0, errors: 0, cached: 0, lat: [], days: {} });
}
function dayStats(d = today()) { return (stats.days[d] ||= { calls: 0, cost: 0 }); }

// ---- limite por IP (token bucket) ----
const buckets = new Map();
function allow(ip) {
  if (!ip || ip.startsWith('server:')) return true;
  const now = Date.now();
  const cap = Math.max(20, RATE_PER_MIN / 3);
  let b = buckets.get(ip);
  if (!b) { b = { t: cap, at: now }; buckets.set(ip, b); }
  b.t = Math.min(cap, b.t + ((now - b.at) / 60000) * RATE_PER_MIN);
  b.at = now;
  if (b.t < 1) return false;
  b.t -= 1;
  return true;
}
setInterval(() => { const cut = Date.now() - 600000; for (const [k, b] of buckets) if (b.at < cut) buckets.delete(k); }, 60000).unref();

// ---- cache LRU opcional ----
const cache = new Map();
const CACHE_TTL = 30 * 60 * 1000;
function cacheGet(k) { const v = cache.get(k); if (!v) return null; if (Date.now() - v.at > CACHE_TTL) { cache.delete(k); return null; } cache.delete(k); cache.set(k, v); return v; }
function cacheSet(k, v) { cache.set(k, { ...v, at: Date.now() }); if (cache.size > 6000) cache.delete(cache.keys().next().value); }

function send(res, status, obj) {
  const s = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(s);
}

function readBody(req, res) {
  return new Promise((resolve, reject) => {
    let size = 0, grande = false; const chunks = [];
    req.on('data', c => {
      if (grande) return; // já estourou: descarta o resto
      size += c.length;
      if (size <= MAX_BODY) { chunks.push(c); return; }
      // responde o 413 antes de fechar (com req.destroy() na hora, o cliente via a conexão cortada)
      grande = true; chunks.length = 0;
      if (res && !res.headersSent) { res.setHeader('Connection', 'close'); res.once('finish', () => req.destroy()); }
      reject(Object.assign(new Error('payload grande demais'), { status: 413 }));
    });
    req.on('end', () => { if (grande) return; try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); } catch { reject(Object.assign(new Error('JSON inválido'), { status: 400 })); } });
    req.on('error', reject);
  });
}

function validQuestions(q) {
  if (!q || typeof q !== 'object' || Array.isArray(q)) return 'questions deve ser um objeto';
  const keys = Object.keys(q);
  if (!keys.length) return 'questions vazio';
  if (keys.length > MAX_QUESTIONS) return `máximo de ${MAX_QUESTIONS} perguntas por chamada`;
  for (const k of keys) {
    const v = q[k];
    if (!v || !['choice', 'score', 'noul'].includes(v.type)) return `pergunta "${k}": type deve ser choice|score|noul`;
    if (typeof v.instructions !== 'string' || !v.instructions.trim()) return `pergunta "${k}": instructions obrigatório`;
    if (v.type === 'choice' && (!v.criteria || typeof v.criteria !== 'object' || Array.isArray(v.criteria) || Object.keys(v.criteria).length < 2)) return `pergunta "${k}": choice precisa de criteria com 2+ opções`;
    if (v.type === 'score' && (!Array.isArray(v.criteria) || v.criteria.length < 2 || v.criteria.length > 10)) return `pergunta "${k}": score precisa de criteria (lista de 2 a 10 níveis)`;
  }
  return null;
}

async function upstream(body) {
  let lastErr;
  for (let attempt = 0; attempt < 2; attempt++) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 20000);
    const t0 = performance.now();
    try {
      const r = await fetch(UPSTREAM, {
        method: 'POST', signal: ctrl.signal,
        headers: { Authorization: `Bearer ${KEY}`, 'Content-Type': 'application/json', 'HTTP-Referer': 'https://jev.<DOMINIO>', 'X-Title': 'Jev Showcase' },
        body: JSON.stringify(body),
      });
      const ms = performance.now() - t0;
      const text = await r.text();
      let j; try { j = JSON.parse(text); } catch { j = { error: { message: text.slice(0, 300) } }; }
      if (r.ok && j.answers) return { j, ms };
      const msg = String(j?.error?.message || `upstream ${r.status}`);
      if (/<!DOCTYPE html|Attention Required|you have been blocked|cf-error/i.test(msg) || /<!DOCTYPE html/i.test(text)) {
        // a borda (Cloudflare) do provedor recusou o conteúdo por parecer um ataque — não é erro do modelo
        lastErr = Object.assign(new Error('bloqueado pela proteção do provedor'), { status: 403, code: 'upstream_blocked' });
        break;
      }
      lastErr = Object.assign(new Error(msg.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').slice(0, 240)), { status: r.status, upstream: j });
      if (!(r.status === 429 || r.status >= 500)) break;
    } catch (e) {
      lastErr = Object.assign(new Error(e.name === 'AbortError' ? 'timeout no Jev' : e.message), { status: 504 });
    } finally { clearTimeout(timer); }
    await new Promise(r => setTimeout(r, 350 + Math.random() * 300));
  }
  throw lastErr;
}


function pct(arr, p) { if (!arr.length) return null; const s = [...arr].sort((a, b) => a - b); return Math.round(s[Math.min(s.length - 1, Math.floor(p * s.length))]); }

async function decide(req, res) {
  const t0 = performance.now();
  let body;
  try { body = await readBody(req, res); } catch (e) { return send(res, e.status || 400, { ok: false, error: { code: 'bad_request', message: e.message } }); }
  const app = String(body.app || 'desconhecido').slice(0, 40);
  const ip = String(body.meta?.ip || req.socket.remoteAddress || '').slice(0, 80);
  const err = validQuestions(body.questions);
  if (err) return send(res, 400, { ok: false, error: { code: 'bad_request', message: err } });
  if (body.state === undefined || body.state === null) return send(res, 400, { ok: false, error: { code: 'bad_request', message: 'state obrigatório' } });

  const A = appStats(app); const D = dayStats(); const d = today();
  if (stats.total.cost >= BUDGET_TOTAL || D.cost >= BUDGET_DAILY || (A.days[d] || 0) >= appCap(app))
    return send(res, 429, { ok: false, error: { code: 'budget_exhausted', message: 'O orçamento de demonstração do Jev acabou por hoje. Volte amanhã!' } });
  if (!allow(ip)) return send(res, 429, { ok: false, error: { code: 'rate_limited', message: 'Muitas decisões por minuto vindas de você. Respira e tenta de novo em alguns segundos.' } });

  const payload = { model: body.model && String(body.model).startsWith('typesafe/') ? body.model : MODEL, state: body.state, questions: body.questions };
  const nq = Object.keys(body.questions).length;
  let ck = null;
  if (body.cache) {
    ck = crypto.createHash('sha1').update(JSON.stringify(payload)).digest('hex');
    const hit = cacheGet(ck);
    if (hit) {
      A.cached++; stats.total.cached++; dirty = true;
      return send(res, 200, { ok: true, cached: true, answers: hit.answers, model: hit.model, usage: hit.usage, cost: 0, latency_ms: 0, total_ms: Math.round(performance.now() - t0) });
    }
  }
  try {
    // conteúdo barrado pela borda do provedor (upstream_blocked, 403) sobe como erro amigável, sem nova tentativa
    const defanged = false;
    const up = await upstream(payload);
    const { j, ms } = up;
    if (defanged) { A.defanged = (A.defanged || 0) + 1; }
    const cost = +(j.usage?.cost || 0);
    const inTok = +(j.usage?.input_tokens || 0);
    stats.total.calls++; stats.total.questions += nq; stats.total.cost += cost; stats.total.input_tokens += inTok;
    D.calls++; D.cost += cost;
    A.calls++; A.questions += nq; A.cost += cost; A.input_tokens += inTok; A.days[d] = (A.days[d] || 0) + cost;
    A.lat.push(Math.round(ms)); if (A.lat.length > 400) A.lat.splice(0, A.lat.length - 400);
    dirty = true;
    fs.appendFile(USAGE_FILE, JSON.stringify({ ts: new Date().toISOString(), app, ip: crypto.createHash('sha1').update(ip).digest('hex').slice(0, 10), nq, in: inTok, cost, ms: Math.round(ms), model: j.model }) + '\n', () => {});
    if (ck) cacheSet(ck, { answers: j.answers, model: j.model, usage: j.usage });
    return send(res, 200, { ok: true, cached: false, defanged, answers: j.answers, model: j.model, usage: j.usage, cost, latency_ms: Math.round(ms), total_ms: Math.round(performance.now() - t0), id: j.id });
  } catch (e) {
    stats.total.errors++; A.errors++; dirty = true;
    fs.appendFile(USAGE_FILE, JSON.stringify({ ts: new Date().toISOString(), app, nq, error: e.message, status: e.status }) + '\n', () => {});
    const code = e.code === 'upstream_blocked' ? 'upstream_blocked' : e.status === 402 ? 'no_credits' : e.status === 429 ? 'upstream_busy' : 'upstream_error';
    const message = code === 'upstream_blocked' ? 'O provedor do modelo recusou este texto na borda (proteção anti-ataque). Tente reformular.'
      : code === 'no_credits' ? 'Os créditos de demonstração do Jev acabaram. Volte mais tarde!'
      : code === 'upstream_busy' ? 'O Jev está muito requisitado agora. Tente de novo em alguns segundos.'
      : 'O Jev não respondeu desta vez. Tente de novo.';
    return send(res, e.status === 400 ? 400 : 502, { ok: false, error: { code, message } });
  }
}

function statsView() {
  const d = today();
  const apps = {};
  for (const [name, a] of Object.entries(stats.apps)) apps[name] = { calls: a.calls, questions: a.questions, cost: +a.cost.toFixed(6), input_tokens: a.input_tokens, errors: a.errors, cached: a.cached, p50_ms: pct(a.lat, 0.5), p90_ms: pct(a.lat, 0.9), today_cost: +(a.days[d] || 0).toFixed(6) };
  const all = Object.values(stats.apps).flatMap(a => a.lat);
  return {
    model: MODEL, since: stats.since,
    total: { ...stats.total, cost: +stats.total.cost.toFixed(6), p50_ms: pct(all, 0.5), p90_ms: pct(all, 0.9) },
    today: { date: d, ...(stats.days[d] || { calls: 0, cost: 0 }) },
    budget: { total_usd: BUDGET_TOTAL, daily_usd: BUDGET_DAILY, app_daily_usd: APP_DAILY, app_caps: APP_CAPS, spent_total: +stats.total.cost.toFixed(6), spent_today: +((stats.days[d] || {}).cost || 0).toFixed(6) },
    apps,
  };
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try {
    if (req.method === 'POST' && url.pathname === '/v1/decide') return await decide(req, res);
    if (req.method === 'GET' && url.pathname === '/v1/stats') return send(res, 200, statsView());
    if (req.method === 'GET' && url.pathname === '/healthz') return send(res, 200, { ok: true, model: MODEL });
    send(res, 404, { ok: false, error: { code: 'not_found' } });
  } catch (e) {
    console.error('[gateway]', e);
    send(res, 500, { ok: false, error: { code: 'internal', message: e.message } });
  }
});
server.keepAliveTimeout = 65000;
server.listen(PORT, () => console.log(`[gateway] ouvindo em :${PORT} modelo=${MODEL} orçamento total=$${BUDGET_TOTAL} dia=$${BUDGET_DAILY} app/dia=$${APP_DAILY}`));
