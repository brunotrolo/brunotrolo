# Busca que Entende — exemplo real: uma frase de intenção com orçamento. As 6 chamadas da MESMA busca (1 de entendimento
# + 5 lotes de 24 produtos, em paralelo). `?fresh=1` desliga os caches (da página e do gateway): custo e latência reais.
import re
import urllib.parse

from comum import achar, estado, pct, pergunta, total_perguntas

TITULO = 'Busca que Entende'
Q = 'presente pra minha mãe que ama cozinhar até 200 reais'
URL = '/?fresh=1&q=' + urllib.parse.quote(Q)
VIEWPORT = (1180, 1000)  # colunas estreitas (recorte legível a 356 px), mas com o cabeçalho de cada coluna numa linha só
PRONTO = "() => !!window.__buscaLast && JevKit.inspector.calls.length >= 6 && document.querySelectorAll('#jevlist li').length > 0"
ASSENTAR_MS = 1200  # os resultados entram com animação
RECORTE = ['.panel-kw', '.panel-jev']  # as duas colunas lado a lado na tela, empilhadas aqui: o 1º resultado de cada busca
CSS_RECORTE = '#kwlist > li:nth-child(n+2), #jevlist > li:nth-child(n+2), #overbudget { display: none !important; }'  # só na foto

# rótulos que o próprio app mostra (apps/busca/server.mjs: CATEGORIAS, ROTULOS)
ROT_CAT = {'casa': 'Casa', 'jardim': 'Jardim', 'cozinha': 'Cozinha', 'eletronicos': 'Eletrônicos', 'esporte': 'Esporte', 'camping': 'Camping',
           'moda': 'Moda', 'beleza': 'Beleza', 'pet': 'Pet', 'brinquedos': 'Brinquedos', 'livros': 'Livros', 'papelaria': 'Papelaria',
           'bem_estar': 'Bem-estar', 'varias': 'Vários departamentos'}
ROT_PARA = {'mae': 'Para a mãe', 'pai': 'Para o pai', 'avos': 'Para os avós', 'parceiro': 'Para o par', 'crianca': 'Para criança',
            'bebe': 'Para bebê', 'adolescente': 'Para adolescente', 'amigo': 'Para amigo(a)', 'pet': 'Para o pet', 'eu_mesmo': 'Para você',
            'familia': 'Para a família', 'nao_informado': 'Não dá para saber'}
NIVEIS = {'0': '0 · Irrelevante', '1': '1 · Talvez', '2': '2 · Boa opção', '3': '3 · Perfeito'}


def escolher(calls):
    i = max(k for k, c in enumerate(calls) if c.get('label') == 'entendimento')
    return calls[i:i + 6]


def extra(pg):
    return pg.evaluate(r"""() => {
      const t = (n) => n ? n.innerText.replace(/\s+/g, ' ').trim() : null;
      const q = (s) => t(document.querySelector(s));
      return {
        pilulas: [...document.querySelectorAll('#understood .pill')].map(t),
        jev: [...document.querySelectorAll('#jevlist li')].map((li) => ({ id: li.dataset.id, nome: t(li.querySelector('.nm')),
          preco: t(li.querySelector('.price')), nivel: t(li.querySelector('.rel .tag')), p: t(li.querySelector('.rel .p')), kw: t(li.querySelector('.kwpos')) })),
        kw: [...document.querySelectorAll('#kwlist li.res')].map((li) => ({ id: li.dataset.id, nome: t(li.querySelector('.nm')),
          preco: t(li.querySelector('.price')), casou: t(li.querySelector('.kwpos')), jev: t(li.querySelector('.kwv')) })),
        jevcount: q('#jevcount'), kwcount: q('#kwcount'),
        overbudget: document.getElementById('overbudget').hidden ? null : q('#overbudget'),
        speed: q('#speed'),
      };
    }""")


def produtos(ex):
    """id → (nome, preço) a partir das linhas de produto que foram no estado de cada lote."""
    out = {}
    for c in ex['chamadas']:
        for pid, linha in ((c['request']['state'] or {}).get('produtos') or {}).items():
            nome = linha.split(' — ')[0]
            m = re.search(r'R\$ ([\d.]+,\d{2})', linha)
            out[pid] = (nome, float(m.group(1).replace('.', '').replace(',', '.')) if m else None, linha)
    return out


def nbsp(s):
    """'R$ 189,90' não quebra entre 'R$' e o valor."""
    return str(s).replace('R$ ', 'R$\u00a0')


def nota(ex, pid, nome):
    # a pergunta real (server.mjs): "Quão bem o produto pXXX atende ao pedido do cliente?"
    return pergunta(ex, pid, f'Quão bem este produto atende ao pedido?\n“{nome}”', n=2, rotulos=NIVEIS, tipo='nota de 0 a 3')


def montar(ex):
    e = ex.get('extra') or {}
    prods = produtos(ex)
    lista, kw = e.get('jev') or [], e.get('kw') or []
    top = lista[0]['id'] if lista else max(prods, key=lambda k: achar(ex, k)[1].get('score', 0))
    kw1 = kw[0]['id'] if kw else None
    top_nome = prods[top][0]
    nivel_top = (lista[0]['p'].split('nota')[-1].strip() if lista else '')
    perguntas = [
        pergunta(ex, 'para_quem', 'Para quem é?', rotulos=ROT_PARA, n=1),
        pergunta(ex, 'categoria', 'Qual departamento combina?', rotulos=ROT_CAT, n=1),
        nota(ex, top, top_nome),
    ]
    if kw1 and kw1 != top:
        perguntas.append(nota(ex, kw1, prods[kw1][0]))
    pil = [x.rsplit(' ', 1)[0].split(' ', 1)[-1] for x in e.get('pilulas') or []]  # '🎁 Presente 100%' → 'Presente'
    itens = ['Pílulas “O Jev entendeu”: ' + ', '.join(pil[:-1]) + (' e ' if len(pil) > 1 else '') + (pil[-1] if pil else '')
             + (' (valor lido pelo código)' if any(x.startswith('Até R$') for x in pil) else '')]
    if lista:
        itens.append(f'1º com o Jev: {top_nome}, {lista[0]["preco"]}, nota {nivel_top} de 3 ({lista[0]["kw"].replace("busca comum:", "na busca comum,")})')
    if kw1 and kw1 != top:
        casou = kw[0]['casou'].removeprefix('casou:').strip()
        itens.append(f'Busca comum: 1º é o “{kw[0]["nome"]}”, que casou com “{casou}” → o Jev dá “{kw[0]["jev"].split("Jev:")[-1].strip()}”')
    return {
        'entrada': {
            'titulo': 'A busca digitada',
            'texto': estado(ex)['pedido_do_cliente'],
            'campos': [('catálogo', '120 produtos, 24 por chamada, uma linha cada. Ex.:'),
                       ('', nbsp(prods[top][2] + ('\n' + prods[kw1][2] if kw1 and kw1 != top else '')))],
            'max_linhas_campo': 7,
            'nota': 'A frase vai inteira, sem filtro por palavra: 5 chamadas levam o catálogo e a 6ª só tenta entender a frase. Todas ao mesmo tempo.',
        },
        'jev': {
            'perguntas': perguntas,
            'mais': f'+ {total_perguntas(ex) - len(perguntas)} outras: as notas dos outros {len(prods) - (len(perguntas) - 2)} produtos,\ne intenção, ocasião e faixa de orçamento',
            'nota': 'O Jev dá nota a todos os 120 produtos, sem pré-filtro. Não faz contas: o valor “até 200 reais” é lido do texto por código.',
        },
        'saida': {
            'titulo': 'O que o Jev entendeu × a busca comum',
            'itens': [nbsp(x) for x in itens],
            'nota': 'A ordem é a nota do Jev; o que passa do orçamento (lido por código) vai para o fim. Todo texto da tela é nosso.',
        },
    }
