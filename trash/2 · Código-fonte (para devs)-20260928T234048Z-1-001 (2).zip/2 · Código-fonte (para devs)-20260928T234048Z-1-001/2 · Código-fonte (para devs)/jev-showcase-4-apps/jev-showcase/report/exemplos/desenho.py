"""Desenho do diagrama "entrada → Jev → saída" (SVG autônomo, 1440 px de largura).

Três colunas lado a lado: ① o que entra (o estado real enviado), ② o que o Jev decide (perguntas e
probabilidades reais) e ③ o que sai (o recorte da tela do app + o que cada decisão virou). Cada coluna termina
com uma explicação curta. O texto é quebrado por uma estimativa de largura da fonte do sistema.
"""
import base64
import html
import math

FONTE = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif"
MONO = "ui-monospace, 'SF Mono', Menlo, Consolas, monospace"
e = html.escape

W, M, GAP = 1440, 24, 72
COLS = [352, 504, 392]
X = [M, M + COLS[0] + GAP, M + COLS[0] + GAP + COLS[1] + GAP]
TOPO, PAD = 84, 18

# larguras aproximadas (em "em") da fonte do sistema; o fator dá folga para Segoe UI e Roboto
ESTREITAS, MEIAS, LARGAS = set("il.,;:!|'’`ìíîïI()[]{} "), set('fjrtJ-/\\"“”'), set('mwMW%@')


def larg(s, tam, peso=400):
    tot = 0.0
    for ch in s:
        if ch in ESTREITAS:
            tot += 0.28
        elif ch in MEIAS:
            tot += 0.36
        elif ch in LARGAS:
            tot += 0.84
        elif ch.isupper():
            tot += 0.66
        elif ch.isdigit():
            tot += 0.57
        elif ord(ch) > 0x2000:  # emoji e símbolos
            tot += 1.1
        else:
            tot += 0.53
    return tot * tam * (1.07 if peso >= 700 else 1.03 if peso >= 600 else 1.0) * 1.04


def quebrar(s, tam, largura, peso=400, max_linhas=None):
    linhas = []
    for par in str(s).split('\n'):
        atual = ''
        for pal in par.split(' '):
            tent = (atual + ' ' + pal).strip()
            if atual and larg(tent, tam, peso) > largura:
                linhas.append(atual)
                atual = pal
            else:
                atual = tent
        linhas.append(atual)
    linhas = [l for l in linhas if l != ''] or ['']
    if max_linhas and len(linhas) > max_linhas:
        linhas = linhas[:max_linhas]
        ult = linhas[-1]
        while ult and larg(ult + '…', tam, peso) > largura:
            ult = ult[:-1]
        linhas[-1] = ult.rstrip(' ,;:') + '…'
    return linhas


def cortar(s, tam, largura, peso=400):
    s = str(s)
    if larg(s, tam, peso) <= largura:
        return s
    while s and larg(s + '…', tam, peso) > largura:
        s = s[:-1]
    return s.rstrip() + '…'


def txt(x, y, s, tam=13, cor='#e5e7eb', peso=400, anc='start', fam=None, extra=''):
    f = f' font-family="{fam}"' if fam else ''
    return f'<text x="{x:.1f}" y="{y:.1f}" font-size="{tam}" fill="{cor}" font-weight="{peso}" text-anchor="{anc}"{f}{extra}>{e(s)}</text>'


# os 3 tipos de pergunta do Jev: símbolo, nome e cor (as mesmas do visualizador de chamadas, shared/ui/jev-chamadas.js)
TIPOS = [('choice', '◉', 'escolha', '#67e8f9'), ('score', '▮', 'nota', '#fbbf24'), ('noul', '◐', 'sim/não', '#c4b5fd')]


def contar_tipos(ex):
    n = {'choice': 0, 'score': 0, 'noul': 0}
    for ch in ex['chamadas']:
        for q in ((ch.get('request') or {}).get('questions') or {}).values():
            if isinstance(q, dict) and q.get('type') in n:
                n[q['type']] += 1
    return n


def tipo_da_etiqueta(t):
    t = str(t).lower()
    return 'noul' if t.startswith('sim') else 'score' if t.startswith('nota') else 'choice' if t.startswith('escolha') else None


def pct(p):
    if p is None:
        return '—'
    v = p * 100
    return f'{v:.0f}%' if v >= 1 or v == 0 else '<1%'


def br(v, casas=2):
    return f'{v:,.{casas}f}'.replace(',', 'X').replace('.', ',').replace('X', '.')


class Coluna:
    """Acumula elementos com y relativo ao topo interno do cartão e mede a altura."""

    def __init__(self, i):
        self.x = X[i] + PAD
        self.w = COLS[i] - 2 * PAD
        self.y = 0.0
        self.el = []  # (y_rel, função que recebe y_abs e devolve svg)

    def add(self, altura, fn):
        y0 = self.y
        self.el.append((y0, fn))
        self.y += altura
        return y0

    def espaco(self, h):
        self.y += h

    def desenhar(self, topo):
        return ''.join(fn(topo + y0) for y0, fn in self.el)


def bloco_titulo(col, s, cor='#cbd5e1'):
    col.add(22, lambda y: txt(col.x, y + 14, s.upper(), 11.5, cor, 800, extra=' letter-spacing=".08em"'))


def bloco_nota(col_w, x, s):
    linhas = quebrar(s, 12.5, col_w)
    h = 14 + 18 * len(linhas)

    def fn(y):
        out = [f'<line x1="{x}" y1="{y:.1f}" x2="{x + col_w}" y2="{y:.1f}" stroke="rgba(255,255,255,.12)"/>']
        out += [txt(x, y + 26 + i * 18, l, 12.5, '#a3aab8') for i, l in enumerate(linhas)]
        return ''.join(out)
    return h, fn


def barra(x, y, w, p, destaque):
    wf = max(2.0, w * max(0.0, min(1.0, p or 0)))
    cor = 'url(#gb)' if destaque else '#4b5563'
    return (f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="8" rx="4" fill="rgba(255,255,255,.07)"/>'
            f'<rect x="{x:.1f}" y="{y:.1f}" width="{wf:.1f}" height="8" rx="4" fill="{cor}"/>')


def svg_exemplo(meta, c, ex, jpg=None, prod=None):
    """meta: {id, titulo, emoji}; c: conteúdo de montar(ex); jpg: bytes do recorte; prod: {'p50_ms': …} medido em produção."""
    ent, jev, sai = c['entrada'], c['jev'], c['saida']

    # ---------------------------------------------------------------- ① entrada
    c1 = Coluna(0)
    bloco_titulo(c1, ent.get('titulo', 'O que chega'))
    if ent.get('texto'):
        linhas = quebrar('“' + ent['texto'].strip() + '”', 14.5, c1.w - 14, max_linhas=ent.get('max_linhas', 11))
        c1.add(8 + 22 * len(linhas), lambda y, L=linhas: (
            f'<rect x="{c1.x}" y="{y + 4:.1f}" width="3" height="{22 * len(L) - 4}" rx="1.5" fill="#94a3b8"/>'
            + ''.join(txt(c1.x + 14, y + 19 + i * 22, l, 14.5, '#f3f4f6') for i, l in enumerate(L))))
        c1.espaco(6)
    campos = ent.get('campos', [])
    kw = min(124, max(64, max((larg(str(k), 11.5, 700) for k, _ in campos), default=0) + 14))  # coluna do rótulo cabe o maior rótulo
    for k, v in campos:
        vl = quebrar(str(v), 13, c1.w - kw, max_linhas=ent.get('max_linhas_campo', 3))
        c1.add(8 + 19 * len(vl), lambda y, k=k, vl=vl: (
            txt(c1.x, y + 17, cortar(k, 11.5, kw - 8, 700), 11.5, '#94a3b8', 700)
            + ''.join(txt(c1.x + kw, y + 17 + i * 19, l, 13, '#e5e7eb', fam=MONO if ent.get('mono') else None) for i, l in enumerate(vl))))

    # ---------------------------------------------------------------- ② jev
    c2 = Coluna(1)
    n_ch = len(ex['chamadas'])
    n_q = sum(ch.get('n_questions') or 0 for ch in ex['chamadas'])
    custo = sum(ch.get('cost') or 0 for ch in ex['chamadas'])
    chips = [f'{n_ch} chamada{"s" if n_ch > 1 else ""}' + (' em paralelo' if n_ch > 1 and jev.get('paralelo', True) else ''),
             f'{n_q} pergunta{"s" if n_q != 1 else ""}', f'US$ {br(custo, 6 if custo < 0.001 else 4)}']
    if prod and prod.get('p50_ms'):  # mediana medida no gateway de produção (do app, ou a geral do Jev se o app tem poucas chamadas)
        chips.append(f'~{br(prod["p50_ms"] / 1000, 2)} s ' + ('por chamada' if prod.get('geral') else 'em produção'))
    if jev.get('chips'):
        chips = jev['chips']

    def cab(y):
        out = [txt(c2.x, y + 24, '⚡ JEV', 23, 'url(#gj)', 900, extra=' letter-spacing=".14em"')]
        cx = c2.x + 110
        linha = 0
        for ch in chips:
            w = larg(ch, 11.5, 700) + 18
            if cx + w > c2.x + c2.w:
                linha += 1
                cx = c2.x + 110
            yy = y + 8 + linha * 26
            out.append(f'<rect x="{cx:.1f}" y="{yy:.1f}" width="{w:.1f}" height="21" rx="10.5" fill="rgba(34,211,238,.10)" stroke="rgba(34,211,238,.45)"/>')
            out.append(txt(cx + w / 2, yy + 14.5, ch, 11.5, '#a5f3fc', 700, 'middle'))
            cx += w + 6
        return ''.join(out)
    # quantas linhas de selos: mesma conta do desenho
    cx, linhas_chip = c2.x + 110, 1
    for ch in chips:
        w = larg(ch, 11.5, 700) + 18
        if cx + w > c2.x + c2.w:
            linhas_chip += 1
            cx = c2.x + 110
        cx += w + 6
    c2.add(max(40, 12 + 26 * linhas_chip) + 8, cab)

    # os 3 tipos usados neste exemplo (os que não aparecem ficam apagados)
    n_tipos = contar_tipos(ex)

    def faixa_tipos(y):
        out = [txt(c2.x, y + 14, 'TIPOS', 10.5, '#9ca3af', 800, extra=' letter-spacing=".12em"')]
        cx = c2.x + 52
        for t, simb, nome, cor in TIPOS:
            rot = f'{simb} {n_tipos[t]} {nome}'
            w = larg(rot, 11.5, 700) + 18
            op = '1' if n_tipos[t] else '.35'
            out.append(f'<g opacity="{op}"><rect x="{cx:.1f}" y="{y:.1f}" width="{w:.1f}" height="21" rx="10.5" fill="none" stroke="{cor}" stroke-opacity=".7"/>'
                       + txt(cx + w / 2, y + 14.5, rot, 11.5, cor, 700, 'middle') + '</g>')
            cx += w + 6
        return ''.join(out)
    c2.add(32, faixa_tipos)

    ROT_W, PCT_W = 196, 44
    for q in jev['perguntas']:
        tq = tipo_da_etiqueta(q.get('tipo', ''))
        simb, cor_t = next(((sb, cr) for t, sb, _, cr in TIPOS if t == tq), ('', '#c4b5fd'))
        tipo = (simb + ' ' if simb else '') + q.get('tipo', '')
        tw = larg(tipo, 11, 700) + 16
        rl = quebrar(q['rotulo'], 14, c2.w - tw - 18, 700, max_linhas=2)

        def cabq(y, rl=rl, tipo=tipo, tw=tw, cor_t=cor_t):
            out = [txt(c2.x, y + 16 + i * 19, l, 14, '#f9fafb', 700) for i, l in enumerate(rl)]
            out.append(f'<rect x="{c2.x + c2.w - tw:.1f}" y="{y + 3:.1f}" width="{tw:.1f}" height="18" rx="9" fill="none" stroke="{cor_t}" stroke-opacity=".7"/>')
            out.append(txt(c2.x + c2.w - tw / 2, y + 15.5, tipo, 11, cor_t, 700, 'middle'))
            return ''.join(out)
        c2.add(8 + 19 * len(rl), cabq)
        linhas = [('sim', q['sim'])] if 'sim' in q else q.get('opcoes', [])
        for i, (rot, p) in enumerate(linhas):
            dest = i == 0

            def lin(y, rot=rot, p=p, dest=dest):
                cor = '#f3f4f6' if dest else '#9ca3af'
                return (txt(c2.x + 2, y + 15, cortar(rot, 12.5, ROT_W - 10, 700 if dest else 400), 12.5, cor, 700 if dest else 400)
                        + barra(c2.x + ROT_W, y + 7, c2.w - ROT_W - PCT_W, p, dest)
                        + txt(c2.x + c2.w, y + 15, pct(p), 12.5, '#67e8f9' if dest else '#9ca3af', 700 if dest else 400, 'end', MONO))
            c2.add(21, lin)
        c2.espaco(12)
    if jev.get('mais'):
        ml = quebrar(jev['mais'], 12.5, c2.w, 600)
        c2.add(4 + 18 * len(ml), lambda y, ml=ml: ''.join(txt(c2.x, y + 13 + i * 18, l, 12.5, '#67e8f9', 600) for i, l in enumerate(ml)))

    # ---------------------------------------------------------------- ③ saída
    c3 = Coluna(2)
    bloco_titulo(c3, sai.get('titulo', 'O que o app faz'))
    if jpg:
        rw, rh = ex.get('recorte', {}).get('w', 840), ex.get('recorte', {}).get('h', 400)
        iw = c3.w
        ih = min(sai.get('altura_max', 250), iw * rh / rw)
        b64 = base64.b64encode(jpg).decode()

        def img(y, iw=iw, ih=ih, b64=b64):
            cid = f'rc-{meta["id"]}'
            return (f'<clipPath id="{cid}"><rect x="{c3.x}" y="{y + 2:.1f}" width="{iw:.1f}" height="{ih:.1f}" rx="10"/></clipPath>'
                    f'<image x="{c3.x}" y="{y + 2:.1f}" width="{iw:.1f}" height="{ih:.1f}" preserveAspectRatio="xMidYMin slice" clip-path="url(#{cid})" href="data:image/jpeg;base64,{b64}"/>'
                    f'<rect x="{c3.x}" y="{y + 2:.1f}" width="{iw:.1f}" height="{ih:.1f}" rx="10" fill="none" stroke="rgba(255,255,255,.18)"/>')
        c3.add(ih + 14, img)
    for it in sai.get('itens', []):
        il = quebrar(it, 13, c3.w - 18, max_linhas=3)
        c3.add(5 + 18 * len(il), lambda y, il=il: (
            txt(c3.x, y + 14, '▸', 13, '#34d399', 700) + ''.join(txt(c3.x + 16, y + 14 + i * 18, l, 13, '#e5e7eb') for i, l in enumerate(il))))

    # ---------------------------------------------------------------- notas e altura comum
    notas = [bloco_nota(COLS[i] - 2 * PAD, X[i] + PAD, s) for i, s in enumerate([ent.get('nota', ''), jev.get('nota', ''), sai.get('nota', '')])]
    corpo = max(c1.y + notas[0][0], c2.y + notas[1][0], c3.y + notas[2][0]) + 18
    H_CARD = PAD + corpo + PAD - 8
    H = int(TOPO + H_CARD + 26)

    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" role="img" aria-labelledby="t-{meta["id"]} d-{meta["id"]}" font-family="{e(FONTE)}">',
           f'<title id="t-{meta["id"]}">Como o Jev decide · {e(meta["titulo"])}</title>',
           f'<desc id="d-{meta["id"]}">{e(resumo_texto(c, ex))}</desc>',
           '<defs><linearGradient id="gj" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#22d3ee"/><stop offset="1" stop-color="#a78bfa"/></linearGradient>'
           '<linearGradient id="gb" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#22d3ee"/><stop offset="1" stop-color="#a78bfa"/></linearGradient>'
           '<linearGradient id="gf" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#22d3ee" stop-opacity=".14"/><stop offset="1" stop-color="#a78bfa" stop-opacity=".10"/></linearGradient>'
           '<filter id="glow" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="10"/></filter>'
           '<marker id="seta" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="8" markerHeight="8" orient="auto"><path d="M0 0 10 5 0 10z" fill="#67e8f9"/></marker></defs>',
           f'<rect width="{W}" height="{H}" fill="#0b0e15"/>']
    # cabeçalhos das colunas
    cabs = [('1', 'Entrada', 'o que o app manda para o Jev', '#94a3b8'), ('2', 'O Jev decide', 'perguntas tipadas → probabilidades', 'url(#gj)'),
            ('3', 'Saída', 'o que o app faz com as respostas', '#34d399')]
    for i, (n, t, s, cor) in enumerate(cabs):
        x = X[i]
        out.append(f'<circle cx="{x + 14}" cy="{38}" r="14" fill="{cor}"/>')
        out.append(txt(x + 14, 43, n, 14, '#0b0e15', 900, 'middle'))
        out.append(txt(x + 38, 36, t.upper(), 15, '#f3f4f6', 900, extra=' letter-spacing=".08em"'))
        out.append(txt(x + 38, 56, s, 12.5, '#9ca3af'))
    # cartões
    for i in (0, 2):
        cor = '#94a3b8' if i == 0 else '#34d399'
        out.append(f'<rect x="{X[i]}" y="{TOPO}" width="{COLS[i]}" height="{H_CARD:.1f}" rx="16" fill="rgba(255,255,255,.035)" stroke="{cor}" stroke-opacity=".45" stroke-width="1.5"/>')
    out.append(f'<rect x="{X[1]}" y="{TOPO}" width="{COLS[1]}" height="{H_CARD:.1f}" rx="18" fill="#22d3ee" opacity=".16" filter="url(#glow)"/>')
    out.append(f'<rect x="{X[1]}" y="{TOPO}" width="{COLS[1]}" height="{H_CARD:.1f}" rx="18" fill="#0b1220"/>')
    out.append(f'<rect x="{X[1]}" y="{TOPO}" width="{COLS[1]}" height="{H_CARD:.1f}" rx="18" fill="url(#gf)" stroke="url(#gj)" stroke-width="2.4"/>')
    # setas entre as colunas
    ya = TOPO + min(150, H_CARD / 2)
    for i, rot in ((0, ['estado', '+ perguntas']), (1, ['respostas'])):
        x0, x1 = X[i] + COLS[i] + 8, X[i + 1] - 8
        out.append(f'<path d="M{x0},{ya:.1f} L{x1 - 2},{ya:.1f}" stroke="#67e8f9" stroke-width="2.4" marker-end="url(#seta)"/>')
        for k, r in enumerate(rot):
            out.append(txt((x0 + x1) / 2, ya - 12 - (len(rot) - 1 - k) * 14, r, 11, '#a5f3fc', 600, 'middle'))
    topo_int = TOPO + PAD
    out += [c1.desenhar(topo_int), c2.desenhar(topo_int), c3.desenhar(topo_int)]
    for i, (h, fn) in enumerate(notas):
        out.append(fn(TOPO + H_CARD - PAD - h + 4))
    out.append('</svg>')
    return '\n'.join(out), W, H, [X[1], TOPO, COLS[1], round(H_CARD, 1)]


def resumo_texto(c, ex):
    """Texto alternativo: a mesma história do desenho, para leitores de tela."""
    partes = [f"Entrada: {c['entrada'].get('titulo', '')}. " + (c['entrada'].get('texto') or '')[:300]]
    for q in c['jev']['perguntas']:
        if 'sim' in q:
            partes.append(f"{q['rotulo']} sim {pct(q['sim'])}")
        elif q.get('opcoes'):
            r, p = q['opcoes'][0]
            partes.append(f"{q['rotulo']} {r} ({pct(p)})")
    partes.append('Saída: ' + '; '.join(c['saida'].get('itens', [])))
    return ' · '.join(partes)
