# Exemplos reais para os diagramas "entrada → Jev → saída"

> **Neste pacote:** o `report/build_arquiteturas.py` não vem junto (veja o README da raiz). Os diagramas prontos estão em `shared/ui/diagramas/`; o `capturar.py` e o `previa.py` funcionam sozinhos.

Cada app tem um diagrama em 3 colunas, gerado por `report/build_arquiteturas.py` com `report/exemplos/desenho.py`:

1. **Entrada**: o estado que o app mandou ao Jev, num exemplo real (texto entre aspas e/ou pares rótulo → valor).
2. **O Jev decide**: 3 ou 4 perguntas daquela chamada, com as opções mais prováveis e as probabilidades reais.
3. **Saída**: um recorte da tela do app com o resultado + 2 a 4 linhas dizendo o que cada decisão virou.

Cada coluna termina com uma explicação curta (`nota`). Nada é inventado: o exemplo sai de uma execução real do
app, capturada do inspetor (`JevKit.inspector.calls`, que guarda o estado, as perguntas e as respostas).

## Arquivos

| arquivo | o que é |
|---|---|
| `capturar.py` | sobe o app localmente (porta 5100 + posição em `apps.json`) contra o gateway local `:8797`, com `JEV_DEBUG_FULL=1` (estado e respostas inteiros), abre no Chromium headless, dispara o exemplo, grava `dados/<id>.json` e o recorte `dados/<id>.jpg` |
| `previa.py` | desenha só o diagrama de um app: `scratch/exemplos-run/previa-<id>.png` (confira sempre este PNG) |
| `comum.py` | ajudantes: `pergunta()`, `opcoes()`, `sim()`, `escolha()`, `nota()`, `estado()`, `pct()`, `total_perguntas()` |
| `desenho.py` | o desenho (não mude sem combinar: vale para todos os apps) |
| `apps/<id>.py` | a receita de cada app (captura + conteúdo). Referências: `apps/golpe.py` (1 chamada) e `apps/estudio.py` (5 chamadas) |

## Receita (`apps/<id>.py`)

Captura (lida por `capturar.py`):
- `URL` — caminho + query no app local (ex.: `'/?texto=' + urllib.parse.quote(TEXTO)`). Prefira os atalhos de URL do app.
- `acoes(pg)` — opcional: cliques/digitação com Playwright, se o app não tiver atalho de URL.
- `PRONTO` — função JS (string) que devolve verdadeiro quando o exemplo terminou (ex.: resultado visível e `JevKit.inspector.calls.length > 0`).
- `escolher(calls)` — opcional: quais chamadas do inspetor viram o exemplo (padrão: a última). Várias chamadas da MESMA rodada podem entrar (como no estudio).
- `RECORTE` — seletor CSS da região que mostra a saída; ou uma lista de seletores (empilhados); item da lista pode ser `(seletor, altura_max_css)`.
  O recorte aparece com 356 px de largura e no máximo 250 px de altura no diagrama: prefira regiões largas (proporção entre 1,3:1 e 2,5:1).
- Opcionais: `VIEWPORT=(w,h)`, `INIT` (script injetado antes da página), `ARGS` (Chromium), `ENV` (variáveis do servidor), `ESPERA_S`, `ASSENTAR_MS`, `MARGEM`, `CSS_RECORTE` (CSS extra só na hora da foto), `extra(pg)` (textos lidos da página, gravados em `ex['extra']`),
  `WAIT_UNTIL` (`'load'` em app com SSE aberto: o `'networkidle'` padrão nunca chega), `DADOS='outro_id'` (usa a captura de outro app; é o caso da visão geral, `plataforma.py`).
- Chamadas feitas no servidor (cidade, qa, tron) não passam pelo inspetor sozinhas: a receita as injeta no inspetor (ex.: marcadas com `__alvo`) e filtra em `escolher()`.
- Opções do conteúdo em `montar()`: `jev.paralelo=False` (o selo não diz "em paralelo"), `jev.chips=[...]` (troca os selos), `entrada.mono`, `entrada.max_linhas`, `entrada.max_linhas_campo`, `saida.altura_max` (altura máxima do recorte, padrão 250).

Conteúdo (lido pelo gerador): `TITULO` e `montar(ex) -> dict`:

```python
{'entrada': {'titulo': 'A mensagem colada', 'texto': '...', 'campos': [('rótulo', 'valor'), ...], 'mono': False,
             'nota': '1 ou 2 frases: de onde vem e o que o app manda'},
 'jev': {'perguntas': [pergunta(ex, 'qid', 'Pergunta curta?', n=3, rotulos={...}), ...],   # 3 ou 4 perguntas
         'mais': '+ N outras: ...', 'nota': '1 ou 2 frases: o papel do Jev aqui'},
 'saida': {'titulo': 'O veredito na tela', 'itens': ['decisão → efeito', ...], 'nota': '1 ou 2 frases'}}
```

Regras de conteúdo:
- **Tudo real**: números, escolhas e textos da saída vêm de `ex` (calcule a partir das respostas, não digite valores).
- Português do Brasil com acentos; frases curtas e concretas; sem jargão (nada de "state", "payload", "noul": diga "sim ou não").
- Rótulos de opção sem acento vindos da chave (ex.: `Nao responder`) são proibidos: passe `rotulos={...}` com os rótulos que o próprio app mostra.
- A explicação diz a verdade do código do app (leia `apps/<id>/server.mjs` e o README do app): o que é decisão do Jev e o que é regra/código/texto nosso.
- Escolha perguntas que contam a história do app (a decisão principal primeiro), e um exemplo que mostre o Jev fazendo algo que regra fixa não faria.

## Como rodar

```bash
# gateway local (uma vez): OPENROUTER_KEY_FILE=.secrets/openrouter_key PORT=8797 DATA_DIR=scratch/gw-ex node gateway/server.mjs
python3 report/exemplos/capturar.py <id>     # ~5–60 s por app
python3 report/exemplos/previa.py <id>       # confira scratch/exemplos-run/previa-<id>.png
```
