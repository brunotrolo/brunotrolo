# Planilha Preditiva — exemplo real: a coluna "Quer comprar?" criada nos 124 leads do Instagram
# (6 chamadas em paralelo, 21 linhas por chamada, uma pergunta de sim ou não por linha)
import re
import urllib.parse

from comum import estado, pct, pergunta, sim

TITULO = 'Planilha Preditiva'
COLUNA = 'Quer comprar?'
URL = '/?planilha=leads&coluna=' + urllib.parse.quote(COLUNA)
PRONTO = """() => !!document.querySelector('#status[data-state="pronto"]') && JevKit.inspector.calls.some((c) => /^lote /.test(c.label || ''))"""
ASSENTAR_MS = 1200  # as células entram em onda (até 0,6 s)

# linhas contadas no exemplo (dados semente de apps/planilha/data/leads.json) e os trechos da própria mensagem que
# vão no rótulo da pergunta (montar() confere que cada trecho está mesmo na mensagem):
# compra sem a palavra "comprar" · gíria · diz "comprei", mas é reclamação · ambígua
LINHAS = [('r4', ['garantir minha vaga']), ('r9', ['me vê 1 acesso', 'kkkk']),
          ('r25', ['comprei', 'quero meu dinheiro de volta']), ('r5', ['valor???'])]

# Na foto: some com Nome, Cidade e Seguidores (células e <col>, para as larguras continuarem alinhadas) e encurta a
# mensagem, para o recorte ficar legível: # · Mensagem na DM · Quer comprar?
CSS_RECORTE = ('#grid tr > :nth-child(2), #grid tr > :nth-child(3), #grid tr > :nth-child(4),'
               '#cols col:nth-child(2), #cols col:nth-child(3), #cols col:nth-child(4) { display: none !important }'
               '#cols col:nth-child(5) { width: 430px !important }'
               # layout fixo precisa de largura explícita: # (44) + mensagem (430) + Jev (150) + nova coluna (232)
               '#grid { width: 856px !important; min-width: 0 !important }')


def RECORTE(pg):
    """Da borda do # até o fim da coluna do Jev, do cabeçalho até a linha 9."""
    b = pg.evaluate("""() => {
      const g = document.getElementById('grid').getBoundingClientRect();
      const ai = document.querySelector('#grid th.ai').getBoundingClientRect();
      const top = document.querySelector('#grid thead').getBoundingClientRect();
      const fim = document.querySelector('#grid tr[data-rid="r9"]').getBoundingClientRect();
      return { x: g.left, y: top.top, w: ai.right - g.left, h: fim.bottom - top.top };
    }""")
    m = 6
    return pg.screenshot(type='png', clip={'x': max(0, b['x'] - m), 'y': max(0, b['y'] - m), 'width': b['w'] + 2 * m,
                                          'height': b['h'] + 2 * m}, animations='disabled')


def extra(pg):
    return pg.evaluate("""() => ({
      tipo: document.querySelector('#status .l1').innerText.trim(),
      numeros: document.querySelector('#status .l2').innerText.replace(/\\s+/g, ' ').trim(),
      cabecalho: document.querySelector('#grid th.ai .aih-type').innerText.replace(/\\s+/g, ' ').trim(),
    })""")


def escolher(calls):
    """As chamadas de lote desta coluna, na ordem das linhas (lote 1 = r1…r21)."""
    lotes = [c for c in calls if re.match(r'lote \d+/\d+ · ', c.get('label') or '')]
    return sorted(lotes, key=lambda c: int(re.match(r'lote (\d+)', c['label']).group(1)))


def _linha(ex, rid):
    for c in ex['chamadas']:
        ls = c['request']['state'].get('linhas') or {}
        if rid in ls:
            return ls[rid]
    raise KeyError(rid)


def _num(rid):
    return rid[1:]


def _rotulo(ex, rid, trechos):
    msg = _linha(ex, rid)['Mensagem na DM']
    assert all(t in msg for t in trechos), f'trecho fora da mensagem de {rid}: {trechos}'
    return f'Linha {_num(rid)} (“{"… ".join(trechos)}”) quer comprar?'


def montar(ex):
    st = estado(ex)
    probs = {k: a['noul'] for c in ex['chamadas'] for k, a in c['response']['answers'].items() if a.get('type') == 'noul'}
    n = len(probs)
    n_sim = sum(p >= 0.7 for p in probs.values())
    n_meio = sum(0.3 < p < 0.7 for p in probs.values())
    n_nao = n - n_sim - n_meio
    mostradas = {r for r, _ in LINHAS}
    n_sim_outras = sum(p >= 0.7 for r, p in probs.items() if r not in mostradas)
    por_chamada = max(len(c['request']['state']['linhas']) for c in ex['chamadas'])
    nums = ex['extra'].get('numeros', '')
    tempo = re.search(r'linhas em ([\d,]+ s)', nums)
    custo = re.search(r'custo (US\$ [\d,]+)', nums)
    dezmil = re.search(r'10 mil linhas custariam (US\$ [\d,]+)', nums)
    p4, p25, p5 = sim(ex, 'r4'), sim(ex, 'r25'), sim(ex, 'r5')
    # o servidor corta células longas (com "…") quando a planilha estoura o orçamento de texto por coluna
    inteiras = not any(str(v).endswith('…') for c in ex['chamadas'] for l in c['request']['state']['linhas'].values() for v in l.values())
    return {
        'entrada': {
            'titulo': 'O título da coluna e as linhas',
            'texto': COLUNA,
            'campos': [('planilha', f'{st["planilha"]} · {n} linhas'),
                       ('contexto', '…' + st['contexto'][st['contexto'].find('vende'):])]
                      + [(f'linha {_num(r)}', '“' + _linha(ex, r)['Mensagem na DM'] + '”') for r, _ in LINHAS],
            'max_linhas_campo': 4,
            'nota': f'Termina com “?”, então vira sim ou não (regra nossa, sem Jev). Cada chamada leva {por_chamada} linhas '
                    f'{"inteiras " if inteiras else ""}(nome, cidade, seguidores e mensagem) e uma pergunta por linha.',
        },
        'jev': {
            'perguntas': [pergunta(ex, r, _rotulo(ex, r, t)) for r, t in LINHAS],
            'mais': f'+ {n - len(LINHAS)} outras linhas, a mesma pergunta em cada uma: {n_sim_outras} acima de 70%',
            'nota': f'O Jev lê a intenção, não a palavra: sem “comprar”, a linha 4 dá {pct(p4)}; com “comprei”, '
                    f'a 25 dá {pct(p25)}.' + (' Quando o texto não basta, a resposta fica no meio.' if 0.3 < p5 < 0.7 else ''),
        },
        'saida': {
            'titulo': 'A coluna preenchida',
            'itens': [
                f'≥ 70% → ✓ verde ({n_sim} linhas) · ≤ 30% → ✗ ({n_nao}) · no meio → “?” com a % ({n_meio})',
                f'{n} linhas em {tempo.group(1) if tempo else "—"} por {custo.group(1) if custo else "—"}'
                + (f' → 10 mil linhas custariam {dezmil.group(1)}' if dezmil else ''),
                'Clique no título: quem quer comprar sobe para o topo',
            ],
            'nota': 'Os cortes de 70% e 30%, as cores e a ordenação são código nosso. O Jev só deu a chance de “sim” de cada linha.',
        },
    }
