# Site que Lê Intenções (versão genérica) — exemplo real: a primeira simulação do site.json que captura um "Para você"
# numa lista. A captura acontece no momento em que o Jev põe os itens "Para você" no topo dessa lista.
import json
import pathlib
from comum import estado, pergunta, opcoes, pct, total_perguntas

SITE = json.loads((pathlib.Path(__file__).resolve().parents[3] / 'apps' / 'site' / 'public' / 'dados' / 'site.json').read_text())
SIM = next((s for s in SITE['simulacoes'] if s.get('captura', '').startswith('pins:')), SITE['simulacoes'][0])
LISTA = SIM.get('captura', 'pins:')[5:] if SIM.get('captura', '').startswith('pins:') else ''
POR = {s['id']: s for s in SITE['secoes']}
TRI = next(s for s in SITE['secoes'] if s['tipo'] == 'trilhas')

TITULO = 'Site que Lê Intenções'
URL = '/?sim=' + SIM['id']
WAIT_UNTIL = 'load'
ESPERA_S = 180
ASSENTAR_MS = 1800
PRONTO = "() => !!(window.jevUx && window.jevUx.adaptacoes.some((a) => a.tipo === 'pins'" + (f" && a.secao === '{LISTA}'" if LISTA else '') + '))'
CSS_RECORTE = '#fantasma,#fantasmaRot{display:none!important}'


def extra(pg):
    return pg.evaluate("() => ({ cta: (window.jevUx.estado().cta || '').replace(/\\s+/g, ' ').trim() })")


def escolher(calls):
    # a decisão que pôs os itens "Para você": a última chamada com a pergunta de destaque
    com = [c for c in calls if 'destaque' in (((c.get('request') or {}).get('questions')) or {})]
    return com[-1:] or calls[-1:]


def RECORTE(pg):
    # a tela como a pessoa vê (lista com "Para você" + Lente do Jev + Sua trilha), sem a barra do topo
    return pg.screenshot(type='png', clip={'x': 96, 'y': 62, 'width': 1248, 'height': 800}, animations='disabled')


ROT_PERFIL = {**{p['id']: p['rotulo'] for p in SITE['jev']['perfis']}, 'indefinido': 'Ainda explorando'}
ROT_SECAO = {**{s['id']: s['nome'] for s in SITE['secoes']}, 'nenhuma': 'Nenhuma'}
ROT_TRILHA = {t['id']: t['nome'] for t in TRI['itens']}


def montar(ex):
    st = estado(ex)
    cv = st['comportamento_do_visitante']
    abertas, itens, buscou = cv['secoes_que_abriu_em_ordem'], cv['itens_que_abriu_ou_leu'], cv['buscou']
    eventos = cv['ultimos_eventos'] if isinstance(cv['ultimos_eventos'], list) else []
    campos = [('abriu', '; '.join(abertas) if isinstance(abertas, list) else abertas)]
    if isinstance(itens, list):
        campos.append(('leu', '; '.join(i.split(' → ')[-1] for i in itens[:4])))
    if isinstance(buscou, list):
        campos.append(('buscou', ', '.join(buscou)))
    campos.append(('ainda fechadas', f'{len(cv["secoes_ainda_fechadas"])} seções'))
    sec = (ex['chamadas'][0]['request']['questions'].get('destaque') or {}).get('instructions', '')
    lista = next((s for s in SITE['secoes'] if f'"{s["nome"]}"' in sec), POR.get(LISTA))
    rot_itens = {str(x['id']): x['nome'] for x in (lista or {}).get('itens', [])}
    dest = opcoes(ex, 'destaque', 2, rotulos=rot_itens)
    prox = opcoes(ex, 'proxima', 1, rotulos=ROT_SECAO)[0]
    tri = opcoes(ex, 'trilha', 1, rotulos=ROT_TRILHA)[0]
    n_itens = sum(len(s['itens']) for s in SITE['secoes'] if s['tipo'] in ('trilhas', 'lista', 'depoimentos'))
    return {
        'entrada': {
            'titulo': 'O que o visitante fez (eventos reais)',
            'texto': ' → '.join(eventos[-5:]) if eventos else 'abriu seções e itens da página',
            'campos': campos,
            'max_linhas_campo': 4,
            'nota': 'Quase tudo começa fechado; cada abertura vira sinal. As opções de "próxima seção" vão só com o que ainda está fechado, e as de "destaque" com os itens da lista na tela.',
        },
        'jev': {
            'perguntas': [
                pergunta(ex, 'perfil', 'Quem é este visitante?', n=2, rotulos=ROT_PERFIL),
                pergunta(ex, 'destaque', f'O que mostrar primeiro em {lista["nome"] if lista else "a lista"}?', n=2, rotulos=rot_itens),
                pergunta(ex, 'proxima', 'Qual seção fechada ele deve abrir?', n=2, rotulos=ROT_SECAO),
                pergunta(ex, 'trilha', 'Por onde começar?', n=1, rotulos=ROT_TRILHA),
            ],
            'mais': f'+ {total_perguntas(ex) - 4} outras na mesma chamada: interesse, objeção, ação da página, depoimento parecido e chance de {SITE["conversao"]["verbo"]}',
            'nota': f'O Jev escolhe entre itens REAIS do site.json ({n_itens} itens, {len(SITE["secoes"])} seções, {len(TRI["itens"])} trilhas). A página nunca escreve nada que não esteja no conteúdo.',
        },
        'saida': {
            'titulo': 'A página se monta para ele',
            'itens': [
                f'“{dest[0][0]}” sobe para o topo da lista com o selo “Para você · {pct(dest[0][1])}”',
                f'Porta recomendada: {prox[0]} ({pct(prox[1])}) · chip “Próximo para você”',
                f'Sua trilha: comece por {tri[0]}' + (f'; a chamada vira “{ex["extra"]["cta"]}”' if ex.get('extra', {}).get('cta') else ''),
            ],
            'nota': 'Textos de modelo preenchidos com as escolhas do Jev e os nomes do site.json. Ações que interrompem (guia, dúvida, depoimento, saída) só com 50% ou mais e com intervalo.',
        },
    }
