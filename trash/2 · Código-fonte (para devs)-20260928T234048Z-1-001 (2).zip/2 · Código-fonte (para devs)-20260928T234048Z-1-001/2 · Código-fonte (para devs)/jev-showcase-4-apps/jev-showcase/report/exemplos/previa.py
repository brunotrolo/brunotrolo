#!/usr/bin/env python3
"""Prévia de um ou mais diagramas "entrada → Jev → saída" sem gerar o site inteiro.
Uso: python3 report/exemplos/previa.py golpe [estudio ...]
Grava scratch/exemplos-run/previa-<id>.svg e .png (1440 px) e imprime a altura; use o PNG para conferir o desenho."""
import json
import pathlib
import sys

AQUI = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
from capturar import receita, DADOS, RUN  # noqa: E402
from desenho import svg_exemplo  # noqa: E402


def gerar(app_id, prod=None):
    R = receita(app_id)
    fonte = getattr(R, 'DADOS', app_id)  # a visão geral usa a captura de outro app
    ex = json.loads((DADOS / f'{fonte}.json').read_text())
    jpg = (DADOS / f'{fonte}.jpg').read_bytes() if (DADOS / f'{fonte}.jpg').exists() else None
    meta = {'id': app_id, 'titulo': getattr(R, 'TITULO', app_id), 'emoji': ''}
    return svg_exemplo(meta, R.montar(ex), ex, jpg, prod)


if __name__ == '__main__':
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch()
        for app_id in sys.argv[1:]:
            svg, w, h, _caixa = gerar(app_id)
            arq = RUN / f'previa-{app_id}.svg'
            arq.write_text(svg)
            pg = b.new_page(viewport={'width': w, 'height': h})
            pg.set_content(f'<body style="margin:0;background:#0b0e15"><img src="{arq.as_uri()}" width="{w}" height="{h}"></body>')
            pg.goto(arq.as_uri())
            pg.wait_for_timeout(300)
            pg.screenshot(path=str(RUN / f'previa-{app_id}.png'))
            pg.close()
            print(f'{app_id}: {w}×{h} → {RUN / f"previa-{app_id}.png"}')
        b.close()
