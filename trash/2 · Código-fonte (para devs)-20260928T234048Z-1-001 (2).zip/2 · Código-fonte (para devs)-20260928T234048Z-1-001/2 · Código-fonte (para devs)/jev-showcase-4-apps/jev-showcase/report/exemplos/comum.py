"""Ajudantes das receitas de exemplo (report/exemplos/apps/<id>.py).

Uma receita tem duas metades:
  captura  — URL, acoes(pg), PRONTO, escolher(calls), RECORTE, extra(pg)   (usadas por capturar.py)
  conteúdo — montar(ex) -> dict com 'entrada', 'jev' e 'saida'            (usada por build_arquiteturas.py)

`ex` é o JSON gravado em report/exemplos/dados/<id>.json: ex['chamadas'] (chamadas reais do inspetor, com
request.state, request.questions e response.answers) e ex['extra'] (textos lidos da página na hora da captura).
"""
import re

TIPO_LEGIVEL = {'choice': 'escolha', 'score': 'nota', 'noul': 'sim ou não'}


def chamadas(ex):
    return ex['chamadas']


def achar(ex, qid, chamada=None):
    """(definição da pergunta, resposta) de `qid`, procurando em todas as chamadas (ou só na índice `chamada`)."""
    lista = ex['chamadas'] if chamada is None else [ex['chamadas'][chamada]]
    for c in lista:
        qs = (c.get('request') or {}).get('questions') or {}
        ans = (c.get('response') or {}).get('answers') or {}
        if qid in ans:
            return qs.get(qid, {}), ans[qid]
    raise KeyError(f'pergunta {qid!r} não está nas chamadas capturadas')


def estado(ex, chamada=0):
    return ex['chamadas'][chamada]['request']['state']


def bonito(chave):
    s = str(chave).replace('_', ' ').strip()
    return s[:1].upper() + s[1:]


def rotulo_criterio(texto, chave, maximo=36):
    """Rótulo curto de uma opção a partir do critério escrito no app:
    'Falso parente/amigo: diz ter trocado…' → 'Falso parente/amigo'; cabeça longa → corta em '/', '(' ou ',';
    sem nada curto → a chave legível (prefira passar `rotulos` na receita quando a chave não tem acento)."""
    if isinstance(texto, str) and texto.strip():
        sem_par = re.sub(r'\s*\([^)]*\)', '', texto.strip())  # "(ex.: …)" antes dos dois-pontos não pode virar rótulo
        cab = re.split(r'\s*:\s*|\s+[—–]\s+', sem_par, maxsplit=1)[0].strip()
        for cand in (cab, re.split(r'\s*[/(,;.]\s*', cab, maxsplit=1)[0].strip()):
            if 0 < len(cand) <= maximo:
                return cand
    return bonito(chave)


def opcoes(ex, qid, n=3, rotulos=None, chamada=None):
    """Top-n de uma pergunta choice ou score: [(rótulo, probabilidade), ...], a escolhida primeiro."""
    q, a = achar(ex, qid, chamada)
    rotulos = rotulos or {}
    probs = a.get('probabilities') or {}
    if a.get('type') == 'score':
        legenda = a.get('legend') or {}
        itens = sorted(probs.items(), key=lambda kv: -kv[1])[:n]
        return [(rotulos.get(k) or f'{k} · {rotulo_criterio(legenda.get(k, ""), k, 30)}', p) for k, p in itens]
    crit = q.get('criteria') or {}
    itens = sorted(probs.items(), key=lambda kv: (kv[0] != a.get('choice'), -kv[1]))[:n]
    return [(rotulos.get(k) or rotulo_criterio(crit.get(k) if isinstance(crit, dict) else None, k), p) for k, p in itens]


def escolha(ex, qid, chamada=None):
    return achar(ex, qid, chamada)[1].get('choice')


def nota(ex, qid, chamada=None):
    return achar(ex, qid, chamada)[1].get('score')


def sim(ex, qid, chamada=None):
    a = achar(ex, qid, chamada)[1]
    return a.get('noul', a.get('probability'))


def pergunta(ex, qid, rotulo, n=3, rotulos=None, chamada=None, tipo=None):
    """Bloco pronto para a coluna do Jev."""
    q, a = achar(ex, qid, chamada)
    t = a.get('type') or q.get('type')
    if t == 'noul':
        return {'rotulo': rotulo, 'tipo': tipo or 'sim ou não', 'sim': sim(ex, qid, chamada)}
    if t == 'score':
        niveis = len(a.get('legend') or a.get('probabilities') or {})
        return {'rotulo': rotulo, 'tipo': tipo or (f'nota de 0 a {niveis - 1}' if niveis else 'nota'), 'opcoes': opcoes(ex, qid, n, rotulos, chamada)}
    crit = q.get('criteria') or {}
    return {'rotulo': rotulo, 'tipo': tipo or f'escolha entre {len(crit)}', 'opcoes': opcoes(ex, qid, n, rotulos, chamada)}


def pct(p):
    if p is None:
        return '—'
    v = p * 100
    return f'{v:.0f}%' if v >= 1 or v == 0 else '<1%'


def total_perguntas(ex):
    return sum(c.get('n_questions') or len(((c.get('request') or {}).get('questions') or {})) for c in ex['chamadas'])


def custo(ex):
    return sum(c.get('cost') or 0 for c in ex['chamadas'])


def curto(s, n):
    s = ' '.join(str(s).split())
    return s if len(s) <= n else s[: n - 1].rstrip() + '…'
