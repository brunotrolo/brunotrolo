# Estúdio por Voz — exemplo real: a descrição da hamburgueria numa atualização só (as 6 chamadas com o mesmo texto;
# no microfone, a mesma rodada se repete a cada pausa da fala)
import urllib.parse
FALA = 'Tenho uma hamburgueria artesanal em Curitiba chamada Brasa Burger, o clima é bem rock and roll, com música alta e muita atitude. A gente faz delivery pelo WhatsApp e eu quero mostrar o cardápio com os preços.'
URL = '/?texto=' + urllib.parse.quote(FALA)
ESPERA_S = 90
PRONTO = """() => { const e = window.estudio && window.estudio.estado; return !!(e && !e.voando && !e.pendente && (e.grupos || []).length === 6 && JevKit.inspector.calls.length >= 6); }"""
ASSENTAR_MS = 1500
RECORTE = '#palco'
from comum import estado, opcoes, pergunta, pct, total_perguntas

TITULO = 'Estúdio por Voz'
GRUPOS = {'seg': 'entender', 'hero': 'site', 'estilo': 'marca', 'car_estilo': 'posts', 'em_tipo': 'email', 'ad_conceito': 'anuncios'}


def escolher(calls):
    ultimos = {}
    for c in calls:
        qs = (c.get('request') or {}).get('questions') or {}
        for q, g in GRUPOS.items():
            if q in qs:
                ultimos[g] = c
    return [ultimos[g] for g in GRUPOS.values() if g in ultimos]


# rótulos que o próprio app mostra (public/lib/biblioteca.mjs: TIPOS_EMAIL e CONCEITOS_AD)
ROT_EMAIL = {'boas_vindas': 'Boas-vindas', 'newsletter': 'Newsletter do mês', 'promocao': 'Promoção', 'lancamento': 'Lançamento', 'reengajamento': 'Reengajamento'}
ROT_AD = {'oferta': 'Oferta', 'produto': 'Produto em destaque', 'marca': 'Marca', 'prova': 'Prova social', 'urgencia': 'Urgência', 'local': 'Perto de você', 'novidade': 'Novidade'}


def montar(ex):
    st = estado(ex)
    top = lambda q, rot=None: opcoes(ex, q, 1, rotulos=rot)[0]
    seg, obj, est, car = top('seg'), top('obj'), top('estilo'), top('car_estilo')
    em, ad = top('em_tipo', ROT_EMAIL), top('ad_conceito', ROT_AD)
    return {
        'entrada': {
            'titulo': 'A fala da pessoa',
            'texto': st['fala_da_pessoa'],
            'campos': [('vem de', 'microfone (Web Speech API do navegador), a cada pausa; ou texto digitado')],
            'nota': 'O navegador transcreve a voz. O app manda o texto em 6 chamadas paralelas, uma por peça: entender, site, marca, carrosséis, e-mail e anúncios.',
        },
        'jev': {
            'perguntas': [
                pergunta(ex, 'seg', 'Que negócio é esse?'),
                pergunta(ex, 'car_estilo', 'Qual estilo para os carrosséis?', n=2),
                pergunta(ex, 'em_tipo', 'Que e-mail mandar primeiro?', n=2, rotulos=ROT_EMAIL),
                pergunta(ex, 'ad_conceito', 'Qual conceito para os banners?', n=2, rotulos=ROT_AD),
            ],
            'mais': f'+ {total_perguntas(ex) - 4} outras: paleta, fontes, logo, seções do site, formato e capa de cada carrossel, assunto e blocos do e-mail, assinatura…',
            'nota': 'As 6 chamadas voltam juntas em meio segundo. O Jev só escolhe entre opções que nós desenhamos; não gera imagem nem texto.',
        },
        'saida': {
            'titulo': 'As 5 peças, ao mesmo tempo',
            'itens': [
                f'{seg[0]} + {obj[0].lower()} → site com as seções e o botão certos',
                f'Carrosséis no estilo {car[0].lower()} ({pct(car[1])}): 3 carrosséis, 6 lâminas cada',
                f'E-mail de {em[0].lower()} com assinatura; banners “{ad[0].lower()}” nos 6 tamanhos',
            ],
            'nota': 'Desenhos, fontes e textos-modelo são nossos. Diga “muda os anúncios pra…” e o Jev refaz só aquela peça.',
        },
    }
