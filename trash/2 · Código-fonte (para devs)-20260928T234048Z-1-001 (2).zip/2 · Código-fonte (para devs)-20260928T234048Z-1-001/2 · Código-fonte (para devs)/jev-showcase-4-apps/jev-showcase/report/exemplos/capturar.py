#!/usr/bin/env python3
"""Captura um exemplo REAL de cada app para os diagramas "entrada → Jev → saída".

Para cada app: sobe o servidor localmente (porta 51xx) contra um gateway local com JEV_DEBUG_FULL=1 (estado e
respostas inteiros no inspetor), abre no Chromium headless, dispara o exemplo da receita, lê as chamadas reais
do inspetor (JevKit.inspector.calls) e fotografa a região da saída. Grava:
  report/exemplos/dados/<id>.json   chamadas escolhidas + dados extras lidos da página
  report/exemplos/dados/<id>.jpg    recorte da saída (840 px de largura, para 420 px no diagrama)

Receitas em report/exemplos/apps/<id>.py (ver README.md desta pasta).
Uso:  python3 report/exemplos/capturar.py [id ...]      (sem argumentos = todas as receitas)
      GW=http://127.0.0.1:8797 (padrão) — gateway local: node gateway/server.mjs com PORT=8797
"""
import importlib.util
import io
import json
import os
import pathlib
import subprocess
import sys
import time
import urllib.request

from PIL import Image
from playwright.sync_api import sync_playwright

AQUI = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))  # as receitas importam comum.py
ROOT = AQUI.parents[1]
DADOS = AQUI / 'dados'
DADOS.mkdir(exist_ok=True)
RUN = pathlib.Path(os.environ.get('EXEMPLOS_RUN', str(ROOT / 'scratch' / 'exemplos-run')))
RUN.mkdir(parents=True, exist_ok=True)
GW = os.environ.get('GW', 'http://127.0.0.1:8797')
APPS = {a['id']: a for a in json.loads((ROOT / 'apps.json').read_text())}
ORDEM = list(APPS)


def receita(app_id):
    arq = AQUI / 'apps' / f'{app_id}.py'
    spec = importlib.util.spec_from_file_location(f'receita_{app_id}', arq)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def esperar_saude(url, seg=25):
    fim = time.time() + seg
    while time.time() < fim:
        try:
            with urllib.request.urlopen(url + '/healthz', timeout=2) as r:
                if r.status == 200:
                    return True
        except Exception:
            time.sleep(0.3)
    return False


def subir(app_id, R):
    porta = 5100 + ORDEM.index(app_id)
    base = f'http://127.0.0.1:{porta}'
    dados = RUN / app_id
    dados.mkdir(parents=True, exist_ok=True)
    env = {**os.environ, 'PORT': str(porta), 'JEV_GATEWAY_URL': GW, 'DATA_DIR': str(dados), 'JEV_DEBUG_FULL': '1',
           **{k: str(v) for k, v in getattr(R, 'ENV', {}).items()}}
    log = open(RUN / f'{app_id}.log', 'w')
    p = subprocess.Popen(['node', f'apps/{app_id}/server.mjs'], cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    if not esperar_saude(base):
        p.kill()
        raise RuntimeError(f'{app_id}: servidor local não subiu (ver {RUN / (app_id + ".log")})')
    return p, base


# some com a barra do topo (fixa) e os avisos antes de fotografar a saída
LIMPAR = '.jev-topbar,.jev-toasts{display:none!important}'


def recortar(pg, R, destino):
    alvo = getattr(R, 'RECORTE', None)
    if not alvo:
        return None
    pg.add_style_tag(content=LIMPAR + getattr(R, 'CSS_RECORTE', ''))
    pg.wait_for_timeout(200)
    margem = getattr(R, 'MARGEM', 10)  # px de CSS em volta de cada trecho, para bordas e sombras não ficarem cortadas

    def foto(sel):
        alt_max = None
        if isinstance(sel, (list, tuple)):  # (seletor, altura máxima em px de CSS a partir do topo do trecho)
            sel, alt_max = sel
        loc = pg.locator(sel).first
        loc.scroll_into_view_if_needed()
        if (loc.bounding_box() or {}).get('y', 0) < margem:  # trecho mais alto que a tela: alinha o topo
            loc.evaluate('(e, m) => { e.scrollIntoView({ block: "start" }); window.scrollBy(0, -m); }', margem + 4)
        pg.wait_for_timeout(300)
        bb = loc.bounding_box()
        vw, vh = pg.viewport_size['width'], pg.viewport_size['height']
        x0, y0 = max(0, bb['x'] - margem), max(0, bb['y'] - margem)
        alto = bb['height'] if not alt_max else min(bb['height'], alt_max)
        clip = {'x': x0, 'y': y0, 'width': min(vw, bb['x'] + bb['width'] + margem) - x0, 'height': min(vh, bb['y'] + alto + margem) - y0}
        return Image.open(io.BytesIO(pg.screenshot(type='png', clip=clip, animations='disabled'))).convert('RGB')

    if callable(alvo):
        img = Image.open(io.BytesIO(alvo(pg))).convert('RGB')
    elif isinstance(alvo, list):  # vários trechos da tela, empilhados na mesma largura; item = seletor ou (seletor, altura máx.)
        partes = [foto(sel) for sel in alvo]
        larg = max(x.width for x in partes)
        partes = [x if x.width == larg else x.resize((larg, round(x.height * larg / x.width)), Image.LANCZOS) for x in partes]
        vao = 20
        img = Image.new('RGB', (larg, sum(x.height for x in partes) + vao * (len(partes) - 1)), partes[0].getpixel((2, 2)))
        y = 0
        for x in partes:
            img.paste(x, (0, y)); y += x.height + vao
    else:
        img = foto(alvo)
    alt = getattr(R, 'ALTURA_MAX', None)  # em px de CSS: corta do topo (a imagem vem em 2x)
    if alt and img.height > alt * 2:
        img = img.crop((0, 0, img.width, alt * 2))
    larg = getattr(R, 'LARGURA_RECORTE', 840)
    if img.width > larg:
        img = img.resize((larg, round(img.height * larg / img.width)), Image.LANCZOS)
    img.save(destino, 'JPEG', quality=80, optimize=True, progressive=True)
    return {'w': img.width, 'h': img.height}


def capturar(app_id):
    R = receita(app_id)
    t0 = time.time()
    p, base = subir(app_id, R)
    try:
        with sync_playwright() as pw:
            b = pw.chromium.launch(headless=True, args=getattr(R, 'ARGS', []))
            vw, vh = getattr(R, 'VIEWPORT', (1440, 900))
            ctx = b.new_context(viewport={'width': vw, 'height': vh}, device_scale_factor=2, locale='pt-BR')
            if getattr(R, 'INIT', None):
                ctx.add_init_script(R.INIT)
            pg = ctx.new_page()
            erros = []
            pg.on('pageerror', lambda e: erros.append(str(e)))
            pg.goto(base + getattr(R, 'URL', '/'), wait_until=getattr(R, 'WAIT_UNTIL', 'networkidle'))  # app com SSE aberto: use 'load'
            if hasattr(R, 'acoes'):
                R.acoes(pg)
            pg.wait_for_function(R.PRONTO, timeout=getattr(R, 'ESPERA_S', 60) * 1000)
            pg.wait_for_timeout(getattr(R, 'ASSENTAR_MS', 600))
            chamadas = pg.evaluate('() => JSON.parse(JSON.stringify((window.JevKit && JevKit.inspector.calls) || []))')
            escolhidas = R.escolher(chamadas) if hasattr(R, 'escolher') else chamadas[-1:]
            if not escolhidas:
                raise RuntimeError(f'{app_id}: nenhuma chamada do Jev registrada no inspetor')
            extra = R.extra(pg) if hasattr(R, 'extra') else {}
            dims = recortar(pg, R, DADOS / f'{app_id}.jpg')
            b.close()
        ex = {'app': app_id, 'capturado_em': time.strftime('%Y-%m-%d %H:%M'), 'url': getattr(R, 'URL', '/'),
              'chamadas': escolhidas, 'extra': extra, 'recorte': dims, 'erros_pagina': erros[:5]}
        (DADOS / f'{app_id}.json').write_text(json.dumps(ex, ensure_ascii=False, indent=1))
        nq = sum(c.get('n_questions') or 0 for c in escolhidas)
        print(f'  ✓ {app_id}: {len(escolhidas)} chamada(s), {nq} perguntas, recorte {dims}, {time.time() - t0:.1f} s'
              + (f'  ⚠ erros na página: {erros[:2]}' if erros else ''), flush=True)
    finally:
        p.terminate()
        try:
            p.wait(5)
        except Exception:
            p.kill()


if __name__ == '__main__':
    ids = sys.argv[1:] or sorted(f.stem for f in (AQUI / 'apps').glob('*.py') if not f.stem.startswith('_') and f.stem in APPS)
    falhas = []
    for i in ids:
        try:
            capturar(i)
        except Exception as e:  # segue para o próximo app e relata no fim
            print(f'  ✗ {i}: {e}', flush=True)
            falhas.append(i)
    sys.exit(1 if falhas else 0)
