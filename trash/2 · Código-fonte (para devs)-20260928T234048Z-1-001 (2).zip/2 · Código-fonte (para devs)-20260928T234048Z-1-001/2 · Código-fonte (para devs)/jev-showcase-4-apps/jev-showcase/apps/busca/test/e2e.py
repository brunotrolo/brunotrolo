#!/usr/bin/env python3
"""E2E — Busca que Entende (porta 4111).

Uso:  python3 apps/busca/test/e2e.py            (servidor já rodando em http://localhost:4111)
      BUSCA_URL=http://host:porta python3 apps/busca/test/e2e.py

O que prova:
  1. Para 4 buscas-exemplo, o top-5 do Jev é coerente (precisão@5 >= 0,8 contra um gabarito escrito à mão sobre o
     catálogo versionado) e melhor que o da busca por palavra-chave; o orçamento "até 150 reais" é respeitado.
  2. Cada busca termina (clique -> resultado na tela) em menos de 2 s, medindo sem cache (?fresh=1).
  3. Digitação ao vivo com debounce, descarte de respostas velhas em cliques rápidos, entrada vazia, só emoji,
     texto enorme e inglês não quebram nada.
  4. Inspetor mostra as chamadas reais; layout de celular com abas funciona.
  5. Zero erros de console / pageerror.
Capturas em apps/busca/test/shots/.
"""
import json
import os
import random
import sys
import time

from playwright.sync_api import sync_playwright

URL = os.environ.get('BUSCA_URL', 'http://localhost:4111').rstrip('/')
HERE = os.path.dirname(os.path.abspath(__file__))
SHOTS = os.path.join(HERE, 'shots')
os.makedirs(SHOTS, exist_ok=True)
CAT = {p['id']: p for p in json.load(open(os.path.join(HERE, '..', 'data', 'catalogo.json'), encoding='utf-8'))}

# Gabarito (relevância julgada à mão sobre data/catalogo.json)
JARDIM_PRESENTE = {'p001', 'p002', 'p003', 'p004', 'p005', 'p006', 'p007', 'p008', 'p009', 'p010', 'p107'}  # jardim <= R$150 + livro de horta
ACAMPAR_FRIO = {f'p{i:03d}' for i in range(13, 26)} | {'p060', 'p072', 'p112'}  # camping, roupa de frio, garrafa térmica, manta, guia de trilhas
CACHORRO_RESISTENTE = {'p086', 'p087', 'p088', 'p089', 'p090'}  # mordedor, bola maciça, recheável, disco, corda
SONO_BARULHO = {'p043', 'p061', 'p062', 'p063', 'p064', 'p067', 'p068', 'p069', 'p070', 'p077', 'p114', 'p028', 'p075'}
CAFE = {'p051', 'p052', 'p053', 'p054', 'p055', 'p060'}

CASOS = [
    # (texto do chip, frase, gabarito, arquivo de captura)
    ('Mãe jardineira', 'presente pra minha mãe que ama jardinagem até 150 reais', JARDIM_PRESENTE, '02-jardinagem.png'),
    ('Acampar com criança', 'acampar com criança no frio', ACAMPAR_FRIO, '03-acampar.png'),
    ('Cachorro destruidor', 'meu cachorro destrói todos os brinquedos', CACHORRO_RESISTENTE, '04-cachorro.png'),
    ('Insônia', 'tenho insônia e acordo com qualquer barulho', SONO_BARULHO, '05-insonia.png'),
]

fails = []


def check(cond, msg):
    print(('  ✓ ' if cond else '  ✗ ') + msg)
    if not cond:
        fails.append(msg)


def p_at_5(ids, rel):
    return sum(1 for i in ids[:5] if i in rel) / 5


def nomes(ids):
    return ', '.join(f"{CAT[i]['nome'][:28]} (R$ {CAT[i]['preco']:.2f})" for i in ids[:5])


def main():
    errors, warnings = [], []
    ip = f'10.{random.randint(20, 250)}.{random.randint(0, 250)}.{random.randint(1, 250)}'  # isola o limite por IP deste teste
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(viewport={'width': 1440, 'height': 900}, device_scale_factor=1, locale='pt-BR',
                                  extra_http_headers={'X-Forwarded-For': ip})
        pg = ctx.new_page()
        pg.on('console', lambda m: (errors if m.type == 'error' else warnings).append(f'{m.type}: {m.text}') if m.type in ('error', 'warning') else None)
        pg.on('pageerror', lambda e: errors.append(f'pageerror: {e}'))
        api_calls = []
        pg.on('request', lambda r: api_calls.append(r.url) if '/api/buscar' in r.url else None)

        print('1) Página inicial')
        pg.goto(URL + '/?fresh=1', wait_until='networkidle')
        pg.wait_for_selector('#chips .jev-chip')
        check(pg.locator('#mosaic .tile').count() == 120, 'mosaico mostra os 120 produtos do catálogo')
        check('Busca que Entende' in pg.inner_text('h1'), 'título visível no primeiro frame')
        check(pg.locator('#chips .jev-chip').count() >= 6, 'há chips de exemplo para o caminho de 1 clique')
        pg.wait_for_timeout(300)
        pg.screenshot(path=os.path.join(SHOTS, '01-inicio.png'))

        print('2) Quatro buscas-exemplo: coerência, orçamento, comparação com palavra-chave e tempo')
        ganhos = 0
        for chip, frase, gab, shot in CASOS:
            t0 = time.perf_counter()
            pg.locator('#chips .jev-chip', has_text=chip).first.click()
            pg.wait_for_function('q => window.__buscaLast && window.__buscaLast.q === q', arg=frase, timeout=15000)
            dt = (time.perf_counter() - t0) * 1000
            last = pg.evaluate('window.__buscaLast')
            pg.wait_for_timeout(250)
            jev = pg.eval_on_selector_all('#jevlist li.res', 'els => els.map(e => e.dataset.id)')
            kw = pg.eval_on_selector_all('#kwlist li.res', 'els => els.map(e => e.dataset.id)')
            pj, pk = p_at_5(jev, gab), p_at_5(kw, gab)
            print(f'   "{frase}"')
            print(f'     Jev  P@5={pj:.1f}: {nomes(jev)}')
            print(f'     Pal. P@5={pk:.1f}: {nomes(kw) if kw else "(nenhum resultado)"}')
            print(f"     clique→tela {dt:.0f} ms · servidor {last['latency_ms']} ms · US$ {last['cost']:.6f} · cache={last['cached']}")
            check(pj >= 0.8, f'top-5 do Jev coerente (P@5={pj:.1f} >= 0,8)')
            check(pj >= pk, f'Jev (P@5={pj:.1f}) não perde da palavra-chave (P@5={pk:.1f})')
            ganhos += pj > pk
            check(dt < 2000, f'resultado na tela em {dt:.0f} ms (< 2 s)')
            check(not last['cached'], 'medido sem cache (?fresh=1)')
            check(pg.locator('#mosaic .tile .rk').count() >= 3, 'mosaico destaca os primeiros colocados')
            if chip == 'Mãe jardineira':
                check(all(CAT[i]['preco'] <= 150 for i in jev[:5]), 'todos os 5 primeiros respeitam "até 150 reais"')
                pills = pg.inner_text('#understood')
                for w in ('Presente', 'Jardim', 'mãe', '150'):
                    check(w in pills, f'"O Jev entendeu" contém "{w}"')
                check(any(CAT[i]['preco'] > 150 for i in kw) or len(kw) < 5, 'palavra-chave ignora o orçamento ou acha pouca coisa')
            if chip == 'Cachorro destruidor':
                check('p091' not in jev[:3], 'pelúcia (que o cachorro destrói) fica fora do top-3 do Jev')
            if chip == 'Acampar com criança':
                pills = pg.inner_text('#understood')
                check('Camping' in pills and 'criança' in pills, '"O Jev entendeu" = camping + criança')
            pg.screenshot(path=os.path.join(SHOTS, shot))
        check(ganhos >= 3, f'Jev melhor que palavra-chave em {ganhos} de 4 buscas (mínimo 3)')

        print('3) Inglês')
        pg.locator('#chips .jev-chip', has_text='Em inglês').click()
        pg.wait_for_function('q => window.__buscaLast && window.__buscaLast.q === q', arg='gift for a coffee lover', timeout=15000)
        pg.wait_for_timeout(250)
        jev = pg.eval_on_selector_all('#jevlist li.res', 'els => els.map(e => e.dataset.id)')
        kw = pg.eval_on_selector_all('#kwlist li.res', 'els => els.map(e => e.dataset.id)')
        check(sum(1 for i in jev[:3] if i in CAFE) >= 3, f'"gift for a coffee lover" → top-3 de café: {nomes(jev[:3])}')
        check(len(kw) == 0, 'palavra-chave não acha nada em inglês')
        pg.screenshot(path=os.path.join(SHOTS, '06-ingles.png'))

        print('4) Inspetor')
        pg.locator('#chips .jev-chip', has_text='Mãe jardineira').click()
        pg.wait_for_function('q => window.__buscaLast && window.__buscaLast.q === q', arg='presente pra minha mãe que ama jardinagem até 150 reais', timeout=15000)
        pg.wait_for_timeout(400)
        pg.click('.jev-topbar button:has-text("🔍")')
        pg.wait_for_selector('.jev-drawer.open')
        n_calls = pg.locator('.jev-drawer .jev-call').count()
        check(n_calls >= 6, f'inspetor lista as chamadas reais ({n_calls})')
        txt = pg.inner_text('.jev-drawer').lower()  # os rótulos são exibidos em maiúsculas via CSS
        check('entendimento' in txt and 'lote 1/5' in txt and 'lote 5/5' in txt and '_truncado' not in txt, 'inspetor mostra o entendimento e os 5 lotes inteiros (sem truncar)')
        pg.wait_for_timeout(300)
        pg.screenshot(path=os.path.join(SHOTS, '07-inspetor.png'))
        pg.keyboard.press('Escape')

        print('5) Digitação ao vivo (debounce) e descarte de respostas velhas')
        pg.fill('#q', '')
        n0 = len(api_calls)
        pg.locator('#q').press_sequentially('meu gato não bebe água', delay=70)
        pg.wait_for_function('q => window.__buscaLast && window.__buscaLast.q === q', arg='meu gato não bebe água', timeout=15000)
        pg.wait_for_timeout(800)
        n_typing = len(api_calls) - n0
        jev = pg.eval_on_selector_all('#jevlist li.res', 'els => els.map(e => e.dataset.id)')
        check(1 <= n_typing <= 3, f'digitando 22 letras gerou só {n_typing} chamada(s) ao Jev (debounce)')
        check('p095' in jev[:2], f'"meu gato não bebe água" → fonte de água para gatos no top-2 ({nomes(jev[:2])})')
        check(pg.locator('#kwlist li.res').count() >= 1, 'coluna de palavra-chave atualiza enquanto digita')
        # cliques rápidos: só a última resposta pode ficar na tela
        for chip in ('Fã de dinossauro', 'Amigo secreto', 'Insônia', 'Carregador quebrou'):
            pg.locator('#chips .jev-chip', has_text=chip).click()
            pg.wait_for_timeout(60)
        pg.wait_for_function('q => window.__buscaLast && window.__buscaLast.q === q', arg='o carregador do meu celular quebrou', timeout=15000)
        pg.wait_for_timeout(1500)
        last = pg.evaluate('window.__buscaLast')
        check(last['q'] == 'o carregador do meu celular quebrou', 'após 4 cliques rápidos, a tela mostra a última busca')
        jev = pg.eval_on_selector_all('#jevlist li.res', 'els => els.map(e => e.dataset.id)')
        check(jev[:1] == ['p040'], f'"carregador quebrou" → carregador em 1º ({nomes(jev[:1])})')
        check('Reposição' in pg.inner_text('#understood'), 'intenção entendida como reposição')
        check(pg.input_value('#q') == 'o carregador do meu celular quebrou', 'caixa de busca coerente com o resultado')

        print('6) Entradas estranhas')
        pg.fill('#q', '🔥🔥🔥')
        pg.press('#q', 'Enter')
        pg.wait_for_function('q => window.__buscaLast && window.__buscaLast.q === q', arg='🔥🔥🔥', timeout=15000)
        pg.wait_for_timeout(300)
        check(pg.is_visible('#jevnone'), 'só emoji: o Jev diz que nada no catálogo atende (não inventa)')
        pg.screenshot(path=os.path.join(SHOTS, '08-nada-serve.png'))
        pg.fill('#q', 'presente ' * 200)
        v = pg.input_value('#q')
        pg.press('#q', 'Enter')
        pg.wait_for_function('() => window.__buscaLast && window.__buscaLast.q.startsWith("presente presente")', timeout=15000)
        check(len(pg.evaluate('window.__buscaLast.q')) <= 300, f'texto enorme ({len(v)} caracteres na caixa) é cortado em 300 e funciona')
        pg.fill('#q', '')
        pg.click('#go')
        pg.wait_for_selector('.jev-toast', timeout=3000)
        check('Digite' in pg.inner_text('.jev-toasts'), 'busca vazia mostra aviso amigável (sem chamar o Jev)')
        check(pg.is_visible('#jevph') and pg.is_visible('#kwph'), 'limpar a caixa volta ao estado inicial')

        ctx.close()

        print('7) Celular (390×844)')
        mctx = browser.new_context(viewport={'width': 390, 'height': 844}, device_scale_factor=2, is_mobile=True, has_touch=True, locale='pt-BR',
                                   extra_http_headers={'X-Forwarded-For': ip})
        m = mctx.new_page()
        m.on('console', lambda msg: errors.append(f'mobile {msg.type}: {msg.text}') if msg.type == 'error' else None)
        m.on('pageerror', lambda e: errors.append(f'mobile pageerror: {e}'))
        m.goto(URL + '/', wait_until='networkidle')
        m.wait_for_selector('#chips .jev-chip')
        m.locator('#chips .jev-chip', has_text='Mãe jardineira').click()
        m.wait_for_function('() => window.__buscaLast', timeout=15000)
        m.wait_for_timeout(700)
        # com is_mobile=True a janela cresce junto com a página: compare com os 390 px da tela
        overflow = m.evaluate('document.documentElement.scrollWidth - 390')
        check(overflow <= 1, f'sem rolagem horizontal no celular (excesso {overflow}px)')
        check(m.is_visible('#jevlist') and not m.is_visible('#kwlist'), 'celular: aba "Com Jev" ativa por padrão')
        m.screenshot(path=os.path.join(SHOTS, 'mobile.png'))
        m.click('#mtabs button[data-tab="kw"]')
        check(m.is_visible('#kwlist') and not m.is_visible('#jevlist'), 'celular: aba "Palavra-chave" troca a coluna')
        m.click('#mtabs button[data-tab="cat"]')
        check(m.is_visible('#mosaic'), 'celular: aba "Catálogo" mostra o mosaico')
        mctx.close()
        browser.close()

    print('8) Console')
    for w in warnings[:5]:
        print('   (aviso)', w)
    check(not errors, 'zero erros de console/pageerror' + ('' if not errors else ': ' + ' | '.join(errors[:5])))
    print()
    if fails:
        print(f'FALHOU: {len(fails)} verificação(ões)')
        for f in fails:
            print('  -', f)
        sys.exit(1)
    print('OK — todas as verificações passaram. Capturas em', SHOTS)


if __name__ == '__main__':
    main()
