#!/usr/bin/env python3
"""E2E do Site que Lê Intenções (versão genérica). Playwright headless (Chromium). Tudo o que ele confere vem do site.json.

Uso:  python3 apps/site/test/e2e.py [--url http://localhost:4115/ | https://jev-site.srvNNNNNN.hstgr.cloud/] [--sims a,b] [--sem-sims] [--sem-jev]
      (https = faz login no hub com .secrets/jev_login, sem imprimir as credenciais)
      --sem-sims  pula as simulações (parte 8)
      --sem-jev   pula tudo o que depende do rastreador e do Jev: as decisões e a Lente preenchida (parte 2), o contrato
                  (parte 4), jevUx.sinais() e o cta.entrou (parte 5) e as simulações (parte 8)
Prova, com o Jev de verdade: primeiro frame; cada seção abre e fecha com os itens do JSON; nada inventado; contrato com
limpar(); pagamento/contato de demonstração; acessibilidade; celular 390×844; as simulações do site.json (o que o Jev leu
e o que apareceu); zero erros de console. Sai com código 0 só sem falhas duras. Capturas em apps/site/test/shots/.
"""
import json, pathlib, re, sys, time, unicodedata, urllib.parse
from playwright.sync_api import sync_playwright

HERE = pathlib.Path(__file__).resolve().parent
SHOTS = HERE / 'shots'
SHOTS.mkdir(parents=True, exist_ok=True)
for velho in SHOTS.glob('*.png'):
    velho.unlink()
URL = (sys.argv[sys.argv.index('--url') + 1] if '--url' in sys.argv else 'http://localhost:4115/').rstrip('/') + '/'
SEM_JEV = '--sem-jev' in sys.argv
LOGIN = URL.startswith('https://')
ACOES = ['guiar', 'destacar_item', 'responder_objecao', 'montar_trilha', 'mostrar_prova', 'convidar', 'segurar_saida']
ACOES_ITEM = ['abriu', 'leu', 'buscou', 'passou']
falhas, avisos = [], []
t_inicio = time.time()


def check(cond, msg):
    print(('  ✓ ' if cond else '  ✗ ') + msg, flush=True)
    if not cond:
        falhas.append(msg)
    return cond


def nota(cond, msg):
    """Checagem suave: registra, mas não reprova (o Jev é probabilístico nestes pontos)."""
    print(('  ✓ ' if cond else '  ~ ') + msg, flush=True)
    if not cond:
        avisos.append(msg)
    return cond


def secao(t):
    print(f'\n▶ {t}  ({time.time() - t_inicio:.0f} s)', flush=True)


def norm(s):
    return ''.join(c for c in unicodedata.normalize('NFD', str(s or '')) if unicodedata.category(c) != 'Mn').lower()


def busca_py(itens, q):
    """Mesma regra da busca da página (Lista.calcular): todas as palavras, sem acento, sem caixa."""
    ws = [w for w in norm(q).split() if w]
    campos = ('nome', 'frase', 'desc', 'grupo', 'rotulo', 'papel', 'texto')
    return [x for x in itens if all(w in norm(' '.join(str(x.get(c, '')) for c in campos)) for w in ws)]


with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    erros, enviados, respostas = [], [], []

    def logar(ctx):
        # credenciais em .secrets/jev_login (linha 1 = e-mail, linha 2 = senha), nunca impressas
        email, senha = (HERE.parents[2] / '.secrets' / 'jev_login').read_text().splitlines()[:2]
        pg = ctx.new_page()
        hub = 'https://jev.' + urllib.parse.urlparse(URL).hostname.split('.', 1)[1]  # jev-site.<dominio> → jev.<dominio>
        pg.goto(hub + '/login?next=' + urllib.parse.quote(URL, safe=''))
        pg.fill('#email', email)
        pg.fill('#password', senha)
        pg.click('button[type=submit]')
        pg.wait_for_url(URL + '**', timeout=30000)
        pg.close()

    def on_resp(resp):
        if '/api/decidir' in resp.url:
            try:
                respostas.append((resp.status, resp.json()))
            except Exception:
                respostas.append((resp.status, None))

    def on_req(req):
        if '/api/decidir' in req.url and req.method == 'POST':
            try:
                enviados.append(json.loads(req.post_data)['sinais'])
            except Exception as e:
                enviados.append({'_erro': str(e)})

    def nova_pagina(w=1440, h=900, rotulo='', reduzido=False, **kw):
        ctx = browser.new_context(viewport={'width': w, 'height': h}, device_scale_factor=kw.pop('dsf', 1), reduced_motion='reduce' if reduzido else 'no-preference', **kw)
        if LOGIN:
            logar(ctx)
        pg = ctx.new_page()
        pg.on('console', lambda m: erros.append(f'[{rotulo}] console.{m.type}: {m.text}') if m.type in ('error', 'warning') else None)
        pg.on('pageerror', lambda e: erros.append(f'[{rotulo}] pageerror: {e}'))
        pg.on('request', on_req)
        pg.on('response', on_resp)
        return ctx, pg

    def abrir(pg, sufixo=''):
        pg.goto(URL + sufixo, wait_until='networkidle')
        pg.wait_for_function('() => document.body.classList.contains("pronto")', timeout=15000)

    def clique(pg, sel, **kw):
        pg.evaluate("s => { const e = document.querySelector(s); if (e) e.scrollIntoView({ block: 'center', behavior: 'instant' }); }", sel)
        pg.wait_for_timeout(40)
        pg.click(sel, **kw)

    def txt(pg, sel):
        return pg.locator(sel).first.inner_text().strip()

    def shot(pg, nome, full=False):
        pg.screenshot(path=str(SHOTS / nome), full_page=full)
        print('  📸', nome, flush=True)

    # ================================================================== 1
    secao('Primeiro frame (desktop 1440×900)')
    ctx, pg = nova_pagina(rotulo='desktop', reduzido=True)
    abrir(pg)
    D = pg.evaluate('() => fetch("dados/site.json").then(r => r.json())')
    SEC = D['secoes']
    IDS = [s['id'] for s in SEC]
    POR = {s['id']: s for s in SEC}
    TIPO = {}
    for s in SEC:
        TIPO.setdefault(s['tipo'], s['id'])
    LISTAS = [s['id'] for s in SEC if s['tipo'] in ('trilhas', 'lista', 'depoimentos')]
    OF, FQ = POR[TIPO['oferta']], POR[TIPO['faq']]
    PAG = D['conversao']['tipo'] == 'pagamento'

    def contar(s):
        return len(s['cards']) if s['tipo'] == 'espacos' else len(s.get('itens') or [])

    def preencher(t):
        t = re.sub(r'\{n:([a-z0-9_]+)\}', lambda m: str(contar(POR[m.group(1)])), str(t))
        return re.sub(r'\{total:([a-z0-9_]+)\}', lambda m: str(sum(x['n'] for x in POR[m.group(1)]['itens'])), t)

    check(D['marca']['nome'] in pg.title() and 'Site que Lê Intenções' in pg.title(), f'título da aba: {pg.title()!r}')
    check(txt(pg, '#heroTitulo') == D['hero']['titulo'], 'título do topo = hero.titulo do JSON')
    check([x.inner_text().strip() for x in pg.locator('.hero-nums dt').all()] == [preencher(n) for n, _ in D['hero']['numeros']], 'números do topo = hero.numeros (com {n:…} preenchido)')
    check(txt(pg, '[data-cta="topo"]') == D['hero']['cta'], 'botão do topo = hero.cta')
    portas = pg.eval_on_selector_all('#portas > .porta', 'els => els.map(e => e.dataset.sec)')
    check(portas == IDS, f'{len(IDS)} portas, na ordem e com os ids do site.json')
    fechadas = pg.evaluate('''() => [...document.querySelectorAll('#portas > .porta')].every(s => {
        const b = s.querySelector('.porta-bt'), c = document.getElementById(b.getAttribute('aria-controls'));
        return b.tagName === 'BUTTON' && b.getAttribute('aria-expanded') === 'false' && c && c.hidden && c.getAttribute('role') === 'region'; })''')
    check(fechadas, 'todas começam FECHADAS: <button aria-expanded="false" aria-controls> → região escondida')
    esperado = {}
    for s in SEC:
        if s['tipo'] == 'trilhas':
            esperado[s['id']] = str(sum(t['n'] for t in s['itens']))
        elif s['tipo'] in ('lista', 'depoimentos', 'faq'):
            esperado[s['id']] = str(len(s['itens']))
        elif s['tipo'] == 'oferta' and s.get('preco'):
            esperado[s['id']] = s['preco']['por']
        elif s['tipo'] == 'agenda' and s.get('numero'):
            esperado[s['id']] = preencher(s['numero'][0])
        elif s['tipo'] == 'equipe' and s.get('numeros'):
            esperado[s['id']] = preencher(s['numeros'][0][0])
    lidos = {k: txt(pg, f'#s-{k} .porta-num b') for k in esperado}
    sem_num = [s['id'] for s in SEC if s['id'] not in esperado and pg.locator(f'#s-{s["id"]} .porta-num').count()]
    check(lidos == esperado and not sem_num, f'números nas portas = JSON {lidos}' + (f'; número a mais em {sem_num}' if sem_num else ''))
    check(pg.locator(f'#s-{TIPO["trilhas"]} .lombada').count() == len(POR[TIPO["trilhas"]]['itens']), 'a porta das trilhas mostra uma lombada por trilha')
    check(pg.locator('.jev-topbar .jev-metric').count() >= 3 and pg.locator('.jev-topbar .jev-arch-btn').count() == 1, 'topbar do kit (métricas, Arquitetura, inspetor)')
    check(pg.locator('#lenteVazio').is_visible(), 'Lente do Jev visível, esperando a primeira abertura')
    shot(pg, '01-inicio.png')

    # ================================================================== 2
    secao('Cada seção abre e fecha, com os itens aninhados')

    def abre(sid):
        clique(pg, f'#b-{sid}')
        pg.wait_for_timeout(200)
        return pg.get_attribute(f'#b-{sid}', 'aria-expanded') == 'true' and pg.locator(f'#c-{sid}').is_visible()

    def fecha(sid):
        clique(pg, f'[data-fechar="{sid}"]')
        pg.wait_for_timeout(150)
        return pg.get_attribute(f'#b-{sid}', 'aria-expanded') == 'false' and pg.locator(f'#c-{sid}').is_hidden()

    for s in SEC:
        sid, t = s['id'], s['tipo']
        check(abre(sid), f'{sid} ({t}): abre')
        if t == 'dores':
            check(txt(pg, f'#c-{sid} .sec-h') == s['titulo'] and pg.locator(f'#c-{sid} .dor').count() == len(s['dores']), f'{sid}: título e as {len(s["dores"])} dores do JSON')
        elif t == 'trilhas':
            ok = True
            for tr in s['itens']:
                clique(pg, f'#ib-{sid}-{tr["id"]}')
                ok &= pg.locator(f'#d-{sid}-{tr["id"]}').is_visible() and pg.locator(f'#d-{sid}-{tr["id"]} .bloco').count() == len(tr['blocos'])
                for i, b in enumerate(tr['blocos']):
                    clique(pg, f'#bb-{tr["id"]}-{i}')
                    n = b['n'] if b.get('resumo') else len(b['itens'])
                    ok &= pg.locator(f'#bd-{tr["id"]}-{i} li').count() == len(b['itens']) and txt(pg, f'#bb-{tr["id"]}-{i} .bloco-n').startswith(f'{n} ') and txt(pg, f'#bd-{tr["id"]}-{i} li') == b['itens'][0]
                    clique(pg, f'#bb-{tr["id"]}-{i}')
                if tr is s['itens'][0]:
                    clique(pg, f'#bb-{tr["id"]}-0')
                    pg.evaluate(f"document.getElementById('s-{sid}').scrollIntoView({{block:'start', behavior:'instant'}}); window.scrollBy(0, -70)")
                    shot(pg, '02-trilhas.png')
                    clique(pg, f'#bb-{tr["id"]}-0')
                clique(pg, f'#ib-{sid}-{tr["id"]}')
                ok &= pg.locator(f'#d-{sid}-{tr["id"]}').is_hidden()
            check(ok, f'{sid}: as {len(s["itens"])} trilhas abrem com os blocos e subitens do JSON (e fecham)')
        elif t == 'lista':
            its = s['itens']
            busca = len(its) >= 17
            vis = pg.locator(f'#c-{sid} .grade > .item').count()
            check(vis == (min(12, len(its)) if busca else len(its)), f'{sid}: {vis} cartões na primeira página ({"12 por vez" if busca else "todos"})')
            if busca:
                check(f'Mostrando 12 de {len(its)}' in txt(pg, f'#c-{sid} .lista-info'), f'{sid}: “Mostrando 12 de {len(its)}”')
                palavra = norm(its[0]['nome']).split()[0][:6]
                pg.fill(f'#c-{sid} .busca-in', palavra)
                pg.wait_for_timeout(700)
                esp = busca_py(its, palavra)
                nomes = pg.eval_on_selector_all(f'#c-{sid} .grade > .item .item-nome', 'els => els.map(e => e.textContent.trim())')
                check(sorted(nomes) == sorted(x['nome'] for x in esp[:12]) or len(nomes) == min(12, len(esp)), f'{sid}: busca “{palavra}” → {len(esp)} resultado(s), pela regra do JSON')
                pg.fill(f'#c-{sid} .busca-in', '')
                pg.wait_for_timeout(500)
                grupos = {}
                for x in its:
                    grupos[x.get('grupo')] = grupos.get(x.get('grupo'), 0) + 1
                if None not in grupos and len(grupos) >= 3:
                    abas = pg.eval_on_selector_all(f'#c-{sid} [data-aba]', 'els => els.map(e => [e.dataset.aba, e.querySelector("i").textContent])')
                    check(abas[0] == ['', str(len(its))] and {a: int(n) for a, n in abas[1:]} == grupos, f'{sid}: aba “Todos” + {len(grupos)} grupos com as contagens do JSON')
                if len(its) > 12:
                    clique(pg, f'#c-{sid} .bt-mais')
                    pg.wait_for_timeout(250)
                    check(pg.locator(f'#c-{sid} .grade > .item').count() == min(24, len(its)), f'{sid}: “Mostrar mais” → {min(24, len(its))}')
            x = its[0]
            clique(pg, f'#ib-{sid}-{x["id"]}')
            check(txt(pg, f'#d-{sid}-{x["id"]} p') == x['desc'], f'{sid}: o item abre com a descrição do JSON')
            clique(pg, f'#ib-{sid}-{x["id"]}')
        elif t == 'depoimentos':
            textos = pg.eval_on_selector_all(f'#c-{sid} .depo-txt', 'els => els.map(e => e.textContent.trim())')
            check(sorted(textos) == sorted(f'“{d["texto"]}”' for d in s['itens']), f'{sid}: os {len(s["itens"])} depoimentos do JSON')
            if s.get('exemplo'):
                check(pg.locator(f'#c-{sid} .tag-exemplo').count() == len(s['itens']) and txt(pg, f'#b-{sid} .porta-tit') == 'Exemplos de depoimentos', f'{sid}: marcados como exemplo')
        elif t == 'faq':
            ok = pg.locator(f'#c-{sid} .faq-it').count() == len(s['itens'])
            for f in s['itens']:
                clique(pg, f'#fb-{f["id"]}')
                ok &= txt(pg, f'#fr-{f["id"]} p') == f['resposta']
                clique(pg, f'#fb-{f["id"]}')
            check(ok, f'{sid}: as {len(s["itens"])} perguntas abrem com a resposta oficial e fecham')
        elif t == 'oferta':
            inc = pg.eval_on_selector_all(f'#c-{sid} .inc span', 'els => els.map(e => e.textContent.trim())')
            check(sorted(inc) == sorted(x['texto'] for x in s['inclui']), f'{sid}: os {len(s["inclui"])} inclusos do JSON')
            check((txt(pg, f'#c-{sid} .oferta-por b') == s['preco']['por']) if s.get('preco') else ('Fale com a gente' in txt(pg, f'#c-{sid} .oferta-card')), f'{sid}: preço do JSON (ou “Fale com a gente”)')
            pg.evaluate(f"document.getElementById('s-{sid}').scrollIntoView({{block:'start', behavior:'instant'}}); window.scrollBy(0, -70)")
            pg.wait_for_timeout(300)
            shot(pg, '03-oferta.png')
        elif t == 'para_quem':
            check(pg.locator(f'#c-{sid} .pq-sim li').count() == len(s['sim']) and pg.locator(f'#c-{sid} .pq-nao li').count() == len(s['nao']), f'{sid}: sim e não do JSON')
        elif t == 'espacos':
            check(pg.locator(f'#c-{sid} .espaco').count() == len(s['cards']), f'{sid}: os cartões do JSON')
        elif t == 'agenda':
            check(pg.locator(f'#c-{sid} .agenda-linha li').count() == len(s['datas']), f'{sid}: as datas do JSON')
        elif t == 'conversa':
            check(pg.locator(f'#c-{sid} .msg').count() == 3 and pg.locator(f'#c-{sid} .checks li').count() == len(s['itens']), f'{sid}: itens e a conversa de exemplo')
        elif t == 'equipe':
            check(pg.locator(f'#c-{sid} .pessoa').count() == len(s['pessoas']), f'{sid}: as pessoas do JSON')
        check(fecha(sid), f'{sid}: fecha pelo botão do fim')
    minimo = max(3, len(IDS) // 3)
    if not SEM_JEV:
        pg.wait_for_timeout(2500)
        check(pg.evaluate('jevUx.decisoes.length') >= minimo, f'o Jev decidiu enquanto as seções abriam ({pg.evaluate("jevUx.decisoes.length")} decisões; mínimo {minimo})')
        check(pg.evaluate('document.getElementById("lenteVazio").hidden'), 'a Lente do Jev mostra perfil, interesse, dúvida e chance')

    # ================================================================== 3
    secao('Nada inventado: preços, cupom, desconto e links de pagamento')
    for sid in IDS:
        if pg.get_attribute(f'#b-{sid}', 'aria-expanded') == 'false':
            clique(pg, f'#b-{sid}')
    pg.wait_for_timeout(400)
    texto = pg.evaluate('() => document.body.innerText')
    bruto = json.dumps(D, ensure_ascii=False)
    desc = (HERE.parent / 'dev' / 'descricao.txt').read_text()
    valores = set(re.findall(r'R\$[  ]?\d[\d.,]*', texto))
    permitidos = set(re.findall(r'R\$[  ]?\d[\d.,]*', bruto))
    check(valores <= permitidos, f'todo valor em R$ na página existe no JSON: {sorted(valores)}')
    check('cupom' not in norm(texto), 'nenhum cupom na página')
    frases_desc = [f for f in re.split(r'(?<=[.!?])\s+', texto) if 'desconto' in norm(f)]
    check(all(f.strip() in bruto or 'desconto' in norm(desc) for f in frases_desc), f'“desconto” só em texto do JSON ({len(frases_desc)} ocorrência(s))')
    links = pg.eval_on_selector_all('a[href]', 'els => els.map(e => e.href)')
    ruins = [h for h in links if re.search(r'checkout|pagar\.me|pagarme|onprofit|hotmart|kiwify|stripe|pay\.|eduzz|monetizze|mercadopago|pagseguro', h, re.I)]
    check(not ruins, f'nenhum link para checkout real ({len(links)} links na página)')
    for sid in IDS:
        if pg.get_attribute(f'#b-{sid}', 'aria-expanded') == 'true':
            clique(pg, f'#b-{sid}')

    # ================================================================== 4
    if not SEM_JEV:
        secao('Contrato com o servidor (limpar() de server.mjs)')
        pg.wait_for_timeout(2500)
        ITENS = {s['id']: {str(x['id']) for x in s['itens']} for s in SEC if s['id'] in LISTAS}
        FAQ_IDS = {f['id'] for f in FQ['itens']}

        def valida_sinais(s):
            pr = []
            chaves = {'t', 'secao_atual', 'lista_em_foco', 'rolagem', 'abertas', 'itens', 'subitens', 'buscas', 'faq', 'preco', 'cta', 'cliques', 'ocioso_s', 'saida', 'guia', 'eventos'}
            if set(s) != chaves: pr.append(f'chaves {sorted(set(s) ^ chaves)}')
            num = lambda v, mx=10 ** 6: isinstance(v, (int, float)) and not isinstance(v, bool) and 0 <= v <= mx
            bo = lambda v: isinstance(v, bool)
            if not num(s.get('t'), 36000): pr.append('t')
            if s.get('secao_atual') not in IDS + ['topo']: pr.append('secao_atual')
            if s.get('lista_em_foco') not in LISTAS + ['']: pr.append('lista_em_foco')
            r = s.get('rolagem') or {}
            if not (num(r.get('max'), 100) and num(r.get('atual'), 100) and num(r.get('inversoes_20s'), 99) and num(r.get('rapidas_20s'), 99) and bo(r.get('desceu_rapido')) and bo(r.get('subiu_rapido'))): pr.append('rolagem')
            for a in s.get('abertas') or []:
                if a.get('id') not in IDS or not (num(a.get('ordem'), 99) and num(a.get('vezes'), 99) and num(a.get('aberta_s'), 36000) and bo(a.get('aberta_agora')) and bo(a.get('fechou_rapido'))): pr.append(f'aberta {a}')
            it = s.get('itens') or []
            if len(it) > 14: pr.append('itens > 14')
            for i in it:
                if i.get('secao') not in ITENS or str(i.get('id')) not in ITENS[i['secao']] or not isinstance(i.get('id'), str) or i.get('acao') not in ACOES_ITEM or not num(i.get('s'), 3600): pr.append(f'item {i}')
            bl = (s.get('subitens') or {}).get('blocos')
            if not isinstance(bl, list) or len(bl) > 6 or any(len(b) > 60 or not b.strip() for b in bl): pr.append('blocos')
            if len(s.get('buscas') or []) > 4 or any(len(b) > 40 for b in s.get('buscas') or []): pr.append('buscas')
            if any(x not in FAQ_IDS for x in s.get('faq') or []) or len(set(s.get('faq') or [])) != len(s.get('faq') or []): pr.append('faq')
            pc = s.get('preco') or {}
            if not (num(pc.get('hover_s'), 3600) and num(pc.get('vezes'), 99) and bo(pc.get('copiou'))): pr.append('preco')
            c = s.get('cta') or {}
            if not (num(c.get('cliques'), 99) and bo(c.get('checkout_aberto')) and num(c.get('campos'), 9) and num(c.get('erros'), 99) and bo(c.get('entrou'))): pr.append('cta')
            g = s.get('guia') or {}
            if any(a not in ACOES for a in g.get('acoes', [])) or g.get('sugeriu') not in IDS + ['']: pr.append('guia')
            ev = s.get('eventos')
            if not isinstance(ev, list) or len(ev) > 10 or any(len(e) > 60 or not e.strip() for e in ev): pr.append('eventos')
            return pr

        probs = []
        for s in enviados:
            probs += valida_sinais(s) if '_erro' not in s else [s['_erro']]
        check(len(enviados) >= minimo and not probs, f'{len(enviados)} resumos enviados; todos batem com limpar(){"" if not probs else ": " + "; ".join(probs[:4])}')
        status = [st for st, _ in respostas]
        check(status and all(st == 200 for st in status), f'{len(status)} respostas de /api/decidir, todas 200 ({sorted(set(status))})')
        fmt = [k for st, c in respostas if st == 200 for k in ('perfil', 'interesse', 'proxima', 'objecao', 'acao', 'trilha', 'prob_entrar', 'latency_ms', 'n_perguntas', '_jev') if k not in (c or {})]
        check(not fmt, 'respostas no formato (perfil, interesse, proxima, destaque, objecao, acao, trilha, depoimento, prob_entrar, latency_ms)')
        todas = {**enviados[-1], 'abertas': [{'id': k, 'ordem': i + 1, 'vezes': 1, 'aberta_s': 3, 'aberta_agora': False, 'fechou_rapido': False} for i, k in enumerate(IDS)]}
        r = ctx.request.post(URL + 'api/decidir', data={'sinais': todas})
        j = r.json()
        check(r.status == 200 and j.get('ok') and j['proxima'].get('ranking') == [], 'caso-limite: com todas as seções abertas o Jev ainda responde (sem “próxima”)')
        r = ctx.request.post(URL + 'api/decidir', data={'nada': 1})
        check(r.status == 400, 'sem sinais → 400')
    ctx.close()

    # ================================================================== 5
    secao(f'{"Pagamento" if PAG else "Contato"} de DEMONSTRAÇÃO')
    enviados.clear()
    ctx, pg = nova_pagina(rotulo='checkout')
    abrir(pg)
    prod = [s['id'] for s in SEC if s.get('produto')]
    if prod:
        clique(pg, f'#b-{prod[0]}')
        pg.wait_for_timeout(1200)
    clique(pg, '[data-cta="topo"]')
    pg.wait_for_timeout(500)
    aviso = 'demonstração — nenhuma cobrança' if PAG else 'demonstração — nada é enviado'
    check(pg.locator('#checkout').is_visible() and aviso in txt(pg, '#checkout .ck-demo'), f'o botão do topo abre o {"pagamento" if PAG else "contato"} escrito “{aviso}”')
    check(pg.evaluate('document.activeElement && document.activeElement.name') == 'nome', 'foco vai para o primeiro campo')
    if prod:
        check(POR[prod[0]]['nome'] in txt(pg, '#ckAbriu'), 'o resumo lista o que a pessoa abriu (“Tudo o que você abriu está incluso”)')
    shot(pg, '04-checkout-demo.png')
    pg.click('#ckForm button[type=submit]')
    pg.wait_for_timeout(300)
    check(txt(pg, '#ckErr') != '' and (SEM_JEV or pg.evaluate('jevUx.sinais().cta.erros') == 1), 'enviar vazio mostra o erro' + ('' if SEM_JEV else ' e vira sinal (cta.erros)'))
    pg.fill('#ckForm [name=nome]', 'Ana Souza')
    pg.fill('#ckForm [name=email]', 'ana@exemplo.com')
    pg.click('#ckForm button[type=submit]')
    pg.wait_for_timeout(400)
    check(pg.locator('#ckOk').is_visible() and '(demonstração)' in txt(pg, '#ckOk') and 'Nenhum' in txt(pg, '#ckOk'), 'concluir mostra “Você … (demonstração)”, sem cobrança e sem envio')
    if not SEM_JEV:
        t0 = time.time()
        while time.time() - t0 < 12 and not any(s.get('cta', {}).get('entrou') for s in enviados):
            pg.wait_for_timeout(300)
        check(any(s.get('cta', {}).get('entrou') for s in enviados), 'a conclusão vira o sinal cta.entrou enviado ao Jev')
    pg.keyboard.press('Escape')
    pg.wait_for_timeout(300)
    check(not pg.locator('#checkout').is_visible(), 'Esc fecha o diálogo')
    ctx.close()

    # ================================================================== 6
    secao('Acessibilidade e movimento reduzido')
    ctx, pg = nova_pagina(rotulo='a11y', reduzido=True)
    abrir(pg)
    alvo = IDS[1]
    pg.focus(f'#b-{alvo}')
    pg.keyboard.press('Shift+Tab')
    pg.keyboard.press('Tab')
    foco = pg.evaluate('() => { const e = document.activeElement; const cs = getComputedStyle(e); return [e.id, cs.outlineStyle, parseFloat(cs.outlineWidth)]; }')
    check(foco[0] == f'b-{alvo}' and foco[1] != 'none' and foco[2] >= 1, f'foco visível no botão da porta ({foco})')
    pg.keyboard.press('Enter')
    pg.wait_for_timeout(300)
    check(pg.get_attribute(f'#b-{alvo}', 'aria-expanded') == 'true', 'Enter no teclado abre a porta')
    rodando = pg.evaluate('() => document.getAnimations().filter(a => a.playState === "running").length')
    check(rodando == 0, f'prefers-reduced-motion: nenhuma animação rodando ({rodando})')
    ctx.close()

    # ================================================================== 7
    secao('Celular 390×844')
    ctx, pg = nova_pagina(390, 844, rotulo='celular', dsf=2, is_mobile=True, has_touch=True)
    abrir(pg)
    largura = lambda: pg.evaluate('() => Math.max(document.documentElement.scrollWidth, document.body.scrollWidth)')
    check(largura() <= 390, f'sem rolagem lateral no topo ({largura()} px)')
    check(pg.locator('.doca').is_visible() and pg.locator('.doca .cta-jev').is_visible(), 'barra fixa com a chamada e o botão do Jev')
    shot(pg, '05-celular-topo.png')
    busca = next((s['id'] for s in SEC if s['tipo'] == 'lista' and len(s['itens']) >= 17), LISTAS[0])
    for sid in (IDS[1], busca):
        pg.evaluate(f"document.getElementById('s-{sid}').scrollIntoView({{block:'start', behavior:'instant'}}); window.scrollBy(0, -70)")
        pg.tap(f'#b-{sid}')
        pg.wait_for_timeout(1200)
    if pg.locator(f'#c-{busca} .busca-in').count():
        pg.fill(f'#c-{busca} .busca-in', norm(POR[busca]['itens'][0]['nome'])[:5])
        pg.wait_for_timeout(3500)
    pg.evaluate(f"document.getElementById('s-{busca}').scrollIntoView({{block:'start', behavior:'instant'}}); window.scrollBy(0, -70)")
    pg.wait_for_timeout(300)
    check(largura() <= 390, f'sem rolagem lateral com seções abertas e busca ({largura()} px)')
    shot(pg, '06-celular-lista.png')
    pg.tap('#docaJev')
    pg.wait_for_timeout(600)
    check('aberto' in (pg.get_attribute('#trilho', 'class') or '') and pg.locator('#lente').is_visible(), 'o botão do Jev abre a folha com a Lente, a trilha e o mapa')
    shot(pg, '07-celular-folha-do-jev.png')
    pg.keyboard.press('Escape')
    pg.wait_for_timeout(500)
    check('aberto' not in (pg.get_attribute('#trilho', 'class') or ''), 'Esc fecha a folha')
    pg.tap('.doca .cta-jev')
    pg.wait_for_timeout(600)
    caixa = pg.locator('#checkout').bounding_box()
    check(pg.locator('#checkout').is_visible() and caixa and caixa['x'] >= 0 and caixa['x'] + caixa['width'] <= 390, 'o diálogo de demonstração cabe na tela do celular')
    pg.keyboard.press('Escape')
    ctx.close()

    # ================================================================== 8
    SIMS = {sm['id']: sm for sm in D['simulacoes']}
    PEDIDAS = [] if ('--sem-sims' in sys.argv or SEM_JEV) else (sys.argv[sys.argv.index('--sims') + 1].split(',') if '--sims' in sys.argv else list(SIMS))
    MOMENTO = {  # foto no instante em que a adaptação principal aparece (campo "captura" da simulação)
        'duvida': '() => !!document.querySelector(".faq-it.jev-duvida") || (!document.getElementById("cartao").hidden && document.getElementById("cartao").dataset.tipo === "objecao")',
        'saida': '() => document.getElementById("dlgSaida").open',
        'prova': '() => { const b = document.querySelector(".oferta-prova"); return !!b && !b.hidden; }',
    }

    def rodar_sim(sim, w=1440, h=900, **kw):
        ctx, pg = nova_pagina(w, h, rotulo=f'sim {sim}', **kw)
        abrir(pg, f'?sim={sim}')
        pg.wait_for_function('() => window.jevUx && jevUx.simInicio', timeout=15000)
        visita = pg.evaluate('jevUx.simInicio.visita')
        t0 = time.time()
        cap = SIMS[sim].get('captura', '')
        cond = (f'() => !!document.querySelector("#c-{cap[5:]} .item.pv, #c-{cap[5:]} .trilha.pv")' if cap.startswith('pins:') else MOMENTO.get(cap)) if w >= 800 else None
        while time.time() - t0 < 160 and not pg.evaluate(f'() => !!(jevUx.simFim && jevUx.simFim.visita === {visita})'):
            if cond and pg.evaluate(cond):
                pg.wait_for_timeout(900)
                shot(pg, f'sim-{sim}-momento.png')
                cond = None
            pg.wait_for_timeout(400)
        terminou = pg.evaluate(f'() => !!(jevUx.simFim && jevUx.simFim.visita === {visita})')
        pg.wait_for_timeout(1500)
        dec = pg.evaluate(f'() => jevUx.decisoes.filter(d => d.visita === {visita})')
        ad = pg.evaluate(f'() => jevUx.adaptacoes.filter(a => a.visita === {visita})')
        dom = pg.evaluate('''() => ({ resumo: !document.getElementById('simResumo').hidden, erro: jevUx.simErro || null, saidas: jevUx.saidas || [],
            faqMarcado: [...document.querySelectorAll('.faq-it.jev-duvida')].map(e => e.dataset.faq), trilha: !document.getElementById('minhaTrilha').hidden })''')
        shot(pg, f'sim-{sim}{"-celular" if w < 800 else ""}.png')
        tipos = sorted({a['tipo'] for a in ad})
        print(f'    {len(dec)} decisões · {time.time() - t0:.0f} s · adaptações: {tipos}')
        for d in dec[-3:]:
            print(f"      · {d['perfil']} {d['p_perfil']:.2f} · quer {d['interesse']} · próxima {d['proxima']} {d['p_proxima']:.2f} · dúvida {d['objecao']} {d['p_objecao']:.2f} · ação {d['acao']} {d['p_acao']:.2f} → {d['politica']}")
        check(terminou and not dom['erro'], f'{sim}: a simulação terminou sozinha, sem erro {dom["erro"] or ""}')
        check(dom['resumo'], f'{sim}: mostrou o resumo “o que a página mudou para este visitante”')
        check(len(tipos) >= 2, f'{sim}: {len(tipos)} tipos de adaptação visível (≥ 2)')
        if not any(p_['f'] == 'sairPeloTopo' for p_ in SIMS[sim]['passos']):
            check(not dom['saidas'], f'{sim}: nenhuma “saída pelo topo” falsa {dom["saidas"][:2]}')
        ctx.close()
        return dec, ad, dom

    def teve(dec, campo, valor, pmin=0.5):
        return any(d.get(campo) == valor and (d.get('p_' + campo) or 0) >= pmin for d in dec)

    for sim in PEDIDAS:
        secao(f'Simulação {sim} (cursor fantasma, eventos reais, Jev de verdade)')
        dec, ad, dom = rodar_sim(sim)
        ej = SIMS[sim].get('espera_jev', {})
        tipos = {a['tipo'] for a in ad}
        if ej.get('perfil'):
            check(teve(dec, 'perfil', ej['perfil']), f'o Jev leu o perfil “{ej["perfil"]}” (≥ 50% em alguma decisão)')
        if ej.get('objecao'):
            fid = next(o['faq'] for o in D['jev']['objecoes'] if o['id'] == ej['objecao'])
            check(teve(dec, 'objecao', ej['objecao'], 0.6), f'o Jev leu a dúvida “{ej["objecao"]}” (≥ 60%)')
            check(any(a['tipo'] in ('duvida', 'acao:responder_objecao', 'resposta-pedida') and a.get('faq') == fid for a in ad) or fid in dom['faqMarcado'], f'a dúvida apareceu com a resposta OFICIAL ({fid})')
        if ej.get('pins'):
            sec_ = ej['pins']['secao']
            ids = {i for a in ad if a['tipo'] == 'pins' and a.get('secao') == sec_ for i in a.get('ids', [])}
            check(bool(ids), f'“Para você” apareceu em {sec_} ({len(ids)} item(ns))')
            if ej['pins'].get('item'):
                nomes = [x['nome'] for x in POR[sec_]['itens'] if str(x['id']) in ids]
                check(any(n.startswith(ej['pins']['item']) for n in nomes), f'“{ej["pins"]["item"]}” entre os “Para você” de {sec_} ({nomes})')
        if ej.get('saida'):
            s_ = [a for a in ad if a['tipo'] == 'acao:segurar_saida']
            check(bool(s_), 'segurou a saída com o resumo do que a pessoa abriu')
            if s_ and OF.get('preco'):
                pr = OF['preco']
                check(f'{pr["por"]}{pr["periodo"]}' in s_[0]['txt'] and (not pr.get('a_partir') or 'a partir de' in s_[0]['txt']), 'o aviso cita o preço real (sem desconto inventado)')
            elif s_:
                check('Fale com a gente' in s_[0]['txt'], 'sem preço, o aviso diz “Fale com a gente”')
            if s_ and OF.get('garantia'):
                check(OF['garantia']['frase'] in s_[0]['txt'], 'o aviso cita a garantia real')
        if ej.get('prova'):
            check('prova' in tipos or 'acao:mostrar_prova' in tipos, 'mostrou o depoimento de alguém parecido (prova sob medida)')
        nota('trilha' in tipos or dom['trilha'], 'a “Sua trilha” se montou')
    if PEDIDAS:
        secao('Uma simulação no celular (390×844)')
        dec, ad, dom = rodar_sim(PEDIDAS[0], 390, 844, dsf=2, is_mobile=True, has_touch=True)
        ej = SIMS[PEDIDAS[0]].get('espera_jev', {})
        if ej.get('perfil'):
            check(teve(dec, 'perfil', ej['perfil']), f'celular: o Jev leu o perfil “{ej["perfil"]}”')

    # ================================================================== fim
    secao('Console')
    check(not erros, f'zero erros de console ({len(erros)})')
    for e in erros[:10]:
        print('     ', e)
    browser.close()

print(f'\n{len(falhas)} falha(s), {len(avisos)} aviso(s) suave(s) em {time.time() - t_inicio:.0f} s')
for f in falhas:
    print('  ✗', f)
for a in avisos:
    print('  ~', a)
sys.exit(1 if falhas else 0)
