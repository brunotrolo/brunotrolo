#!/usr/bin/env python3
"""Confere public/dados/site.json antes de seguir: esquema, mínimos, referências e honestidade.
Uso: python3 apps/site/dev/validar_site.py   (sai com 1 e lista os erros; 0 = pode seguir)
     python3 apps/site/dev/validar_site.py --site <site.json> --descricao <descricao.txt> --fontes <fontes.json>   (outro trio)"""
import json, pathlib, re, sys, unicodedata

APP = pathlib.Path(__file__).resolve().parents[1]
def arg(nome, padrao):
    return pathlib.Path(sys.argv[sys.argv.index(nome) + 1]) if nome in sys.argv else padrao
SITE = json.loads(arg('--site', APP / 'public' / 'dados' / 'site.json').read_text())
DESC = arg('--descricao', APP / 'dev' / 'descricao.txt').read_text()
FONTES_ARQ = arg('--fontes', APP / 'dev' / 'fontes.json')
erros, avisos = [], []
def erro(m): erros.append(m)
def aviso(m): avisos.append(m)

PALETAS = {'noite-ouro': '#0c0d0e', 'cafe-caramelo': '#0f0c0b', 'floresta-salvia': '#0a0e0b', 'vinho-rose': '#100c0d',   # id → --bg
           'marinho-areia': '#0b0d10', 'terracota': '#100c0b', 'grafite-lima': '#0c0d0e'}
FONTES = ['editorial', 'artesanal', 'jornal', 'elegante', 'tecnologico', 'amigavel', 'acolhedor']
ICONES = ['relogio', 'livros', 'robo', 'blocos', 'raio', 'arquivo', 'engrenagem', 'ondas', 'boia', 'pessoas', 'balao', 'pessoa', 'alvo',
          'cartao', 'interrogacao', 'xicara', 'calendario', 'estrela', 'folha', 'casa', 'presente', 'grafico', 'pin', 'coracao', 'sacola',
          'livro', 'ferramenta']
TIPOS = {'dores': (0, 1), 'trilhas': (1, 1), 'lista': (1, 5), 'agenda': (0, 1), 'conversa': (0, 1), 'espacos': (0, 1),
         'depoimentos': (0, 1), 'equipe': (0, 1), 'para_quem': (1, 1), 'oferta': (1, 1), 'faq': (1, 1)}
PASSOS = {'abrirPorta': ['secao'], 'lerSecao': ['secao', 'ms'], 'abrirItem': ['secao', 'item', 'ler_ms'], 'abrirTrilha': ['trilha', 'ler_ms'],
          'abrirBloco': ['trilha', 'bloco', 'ler_ms'], 'buscar': ['secao', 'q'], 'esperarPins': ['secao', 'ms', '?item'],
          'abrirPrimeiroPin': ['secao', 'ler_ms'], 'abrirFaq': ['faq', 'ler_ms'], 'esperarDuvida': ['faq', 'ms'],
          'esperarRecomendacao': ['secao', 'ms'], 'seguirRecomendacao': ['clicar'], 'olharTrilha': ['?esperar_ms'],
          'pairarPreco': ['ms'], 'copiarPreco': [], 'olharChamada': [], 'voltarAoTopo': [], 'sairPeloTopo': [], 'esperarProva': []}
CHECKOUT_RE = re.compile(r'checkout|pagar\.me|pagarme|onprofit|hotmart|kiwify|stripe|pay\.|eduzz|monetizze|mercadopago|pagseguro', re.I)
SEM_ACENTO = re.compile(r'\b(nao|voce|voces|acao|acoes|sao|entao|tambem|pagina|informacao|conteudo|duvida|duvidas|preco|precos|servico|servicos|historia|experiencia|unico|unica|facil|rapido|proximo|agua|cafe|voce)\b', re.I)

def norm(s): return ' '.join(unicodedata.normalize('NFKC', str(s)).replace('“', '"').replace('”', '"').replace('’', "'").split()).lower()
DESC_N = norm(DESC)
NUM_DESC = set(re.findall(r'\d+', DESC.replace('.', '')))
def sem_acento(s): return ''.join(c for c in unicodedata.normalize('NFD', str(s)) if unicodedata.category(c) != 'Mn').lower()
EXTENSO = {'dois': 2, 'duas': 2, 'tres': 3, 'quatro': 4, 'cinco': 5, 'seis': 6, 'sete': 7, 'oito': 8, 'nove': 9, 'dez': 10, 'onze': 11,
           'doze': 12, 'treze': 13, 'catorze': 14, 'quatorze': 14, 'quinze': 15, 'dezesseis': 16, 'dezessete': 17, 'dezoito': 18,
           'dezenove': 19, 'vinte': 20, 'trinta': 30, 'quarenta': 40, 'cinquenta': 50, 'sessenta': 60, 'setenta': 70, 'oitenta': 80,
           'noventa': 90, 'cem': 100, 'cento': 100, 'duzentos': 200, 'trezentos': 300, 'quinhentos': 500, 'mil': 1000,
           'milhao': 1000000, 'milhoes': 1000000, 'dezena': 10, 'dezenas': 10, 'duzia': 12, 'duzias': 12, 'centena': 100, 'centenas': 100}
PALAVRAS_DESC = set(re.findall(r'[a-z]+', sem_acento(DESC)))

def texto(v, campo, mn=1, mx=400):
    if not isinstance(v, str) or not v.strip(): erro(f'{campo}: texto vazio ou ausente'); return ''
    if len(v) < mn or len(v) > mx: erro(f'{campo}: {len(v)} caracteres (esperado {mn}–{mx})')
    return v

def lista(v, campo, mn, mx):
    if not isinstance(v, list): erro(f'{campo}: precisa ser lista'); return []
    if not (mn <= len(v) <= mx): erro(f'{campo}: {len(v)} itens (esperado {mn}–{mx})')
    return v

S = SITE
CHAVES = {'versao', 'fonte', 'marca', 'identidade', 'conversao', 'hero', 'pilares_titulo', 'pilares', 'secoes', 'final', 'jev', 'simulacoes'}
if set(S) != CHAVES: erro(f'chaves do topo: sobram {sorted(set(S) - CHAVES)}, faltam {sorted(CHAVES - set(S))}')
if S.get('versao') != 1: erro('versao precisa ser 1')

# ------------------------------------------------------------------ seções
SEC = S.get('secoes') or []
lista(SEC, 'secoes', 5, 15)
POR_ID, TIPO_ID = {}, {}
for i, s in enumerate(SEC):
    c = f'secoes[{i}]'
    sid = s.get('id', '')
    if not re.fullmatch(r'[a-z][a-z0-9_]{1,23}', sid or '') or sid in ('topo', 'nenhuma'): erro(f'{c}.id “{sid}” inválido ([a-z][a-z0-9_], 2–24, nem topo nem nenhuma)')
    if sid in POR_ID: erro(f'{c}.id “{sid}” repetido')
    POR_ID[sid] = s
    if s.get('tipo') not in TIPOS: erro(f'{c}.tipo “{s.get("tipo")}” desconhecido ({", ".join(TIPOS)})')
    TIPO_ID.setdefault(s.get('tipo'), []).append(sid)
    texto(s.get('nome'), f'{c}.nome', 3, 32); texto(s.get('kicker'), f'{c}.kicker', 3, 32); texto(s.get('promessa'), f'{c}.promessa', 20, 140)
    texto(s.get('jev'), f'{c}.jev', 60, 420)
    if 'Vale mais para' not in (s.get('jev') or ''): erro(f'{c}.jev: termine com “Vale mais para quem …” (é o critério da pergunta “proxima”)')
    if s.get('icone') not in ICONES: erro(f'{c}.icone “{s.get("icone")}” fora da lista')
    if not isinstance(s.get('emoji'), str) or not s['emoji'] or len(s['emoji']) > 4: erro(f'{c}.emoji: um emoji')
    if not isinstance(s.get('produto'), bool): erro(f'{c}.produto: true ou false')
for t, (mn, mx) in TIPOS.items():
    n = len(TIPO_ID.get(t, []))
    if not (mn <= n <= mx): erro(f'seções do tipo {t}: {n} (esperado {mn}–{mx})')
if not any(s.get('produto') for s in SEC): aviso('nenhuma seção com produto: true (o resumo de saída e o convite não terão o que citar)')

def contar(s):
    t = s.get('tipo')
    if t in ('trilhas', 'lista', 'depoimentos', 'faq'): return len(s.get('itens') or [])
    if t == 'espacos': return len(s.get('cards') or [])
    return None

def placeholders(v, campo):
    for tipo, sid in re.findall(r'\{(n|total):([a-z0-9_]+)\}', v or ''):
        s = POR_ID.get(sid)
        if not s: erro(f'{campo}: {{{tipo}:{sid}}} aponta para seção que não existe')
        elif tipo == 'n' and contar(s) is None: erro(f'{campo}: {{n:{sid}}} numa seção sem itens')
        elif tipo == 'total' and s.get('tipo') != 'trilhas': erro(f'{campo}: {{total:{sid}}} só vale para trilhas')
    return re.sub(r'\{(n|total):[a-z0-9_]+\}', '', v or '')

IDS_ITEM = {}
for i, s in enumerate(SEC):
    c, t = f'secoes[{i}] ({s.get("id")})', s.get('tipo')
    placeholders(s.get('jev'), f'{c}.jev'); placeholders(s.get('promessa'), f'{c}.promessa')
    if t == 'dores':
        texto(s.get('titulo'), f'{c}.titulo', 10, 110); texto(s.get('texto'), f'{c}.texto', 20, 320)
        for j, d in enumerate(lista(s.get('dores'), f'{c}.dores', 2, 4)):
            texto(d[0], f'{c}.dores[{j}][0]', 3, 60); texto(d[1], f'{c}.dores[{j}][1]', 20, 240)
    elif t == 'trilhas':
        texto(s.get('intro'), f'{c}.intro', 20, 280); texto(s.get('pergunta'), f'{c}.pergunta', 20, 100)
        if not re.match(r'Por (qual|quais|onde)', s.get('pergunta') or '') or not (s.get('pergunta') or '').endswith('?'): erro(f'{c}.pergunta: comece com “Por qual …” e termine com “?”')
        u = s.get('unidade') or []
        if len(u) != 2: erro(f'{c}.unidade: [singular, plural]')
        ids = set()
        for j, tr in enumerate(lista(s.get('itens'), f'{c}.itens', 2, 6)):
            cj = f'{c}.itens[{j}]'
            if not re.fullmatch(r'[a-z0-9][a-z0-9_-]{0,31}', tr.get('id', '')) or tr['id'] in ids: erro(f'{cj}.id inválido ou repetido')
            ids.add(tr.get('id'))
            texto(tr.get('nome'), f'{cj}.nome', 3, 40); texto(tr.get('curto'), f'{cj}.curto', 3, 24); texto(tr.get('frase'), f'{cj}.frase', 10, 90)
            texto(tr.get('desc'), f'{cj}.desc', 20, 400); texto(tr.get('rotulo_bloco'), f'{cj}.rotulo_bloco', 3, 16)
            if tr.get('nota') is not None: texto(tr.get('nota'), f'{cj}.nota', 5, 160)
            if tr.get('pelo') not in ('pelo', 'pela', 'pelos', 'pelas'): erro(f'{cj}.pelo: pelo, pela, pelos ou pelas')
            soma = 0
            for k, b in enumerate(lista(tr.get('blocos'), f'{cj}.blocos', 1, 12)):
                texto(b.get('titulo'), f'{cj}.blocos[{k}].titulo', 3, 80)
                its = lista(b.get('itens'), f'{cj}.blocos[{k}].itens', 1, 30)
                for m_, x in enumerate(its): texto(x, f'{cj}.blocos[{k}].itens[{m_}]', 2, 140)
                if b.get('resumo'):
                    if not isinstance(b.get('n'), int) or b['n'] < len(its): erro(f'{cj}.blocos[{k}]: resumo precisa de n ≥ itens')
                    soma += b.get('n') or 0
                else: soma += len(its)
            if tr.get('n') != soma: erro(f'{cj}.n = {tr.get("n")}, mas os blocos somam {soma}')
        IDS_ITEM[s['id']] = ids
    elif t == 'lista':
        fmt = s.get('formato')
        if fmt not in ('cartoes', 'largos', 'icones'): erro(f'{c}.formato: cartoes, largos ou icones')
        mn, mx = {'cartoes': (3, 60), 'largos': (2, 20), 'icones': (2, 6)}.get(fmt, (2, 60))
        its = lista(s.get('itens'), f'{c}.itens', mn, mx)
        u = s.get('unidade') or []
        if len(u) != 2: erro(f'{c}.unidade: [singular, plural]')
        if s.get('selo_item') is not None: texto(s.get('selo_item'), f'{c}.selo_item', 5, 40)
        if s.get('explicativo') is not None and not isinstance(s['explicativo'], bool): erro(f'{c}.explicativo: true ou false')
        ids = set()
        for j, x in enumerate(its):
            cj = f'{c}.itens[{j}]'
            if not re.fullmatch(r'[a-z0-9][a-z0-9_-]{0,31}', str(x.get('id', ''))) or x['id'] in ids: erro(f'{cj}.id inválido ou repetido')
            ids.add(x.get('id'))
            texto(x.get('nome'), f'{cj}.nome', 2, 40); texto(x.get('desc'), f'{cj}.desc', 10, 620 if fmt == 'largos' else 320)
            if fmt != 'icones': texto(x.get('frase'), f'{cj}.frase', 5, 90)
            if fmt == 'icones':
                texto(x.get('rotulo'), f'{cj}.rotulo', 2, 30)
                if x.get('icone') not in ICONES: erro(f'{cj}.icone fora da lista')
            if x.get('grupo') is not None: texto(x.get('grupo'), f'{cj}.grupo', 2, 40)
        grupos = {x.get('grupo') for x in its}
        if len(its) > 16 and None not in grupos and len(grupos) < 3: aviso(f'{c}: lista com busca e só {len(grupos)} grupos (as abas só aparecem com 3 ou mais)')
        IDS_ITEM[s['id']] = ids
    elif t == 'agenda':
        texto(s.get('desc'), f'{c}.desc', 20, 320)
        if s.get('numero') is not None and len(s['numero']) != 2: erro(f'{c}.numero: [valor, legenda] ou null')
        for j, d in enumerate(lista(s.get('datas'), f'{c}.datas', 1, 3)): texto(d[0], f'{c}.datas[{j}][0]', 3, 30); texto(d[1], f'{c}.datas[{j}][1]', 3, 80)
    elif t == 'conversa':
        texto(s.get('titulo'), f'{c}.titulo', 5, 80); texto(s.get('desc'), f'{c}.desc', 20, 320)
        lista(s.get('itens'), f'{c}.itens', 2, 5)
        ex = lista(s.get('exemplo'), f'{c}.exemplo', 3, 3)
        if [e[0] for e in ex] != ['cliente', 'equipe', 'cliente']: erro(f'{c}.exemplo: quem = cliente, equipe, cliente')
        r = s.get('rotulos') or {}
        if set(r) != {'cliente', 'equipe'}: erro(f'{c}.rotulos: {{cliente, equipe}}')
    elif t == 'espacos':
        texto(s.get('titulo'), f'{c}.titulo', 5, 90); texto(s.get('desc'), f'{c}.desc', 20, 320)
        for j, d in enumerate(lista(s.get('cards'), f'{c}.cards', 2, 6)): texto(d[0], f'{c}.cards[{j}][0]', 3, 50); texto(d[1], f'{c}.cards[{j}][1]', 10, 200)
        if s.get('chips') is not None: lista(s['chips'], f'{c}.chips', 1, 8)
    elif t == 'depoimentos':
        if not isinstance(s.get('exemplo'), bool): erro(f'{c}.exemplo: true (exemplos) ou false (reais)')
        its = lista(s.get('itens'), f'{c}.itens', 4 if s.get('exemplo') else 1, 6 if s.get('exemplo') else 10)
        ids = set()
        for j, d in enumerate(its):
            cj = f'{c}.itens[{j}]'
            if not re.fullmatch(r'[a-z0-9][a-z0-9_-]{0,31}', d.get('id', '')) or d['id'] in ids: erro(f'{cj}.id inválido ou repetido')
            ids.add(d.get('id'))
            texto(d.get('nome'), f'{cj}.nome', 2, 40); texto(d.get('texto'), f'{cj}.texto', 10, 300)
            if d.get('papel') is not None: texto(d.get('papel'), f'{cj}.papel', 3, 50)
            if not s.get('exemplo'):
                if norm(d.get('texto')) not in DESC_N: erro(f'{cj}: depoimento real precisa estar na descrição, palavra por palavra')
                if norm(d.get('nome')) not in DESC_N: erro(f'{cj}: nome “{d.get("nome")}” não está na descrição')
                if d.get('papel') and norm(d['papel']) not in DESC_N: erro(f'{cj}: papel “{d["papel"]}” não está na descrição (sem papel, deixe sem)')
        if s.get('exemplo'):
            if s.get('nome') != 'Exemplos de depoimentos': erro(f'{c}: com exemplo: true, o nome é “Exemplos de depoimentos”')
        IDS_ITEM[s['id']] = ids
    elif t == 'equipe':
        texto(s.get('titulo'), f'{c}.titulo', 5, 90); texto(s.get('sub'), f'{c}.sub', 10, 260)
        for j, p in enumerate(lista(s.get('pessoas'), f'{c}.pessoas', 1, 4)):
            texto(p.get('nome'), f'{c}.pessoas[{j}].nome', 3, 60); texto(p.get('papel'), f'{c}.pessoas[{j}].papel', 3, 80); texto(p.get('bio'), f'{c}.pessoas[{j}].bio', 20, 400)
            if norm(p.get('nome')) not in DESC_N: erro(f'{c}.pessoas[{j}]: “{p.get("nome")}” não está na descrição (ninguém inventado)')
        if s.get('numeros') is not None: lista(s['numeros'], f'{c}.numeros', 0, 3)
        if s.get('conquistas') is not None: lista(s['conquistas'], f'{c}.conquistas', 0, 5)
    elif t == 'para_quem':
        for j, x in enumerate(lista(s.get('sim'), f'{c}.sim', 2, 6)): texto(x, f'{c}.sim[{j}]', 10, 120)
        for j, x in enumerate(lista(s.get('nao'), f'{c}.nao', 0, 4)): texto(x, f'{c}.nao[{j}]', 10, 120)
    elif t == 'oferta':
        texto(s.get('rotulo'), f'{c}.rotulo', 5, 80); texto(s.get('cta'), f'{c}.cta', 5, 42)
        p = s.get('preco')
        if p is not None:
            if not re.fullmatch(r'R\$ ?\d[\d.]*(,\d{2})?', p.get('por', '')): erro(f'{c}.preco.por: “R$69” ou “R$ 1.490”')
            if p.get('de') is not None and not re.fullmatch(r'R\$ ?\d[\d.]*(,\d{2})?', p['de']): erro(f'{c}.preco.de: no mesmo formato, ou null')
            if not isinstance(p.get('periodo'), str): erro(f'{c}.preco.periodo: “/mês”, “/ano” ou “” (pagamento único)')
            if p.get('a_partir') is not None and not isinstance(p['a_partir'], bool): erro(f'{c}.preco.a_partir: true ou false')
            if p.get('a_partir') and p.get('de'): erro(f'{c}.preco: “a partir de” não combina com “de … por”')
        for j, x in enumerate(lista(s.get('planos_extras') or [], f'{c}.planos_extras', 0, 2)):
            texto(x.get('nome'), f'{c}.planos_extras[{j}].nome', 3, 40); texto(x.get('resumo'), f'{c}.planos_extras[{j}].resumo', 5, 120)
            if p is None: erro(f'{c}.planos_extras: só com preco')
        lista(s.get('selos'), f'{c}.selos', 0, 3)
        g = s.get('garantia')
        if g is not None and (not isinstance(g.get('dias'), int) or not g.get('frase')): erro(f'{c}.garantia: {{dias, frase}} ou null')
if TIPO_ID.get('oferta'):
    OF = POR_ID[TIPO_ID['oferta'][0]]
if TIPO_ID.get('faq'):
    FAQ = POR_ID[TIPO_ID['faq'][0]]
    fids = [f.get('id') for f in lista(FAQ.get('itens'), 'faq.itens', 3, 16)]
    if fids != [f'f{i + 1}' for i in range(len(fids))]: erro('faq.itens: ids f1, f2, … na ordem')
    for j, f in enumerate(FAQ.get('itens') or []):
        texto(f.get('pergunta'), f'faq.itens[{j}].pergunta', 8, 120); texto(f.get('resposta'), f'faq.itens[{j}].resposta', 5, 600)
        if f.get('explicativo') is not None and not isinstance(f['explicativo'], bool): erro(f'faq.itens[{j}].explicativo: true ou false')
    if len(FAQ.get('porta') or []) != 3 or not set(FAQ.get('porta') or []) <= set(fids): erro('faq.porta: 3 ids do FAQ (chips da porta fechada)')
    IDS_ITEM[FAQ['id']] = set(fids)
else:
    fids = []

# ------------------------------------------------------------------ topo, pilares, final, marca, identidade, conversão
H = S.get('hero') or {}
for k, (mn, mx) in {'selo': (3, 40), 'titulo': (15, 90), 'sub': (30, 260), 'cta': (5, 42), 'letra_miuda': (5, 160)}.items(): texto(H.get(k), f'hero.{k}', mn, mx)
for j, (v, leg) in enumerate(lista(H.get('numeros'), 'hero.numeros', 3, 4)): placeholders(v, f'hero.numeros[{j}]'); texto(leg, f'hero.numeros[{j}][1]', 3, 50)
texto(S.get('pilares_titulo'), 'pilares_titulo', 5, 50)
for j, p in enumerate(lista(S.get('pilares'), 'pilares', 2, 5)):
    texto(p.get('titulo'), f'pilares[{j}].titulo', 3, 40); texto(p.get('nota'), f'pilares[{j}].nota', 3, 70)
    if not p.get('secoes') or not set(p['secoes']) <= set(POR_ID) or len(p['secoes']) > 4: erro(f'pilares[{j}].secoes: 1 a 4 ids de seção')
F = S.get('final') or {}
for k, (mn, mx) in {'titulo': (10, 90), 'texto': (20, 260), 'cta': (5, 42), 'letra_miuda': (5, 160)}.items(): texto(F.get(k), f'final.{k}', mn, mx)
placeholders(H.get('sub'), 'hero.sub'); placeholders(F.get('texto'), 'final.texto')
M = S.get('marca') or {}
texto(M.get('nome'), 'marca.nome', 2, 40); texto(M.get('segmento'), 'marca.segmento', 5, 90)
for j, l in enumerate(lista(M.get('links') or [], 'marca.links', 0, 4)):
    if not str(l.get('url', '')).startswith('https://'): erro(f'marca.links[{j}]: só https')
    if l.get('url') not in DESC: erro(f'marca.links[{j}]: o link precisa estar na descrição')
    if CHECKOUT_RE.search(l.get('url', '')): erro(f'marca.links[{j}]: nada de link de checkout ou pagamento')
I = S.get('identidade') or {}
if I.get('paleta') not in PALETAS: erro(f'identidade.paleta: uma de {list(PALETAS)}')
def lum(h):
    c = [int(h[i:i + 2], 16) / 255 for i in (1, 3, 5)]
    c = [x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4 for x in c]
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]
def contraste(a, b):
    la, lb = sorted((lum(a), lum(b)), reverse=True); return (la + 0.05) / (lb + 0.05)
def hsl(h):
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (1, 3, 5)); mx, mn = max(r, g, b), min(r, g, b); l = (mx + mn) / 2
    if mx == mn: return 0, 0, l
    d = mx - mn; s = d / (2 - mx - mn) if l > 0.5 else d / (mx + mn)
    hh = ((g - b) / d + (6 if g < b else 0)) if mx == r else ((b - r) / d + 2) if mx == g else ((r - g) / d + 4)
    return hh * 60, s, l
A = I.get('acento')
if A is not None:
    for k in ('ac', 'ac2'):
        v = (A or {}).get(k, '')
        if not re.fullmatch(r'#[0-9a-fA-F]{6}', v or ''): erro(f'identidade.acento.{k}: cor #rrggbb'); continue
        if I.get('paleta') in PALETAS and contraste(v.lower(), PALETAS[I['paleta']]) < 7: erro(f'identidade.acento.{k}: contraste {contraste(v.lower(), PALETAS[I["paleta"]]):.1f}:1 com o --bg (mínimo 7:1)')
        hh, ss, _ = hsl(v.lower())
        if 170 <= hh <= 290 and ss >= 0.35: erro(f'identidade.acento.{k}: ciano ou violeta (matiz {hh:.0f}°, saturação HSL {ss:.0%}) é a cor do Jev')
if I.get('fontes') not in FONTES: erro(f'identidade.fontes: um de {FONTES}')
texto(I.get('por_que'), 'identidade.por_que', 20, 240)
C = S.get('conversao') or {}
if C.get('tipo') not in ('pagamento', 'contato'): erro('conversao.tipo: “pagamento” (a pessoa paga na página) ou “contato” (agenda, pede orçamento, fala com a equipe)')
elif C['tipo'] == 'pagamento' and TIPO_ID.get('oferta') and (not OF.get('preco') or OF['preco'].get('a_partir')): erro('conversao.tipo “pagamento” precisa de oferta.preco fechado (sem “a partir de”)')
texto(C.get('cta'), 'conversao.cta', 4, 28); texto(C.get('acao'), 'conversao.acao', 4, 40); texto(C.get('verbo'), 'conversao.verbo', 3, 16); texto(C.get('concluida'), 'conversao.concluida', 4, 40)

# ------------------------------------------------------------------ política do Jev
J = S.get('jev') or {}
texto(J.get('pagina'), 'jev.pagina', 80, 700); placeholders(J.get('pagina'), 'jev.pagina')
NOMES = [s.get('nome', '') for s in SEC] + [x.get('nome', '') for s in SEC if s.get('tipo') in ('trilhas', 'lista', 'depoimentos') for x in s.get('itens') or []]
NOMES += [f.get('pergunta', '') for f in (FAQ.get('itens') if TIPO_ID.get('faq') else [])]
def concretos(v):
    n = norm(v); return sum(1 for x in NOMES if len(x) >= 3 and norm(x)[:24] in n)
def grupo(nome, mn, mx, obrig=()):
    L = lista(J.get(nome), f'jev.{nome}', mn, mx); ids = [x.get('id') for x in L]
    if len(set(ids)) != len(ids): erro(f'jev.{nome}: ids repetidos')
    for o in obrig:
        if o not in ids: erro(f'jev.{nome}: falta o id obrigatório “{o}”')
    for j, x in enumerate(L):
        if not re.fullmatch(r'[a-z][a-z0-9_]{1,23}', x.get('id', '')) or x['id'] in ('nenhuma', 'indefinido'): erro(f'jev.{nome}[{j}].id inválido')
        texto(x.get('rotulo'), f'jev.{nome}[{j}].rotulo', 3, 30); texto(x.get('criterio'), f'jev.{nome}[{j}].criterio', 40, 420)
        if not isinstance(x.get('emoji'), str) or not x['emoji']: erro(f'jev.{nome}[{j}].emoji')
    return L, ids
PERF, PERF_IDS = grupo('perfis', 3, 7)
for j, x in enumerate(PERF):
    if concretos(x.get('criterio')) < 2: erro(f'jev.perfis[{j}] ({x.get("id")}): cite ao menos 2 nomes reais de seções, itens ou perguntas do site')
INT, INT_IDS = grupo('interesses', 4, 8, ('condicoes', 'prova'))
DIAS = OF.get('garantia', {}).get('dias') if TIPO_ID.get('oferta') and OF.get('garantia') else None
for j, x in enumerate(INT):
    cta = x.get('cta') or ''
    placeholders(cta, f'jev.interesses[{j}].cta')
    if '{dias}' in cta and DIAS is None: erro(f'jev.interesses[{j}].cta usa {{dias}} sem garantia na oferta')
    TRI_S = POR_ID.get((TIPO_ID.get('trilhas') or [''])[0], {})
    tri_max = max((f"{x.get('pelo', '')} {x.get('curto', '')}" for x in TRI_S.get('itens') or []), key=len, default='')
    exp_ids = (J.get('sua_trilha') or {}).get('experimente') or []
    item_max = max((x.get('nome', '') for sid in exp_ids for x in POR_ID.get(sid, {}).get('itens') or []), key=len, default='')
    cheio = cta.replace('{trilha}', tri_max).replace('{item}', item_max).replace('{dias}', str(DIAS) if DIAS is not None else '')
    cheio = re.sub(r'\{n:([a-z0-9_]+)\}', lambda m: str(contar(POR_ID[m.group(1)]) if m.group(1) in POR_ID else 999), cheio)
    cheio = re.sub(r'\{total:([a-z0-9_]+)\}', lambda m: str(sum(x.get('n', 0) for x in POR_ID.get(m.group(1), {}).get('itens') or [])), cheio)
    if cta and len(cheio) > 42: erro(f'jev.interesses[{j}].cta: {len(cheio)} caracteres preenchido com os valores mais longos (máx. 42): “{cheio}”')
OBJ, OBJ_IDS = grupo('objecoes', 3, 8)
fs = [x.get('faq') for x in OBJ]
if not set(fs) <= set(fids) or len(set(fs)) != len(fs): erro('jev.objecoes[].faq: ids do FAQ que existem, sem repetir')
T = J.get('sua_trilha') or {}
listas_ids = TIPO_ID.get('lista', [])
if not T.get('experimente') or not set(T['experimente']) <= set(listas_ids) or len(T['experimente']) > 3: erro('jev.sua_trilha.experimente: 1 a 3 ids de seções do tipo lista')
pad = T.get('experimente_padrao') or {}
if pad.get('secao') not in listas_ids: erro('jev.sua_trilha.experimente_padrao.secao: uma lista')
texto(pad.get('texto'), 'jev.sua_trilha.experimente_padrao.texto', 5, 60); placeholders(pad.get('texto'), 'experimente_padrao.texto')
if not T.get('duvidas') or not set(T['duvidas']) <= set(POR_ID) or len(T['duvidas']) > 2: erro('jev.sua_trilha.duvidas: 1 ou 2 ids de seção')
if T.get('rotulo_experimente') is not None: texto(T['rotulo_experimente'], 'jev.sua_trilha.rotulo_experimente', 3, 24)
if TIPO_ID.get('oferta'):
    TRI_IDS = IDS_ITEM.get((TIPO_ID.get('trilhas') or [''])[0], set())
    for j, x in enumerate(lista(OF.get('inclui'), 'oferta.inclui', 6, 14)):
        texto(x.get('texto'), f'oferta.inclui[{j}].texto', 5, 120)
        if not set(x.get('secoes') or []) <= set(POR_ID): erro(f'oferta.inclui[{j}].secoes: ids de seção')
        if x.get('trilha') is not None and x['trilha'] not in TRI_IDS: erro(f'oferta.inclui[{j}].trilha: id de trilha')
        if not set(x.get('perfis') or []) <= set(PERF_IDS): erro(f'oferta.inclui[{j}].perfis: ids de perfil')
        if not set(x.get('interesses') or []) <= set(INT_IDS): erro(f'oferta.inclui[{j}].interesses: ids de interesse')

# ------------------------------------------------------------------ simulações
SIMS = lista(S.get('simulacoes'), 'simulacoes', 3, 7)
usados = set()
for i, sm in enumerate(SIMS):
    c = f'simulacoes[{i}] ({sm.get("id")})'
    if not re.fullmatch(r'[a-z][a-z0-9_]{1,23}', sm.get('id', '')): erro(f'{c}.id inválido')
    texto(sm.get('rotulo'), f'{c}.rotulo', 4, 40); texto(sm.get('desc'), f'{c}.desc', 20, 160); texto(sm.get('espera'), f'{c}.espera', 20, 160)
    ej = sm.get('espera_jev') or {}
    if not ej: erro(f'{c}.espera_jev: diga o que o teste confere')
    if ej.get('perfil') and ej['perfil'] not in PERF_IDS: erro(f'{c}.espera_jev.perfil desconhecido')
    if ej.get('objecao') and ej['objecao'] not in OBJ_IDS: erro(f'{c}.espera_jev.objecao desconhecida')
    if ej.get('pins') and ej['pins'].get('secao') not in IDS_ITEM: erro(f'{c}.espera_jev.pins.secao precisa ser uma lista')
    if ej.get('prova') and not TIPO_ID.get('depoimentos'): erro(f'{c}.espera_jev.prova: sem depoimentos não há prova')
    if ej.get('saida') and not any(p.get('f') == 'sairPeloTopo' for p in sm.get('passos') or []): erro(f'{c}.espera_jev.saida: a simulação precisa do passo sairPeloTopo')
    if sm.get('captura') not in (None, '', 'duvida', 'saida', 'prova') and not re.fullmatch(r'pins:[a-z][a-z0-9_]{1,23}', str(sm.get('captura'))): erro(f'{c}.captura: pins:<lista>, duvida, saida, prova ou vazio')
    for j, p in enumerate(lista(sm.get('passos'), f'{c}.passos', 3, 16)):
        f = p.get('f'); usados.add(f)
        if f not in PASSOS: erro(f'{c}.passos[{j}]: passo “{f}” desconhecido'); continue
        for k in PASSOS[f]:
            if not k.startswith('?') and k not in p: erro(f'{c}.passos[{j}] ({f}): falta “{k}”')
        if 'secao' in p and p['secao'] not in POR_ID: erro(f'{c}.passos[{j}]: seção “{p["secao"]}” não existe')
        if 'faq' in p and p['faq'] not in fids: erro(f'{c}.passos[{j}]: FAQ “{p["faq"]}” não existe')
        if 'trilha' in p and p['trilha'] not in IDS_ITEM.get((TIPO_ID.get('trilhas') or [''])[0], set()): erro(f'{c}.passos[{j}]: trilha “{p["trilha"]}” não existe')
        if f == 'abrirItem' or (f == 'esperarPins' and p.get('item')):
            sec = POR_ID.get(p.get('secao'), {})
            if not any(x.get('nome', '').startswith(p.get('item', '§')) for x in sec.get('itens') or []): erro(f'{c}.passos[{j}]: nenhum item de “{p.get("secao")}” começa com “{p.get("item")}”')
        if f == 'abrirBloco':
            tr = next((x for x in POR_ID[(TIPO_ID.get('trilhas') or [''])[0]].get('itens', []) if x.get('id') == p.get('trilha')), None) if TIPO_ID.get('trilhas') else None
            if tr and not (0 <= p.get('bloco', -1) < len(tr.get('blocos', []))): erro(f'{c}.passos[{j}]: bloco fora da trilha')
        if f in ('buscar', 'esperarPins', 'abrirPrimeiroPin') and POR_ID.get(p.get('secao'), {}).get('tipo') not in ('lista', 'trilhas', 'depoimentos'): erro(f'{c}.passos[{j}]: {f} só em listas')
        if f == 'buscar' and len(POR_ID.get(p.get('secao'), {}).get('itens') or []) <= 16: erro(f'{c}.passos[{j}]: a lista “{p.get("secao")}” não tem busca (16 itens ou menos)')
for f, porque in (('esperarPins', '“Para você” numa lista'), ('esperarDuvida', 'dúvida respondida'), ('sairPeloTopo', 'saída segurada')):
    if f not in usados: erro(f'simulacoes: nenhuma usa {f} ({porque})')
if TIPO_ID.get('depoimentos') and 'esperarProva' not in usados: erro('simulacoes: com depoimentos, uma delas termina em esperarProva')
if TIPO_ID.get('oferta') and OF.get('preco') and 'pairarPreco' not in usados: erro('simulacoes: com preço, uma delas usa pairarPreco')

# ------------------------------------------------------------------ honestidade: números, preços e links
def textos(o, caminho=''):
    if isinstance(o, dict):
        for k, v in o.items():
            if k in ISENTAS or (k == 'secoes' and isinstance(v, list) and all(isinstance(x, str) for x in v)): continue  # listas de ids
            yield from textos(v, f'{caminho}.{k}')
    elif isinstance(o, list):
        for j, v in enumerate(o): yield from textos(v, f'{caminho}[{j}]')
    elif isinstance(o, str): yield caminho, o
ISENTAS = ('id', 'faq', 'secao', 'trilha', 'perfis', 'interesses', 'porta', 'versao', 'fonte', 'identidade', 'n', 'dias', 'f', 'ms', 'ler_ms',
           'bloco', 'esperar_ms', 'passos', 'espera_jev', 'captura', 'icone', 'emoji', 'url', 'tipo', 'formato', 'produto', 'resumo',
           'explicativo', 'a_partir')
ORDINAL = re.compile(r'^(Etapa|Semana|Módulo|Unidade|Nível|Aula|Parte|Passo|Fase|Capítulo|Dia) \d{1,2}\b')
for caminho, v in textos(S):
    caminho = caminho.lstrip('.')
    limpo = re.sub(r'\{(n|total):[a-z0-9_]+\}|\{dias\}|\{trilha\}|\{item\}', '', v)
    if caminho.endswith('.titulo') and '.blocos[' in caminho: limpo = ORDINAL.sub('', limpo)
    if re.search(r'\.exemplo\[\d+\]\[2\]$', caminho): continue  # a hora da conversa de exemplo é ilustrativa
    for n in re.findall(r'\d+', limpo.replace('.', '')):
        if n not in NUM_DESC: erro(f'{caminho}: o número “{n}” não está na descrição (nada de número inventado): “{v[:70]}”')
    for w in re.findall(r'[a-z]+', sem_acento(limpo)):
        if w in EXTENSO and w not in PALAVRAS_DESC and str(EXTENSO[w]) not in NUM_DESC:
            erro(f'{caminho}: “{w}” é número por extenso e não está na descrição (contagem vem de {{n:…}}): “{v[:70]}”')
    if '\n' in v or '  ' in v: erro(f'{caminho}: sem quebras de linha nem espaços duplos')
    for m in SEM_ACENTO.finditer(v):
        if not re.search(r'\b' + re.escape(m.group(0)) + r'\b', DESC):  # nome próprio escrito assim na descrição passa
            erro(f'{caminho}: “{m.group(0)}” sem acento (pt-BR com acentuação correta)'); break
    if re.search(r'\bcupo(m|ns)\b', v, re.I): erro(f'{caminho}: nada de cupom')
    if re.search(r'desconto', v, re.I) and 'desconto' not in DESC.lower(): erro(f'{caminho}: “desconto” sem estar na descrição')
    if CHECKOUT_RE.search(v): erro(f'{caminho}: parece um link ou nome de checkout: “{v[:60]}”')
if TIPO_ID.get('oferta') and OF.get('garantia') and str(OF['garantia']['dias']) not in NUM_DESC: erro('oferta.garantia.dias: o prazo não está na descrição')

# ------------------------------------------------------------------ fontes: cada afirmação sobre a oferta aponta o trecho da descrição que a sustenta
def norm_f(s): return ' '.join(unicodedata.normalize('NFKC', str(s)).replace('“', '"').replace('”', '"').replace('‘', "'").replace('’', "'").split()).lower()
DESC_F = norm_f(DESC)
FONTES = {}
if not FONTES_ARQ.exists():
    erro(f'{FONTES_ARQ.name}: falta o arquivo de fontes (3.4.4)')
else:
    try:
        FONTES = json.loads(FONTES_ARQ.read_text())
    except Exception as e:
        erro(f'{FONTES_ARQ.name}: JSON inválido ({e})')
    if not isinstance(FONTES, dict):
        erro(f'{FONTES_ARQ.name}: precisa ser um objeto {{chave: trecho}}'); FONTES = {}
REQ = []
if TIPO_ID.get('oferta'):
    if OF.get('preco'): REQ.append('preco')
    REQ += [f'plano:{x.get("nome")}' for x in OF.get('planos_extras') or []]
    if OF.get('garantia'): REQ.append('garantia')
    REQ += [f'selo:{x}' for x in OF.get('selos') or []]
    REQ += [f'inclui:{x.get("texto")}' for x in OF.get('inclui') or []]
if TIPO_ID.get('faq'):
    REQ += [f'faq:{f.get("id")}' for f in FAQ.get('itens') or [] if not f.get('explicativo')]
for s in SEC:
    tp = s.get('tipo')
    if tp == 'lista' and not s.get('explicativo'):
        REQ += [f'item:{s.get("id")}/{x.get("id")}' for x in s.get('itens') or []]
    elif tp == 'trilhas':
        for x in s.get('itens') or []:
            REQ.append(f'percurso:{x.get("id")}')
            REQ += [f'etapa:{x.get("id")}/{k}' for k in range(len(x.get('blocos') or []))]
    elif tp == 'agenda':
        REQ += [f'data:{k}' for k in range(len(s.get('datas') or []))]
    elif tp == 'equipe':
        REQ += [f'pessoa:{x.get("nome")}' for x in s.get('pessoas') or []] + [f'conquista:{k}' for k in range(len(s.get('conquistas') or []))]
    elif tp == 'espacos':
        REQ += [f'card:{d[0]}' for d in s.get('cards') or []]
    elif tp == 'conversa':
        REQ += [f'conversa:{k}' for k in range(len(s.get('itens') or []))]
for k in REQ:
    v = FONTES.get(k)
    if not isinstance(v, str) or len(v.strip()) < 8:
        erro(f'{FONTES_ARQ.name}: falta o trecho da descrição que sustenta “{k}” (sem trecho, tire do JSON ou marque como explicativo)')
    elif norm_f(v) not in DESC_F:
        erro(f'{FONTES_ARQ.name} “{k}”: o trecho não está na descrição, palavra por palavra: “{v[:70]}”')
for k in FONTES:
    if k not in REQ: aviso(f'{FONTES_ARQ.name}: a chave “{k}” não corresponde a nada do site.json')

# ------------------------------------------------------------------ tamanho da maior chamada ao Jev
maior = max((sum(len(x.get('nome', '')) + len(x.get('frase', '') or '') + 40 for x in s.get('itens') or []) for s in SEC if s.get('tipo') in ('trilhas', 'lista', 'depoimentos')), default=0)
fixo = sum(len(json.dumps(J.get(k), ensure_ascii=False)) for k in ('perfis', 'interesses', 'objecoes')) + sum(len(s.get('jev', '')) for s in SEC) + 6000
if fixo + maior > 60000: erro(f'a maior chamada ao Jev teria ~{fixo + maior} caracteres (máx. 60.000): encurte listas ou critérios')
elif fixo + maior > 40000: aviso(f'a maior chamada ao Jev terá ~{fixo + maior} caracteres (acima de 40.000 a latência sobe)')

for a in avisos: print('  ~', a)
for e in erros: print('  ✗', e)
n_itens = sum(len(s.get('itens') or []) for s in SEC if s.get('tipo') in ('trilhas', 'lista', 'depoimentos'))
print(f'{"OK" if not erros else "REPROVADO"}: {len(SEC)} seções, {n_itens} itens em listas, {len(fids)} perguntas, {len(PERF)} perfis, '
      f'{len(INT)} interesses, {len(OBJ)} objeções, {len(SIMS)} simulações, {len(REQ)} fontes · {len(erros)} erro(s), {len(avisos)} aviso(s)')
sys.exit(1 if erros else 0)
