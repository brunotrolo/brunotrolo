#!/usr/bin/env python3
"""E2E da Planilha Preditiva — Playwright (Python, Chromium headless).

Uso:  python3 apps/planilha/test/e2e.py        (app em http://localhost:4101, ou APP_URL=...)
Sai com código 0 quando tudo passa. Salva capturas em apps/planilha/test/shots/.
Custo de Jev por execução: ~US$ 0,007 (≈ 12 colunas preenchidas).
"""
import csv, io, json, os, re, sys, time
from pathlib import Path
from urllib.request import urlopen
from playwright.sync_api import sync_playwright

BASE = os.environ.get('APP_URL', 'http://localhost:4101').rstrip('/')
DIR = Path(__file__).resolve().parent
SHOTS = DIR / 'shots'
SHOTS.mkdir(exist_ok=True)
ROT = json.loads((DIR / 'rotulos.json').read_text(encoding='utf-8'))

falhas, medidas, erros_console = [], [], []


def check(cond, msg):
    print(('  ✓ ' if cond else '  ✗ ') + msg, flush=True)
    if not cond:
        falhas.append(msg)
    return cond


def secao(t):
    print(f'\n== {t}', flush=True)


def liga_console(pg, nome):
    pg.on('console', lambda m: erros_console.append(f'[{nome}] {m.type}: {m.text}') if m.type in ('error', 'warning') else None)
    pg.on('pageerror', lambda e: erros_console.append(f'[{nome}] pageerror: {e}'))


def espera_coluna(pg, cid, timeout=20000):
    """Espera a coluna cid terminar (status pronto). Devolve o tempo de parede em segundos."""
    t0 = time.time()
    pg.wait_for_function(
        """(cid) => { const st = document.querySelector('#status'); const th = document.querySelector(`th.ai[data-col="${cid}"]`);
                      return st && st.dataset.col === cid && ['pronto', 'parcial', 'erro'].includes(st.dataset.state) && th && th.dataset.state === st.dataset.state; }""",
        arg=cid, timeout=timeout)
    return time.time() - t0


def valores(pg, cid):
    return pg.eval_on_selector_all(f'td.ai[data-col="{cid}"]', 'els => els.map(e => [e.parentElement.dataset.rid, e.dataset.v === undefined ? null : e.dataset.v])')


def ultima_coluna(pg):
    return pg.eval_on_selector_all('th.ai', 'els => els.length ? els[els.length - 1].dataset.col : null')


def texto_dom(pg, sel):
    """Texto do DOM em minúsculas (inner_text aplicaria o text-transform: uppercase dos badges)."""
    return (pg.text_content(sel) or '').lower()


def status_txt(pg):
    return pg.inner_text('#status')


def mede_status(pg, rotulo):
    t = status_txt(pg)
    m = re.search(r'([\d.]+) linhas em ([\d,]+) s', t)
    c = re.search(r'custo US\$ ([\d,]+)', t)
    if m and c:
        medidas.append({'acao': rotulo, 'linhas': int(m.group(1).replace('.', '')), 'segundos': float(m.group(2).replace(',', '.')), 'custo': float(c.group(1).replace(',', '.'))})


def cria_por_digitacao(pg, titulo, colar=False):
    antes = pg.eval_on_selector_all('th.ai', 'els => els.length')
    pg.click('#newcol')
    if colar:
        pg.fill('#newcol', titulo)
    else:
        pg.keyboard.type(titulo, delay=18)
    t0 = time.time()
    pg.keyboard.press('Enter')
    pg.wait_for_function('(n) => document.querySelectorAll("th.ai").length > n', arg=antes, timeout=5000)
    cid = ultima_coluna(pg)
    espera_coluna(pg, cid)
    return cid, time.time() - t0


def gasto_gateway():
    try:
        with urlopen('http://127.0.0.1:8787/v1/stats', timeout=3) as r:
            return json.loads(r.read())['apps'].get('planilha', {}).get('cost', 0)
    except Exception:
        return None


def main():
    custo0 = gasto_gateway()
    with sync_playwright() as p:
        br = p.chromium.launch(headless=True)
        ctx = br.new_context(viewport={'width': 1440, 'height': 900}, device_scale_factor=1, accept_downloads=True, locale='pt-BR')
        pg = ctx.new_page()
        liga_console(pg, 'desktop')

        # ------------------------------------------------------------ 1. primeira tela
        secao('Primeira tela')
        pg.goto(BASE + '/', wait_until='networkidle')
        pg.wait_for_selector('tbody tr[data-rid]')
        check('Planilha Preditiva' in pg.inner_text('h1'), 'título "Planilha Preditiva" visível')
        abas = pg.eval_on_selector_all('.pp-tab', 'els => els.map(e => e.dataset.id)')
        check(abas == ['leads', 'avaliacoes', 'candidatos', '__import'], f'abas: {abas}')
        n_leads = pg.eval_on_selector_all('tbody tr[data-rid]', 'els => els.length')
        check(115 <= n_leads <= 130, f'Leads do Instagram com ~120 linhas ({n_leads})')
        check(pg.is_visible('#cta') and pg.is_visible('#newcol'), 'botão de exemplo (1 clique) e campo "+ Nova coluna IA" visíveis')
        check(len(pg.query_selector_all('#sugs .jev-chip')) >= 5, 'chips de sugestão de colunas')
        check(pg.evaluate('document.documentElement.scrollWidth') <= 1441, 'sem rolagem horizontal da página em 1440 px')
        pg.screenshot(path=str(SHOTS / '01-inicio.png'))

        # ------------------------------------------------------------ 2. "Quer comprar?"
        secao('Leads → "Quer comprar?" (regra do "?" → sim/não)')
        cid, dt = cria_por_digitacao(pg, 'Quer comprar?')
        check(cid == 'c1', 'coluna c1 criada pelo cabeçalho')
        check(dt < 8, f'todas as linhas preenchidas em {dt:.2f} s (< 8 s)')
        th = pg.query_selector('th.ai[data-col="c1"]')
        check(th.get_attribute('data-kind') == 'noul' and th.get_attribute('data-state') == 'pronto', 'coluna sim/não (noul) pronta')
        vs = valores(pg, 'c1')
        cheios = [float(v) for _, v in vs if v is not None]
        check(len(cheios) == n_leads, f'{len(cheios)}/{n_leads} células preenchidas')
        distintos = len({round(v, 2) for v in cheios})
        altos = sum(v >= 0.7 for v in cheios)
        check(distintos >= 10 and 0.08 * n_leads <= altos <= 0.6 * n_leads and min(cheios) <= 0.15 and max(cheios) >= 0.9,
              f'valores variados: {distintos} valores distintos, {altos} ≥ 70%, min {min(cheios):.2f}, máx {max(cheios):.2f}')
        mapa = {rid: float(v) for rid, v in vs if v is not None}
        compradores = [rid for rid, c in ROT['leads']['cat'].items() if c == 'compra']
        baixos = [f'{rid}={mapa[rid]:.2f}' for rid in compradores if mapa[rid] < 0.7]
        check(not baixos, f'as {len(compradores)} linhas que claramente querem comprar estão ≥ 70%' + (f' (falharam: {baixos})' if baixos else ''))
        nao = [rid for rid, c in ROT['leads']['cat'].items() if c in ('spam', 'elogio', 'reclamacao', 'curioso')]
        check(sum(mapa[r] < 0.3 for r in nao) >= 0.9 * len(nao), f'spam/elogio/reclamação/curioso ficam < 30% ({sum(mapa[r] < 0.3 for r in nao)}/{len(nao)})')
        st = status_txt(pg)
        check(re.search(r'\d+ linhas em [\d,]+ s', st) is not None and '10 mil linhas custariam' in st and 'decisões' in st, 'contador: "N linhas em X s · decisões · custo · 10 mil linhas custariam…"')
        mede_status(pg, 'Leads · "Quer comprar?" (sim/não)')
        pg.wait_for_timeout(700)
        pg.screenshot(path=str(SHOTS / '02-quer-comprar.png'))

        # ------------------------------------------------------------ 3. painel da linha
        secao('Painel com as probabilidades da linha')
        alvo = compradores[0]
        pg.click(f'tr[data-rid="{alvo}"] td.ai[data-col="c1"]')
        pg.wait_for_selector('#panel.open')
        pg.wait_for_timeout(500)
        txt = pg.inner_text('#panel')
        check('chance de "sim"' in txt and 'Sim' in txt and 'lote' in txt, 'painel mostra % de "sim", barras e o lote da chamada')
        pg.screenshot(path=str(SHOTS / '03-painel.png'))
        pg.keyboard.press('ArrowDown'); pg.wait_for_timeout(150)
        check(pg.get_attribute('tr.sel', 'data-rid') != alvo, 'seta ↓ navega para a próxima linha')
        pg.keyboard.press('Escape'); pg.wait_for_timeout(350)
        check(not pg.is_visible('#panel.open'), 'Esc fecha o painel')

        # ------------------------------------------------------------ 4. filtro ≥ 70%
        secao('Filtro "Quer comprar?" ≥ 70%')
        pg.click('th.ai[data-col="c1"] .aih-menu')
        pg.click('#menu button[data-acao="filtro-gte-0.7"]')
        pg.wait_for_timeout(300)
        vis = [float(v) for _, v in valores(pg, 'c1')]
        check(len(vis) == altos and all(v >= 0.7 for v in vis), f'filtro mostra só as {altos} linhas ≥ 70%')
        check(f'Mostrando {altos} de {n_leads}' in pg.inner_text('#filters').replace('.', ''), 'contador "Mostrando X de Y linhas"')
        pg.click('#filters .jev-chip')
        pg.wait_for_timeout(300)
        check(len(valores(pg, 'c1')) == n_leads, 'remover o filtro volta todas as linhas')

        # ------------------------------------------------------------ 5. ordenação
        secao('Ordenação')
        pg.click('th.ai[data-col="c1"] .aih-title')
        d = [float(v) for _, v in valores(pg, 'c1')]
        check(all(d[i] >= d[i + 1] for i in range(len(d) - 1)) and d[0] >= 0.9, f'clique no título: maior → menor (1ª linha {d[0]:.2f})')
        pg.click('th.ai[data-col="c1"] .aih-title')
        a = [float(v) for _, v in valores(pg, 'c1')]
        check(all(a[i] <= a[i + 1] for i in range(len(a) - 1)), 'segundo clique: menor → maior')
        pg.click('th.ai[data-col="c1"] .aih-title')
        check(pg.eval_on_selector('tbody tr', 'e => e.dataset.rid') == 'r1', 'terceiro clique: ordem original')
        pg.click('th.src[data-key="seguidores"]')
        segs = pg.eval_on_selector_all('tbody tr', 'els => els.map(e => e.dataset.rid)')
        leads = json.loads((DIR.parent / 'data' / 'leads.json').read_text(encoding='utf-8'))['linhas']
        nums = [leads[int(r[1:]) - 1]['seguidores'] for r in segs]
        check(all(nums[i] <= nums[i + 1] for i in range(len(nums) - 1)), 'ordenar coluna de origem (Seguidores) crescente')
        pg.click('th.src[data-key="seguidores"]'); pg.click('th.src[data-key="seguidores"]')

        # ------------------------------------------------------------ 6. "Urgência" → Jev escolhe o tipo
        secao('Leads → "Urgência" (o Jev escolhe o tipo da coluna)')
        cid, dt = cria_por_digitacao(pg, 'Urgência')
        th = pg.query_selector(f'th.ai[data-col="{cid}"]')
        check(th.get_attribute('data-modelo') == 'urgencia', f'o Jev escolheu o modelo de urgência (data-modelo={th.get_attribute("data-modelo")})')
        st = status_txt(pg)
        check('O Jev entendeu' in st and 'Escala de urgência (0–4)' in st and re.search(r'— \d+%', st) is not None, 'status: "O Jev entendeu «Urgência» como: Escala de urgência (0–4) — N%"')
        u = [float(v) for _, v in valores(pg, cid) if v is not None]
        check(len(u) == n_leads and len({round(x) for x in u}) >= 3, f'urgência preenchida em {dt:.2f} s com {len({round(x) for x in u})} níveis diferentes')
        mede_status(pg, 'Leads · "Urgência" (meta + escala 0–4)')
        opts = pg.eval_on_selector_all('#tipoSel option', 'els => els.map(e => e.value)')
        check('urgencia' in opts and 'prioridade' in opts and len(opts) >= 20, f'menu "trocar tipo" com {len(opts)} opções')
        pg.wait_for_timeout(600)
        pg.screenshot(path=str(SHOTS / '04-urgencia.png'))

        secao('Trocar o tipo da coluna no menu')
        pg.select_option('#tipoSel', 'prioridade')
        espera_coluna(pg, cid)
        th = pg.query_selector(f'th.ai[data-col="{cid}"]')
        check(th.get_attribute('data-modelo') == 'prioridade' and 'tipo escolhido por você' in status_txt(pg), 'coluna refeita como "Prioridade de atendimento"')
        pg.select_option('#tipoSel', 'urgencia')
        espera_coluna(pg, cid)
        check(pg.get_attribute(f'th.ai[data-col="{cid}"]', 'data-modelo') == 'urgencia', 'voltou para urgência')

        # ------------------------------------------------------------ 7. Avaliações → Tema
        secao('Avaliações → "Tema: preço, entrega, qualidade, atendimento" (categorias)')
        pg.click('.pp-tab[data-id="avaliacoes"]')
        pg.wait_for_selector('tbody tr[data-rid="r150"]', state='attached')
        cid, dt = cria_por_digitacao(pg, 'Tema: preço, entrega, qualidade, atendimento')
        th = pg.query_selector(f'th.ai[data-col="{cid}"]')
        check(th.get_attribute('data-kind') == 'choice', 'coluna de categorias (choice)')
        tags = dict(valores(pg, cid))
        check(all(v in ('preço', 'entrega', 'qualidade', 'atendimento', 'outro') for v in tags.values()) and len(tags) == 150, '150 etiquetas, todas entre as opções + "outro"')
        tema, flags = ROT['avaliacoes']['tema'], ROT['avaliacoes'].get('flags', {})
        claros = [r for r, t in tema.items() if t in ('preço', 'entrega', 'qualidade', 'atendimento') and r not in flags]
        certos = [r for r in claros if tags.get(r) == tema[r]]
        erradas = [f'{r}:{tema[r]}→{tags.get(r)}' for r in claros if tags.get(r) != tema[r]]
        taxa = len(certos) / len(claros)
        check(taxa >= 0.85, f'etiquetas coerentes: {len(certos)}/{len(claros)} ({taxa:.0%}) batem com o rótulo manual' + (f' — divergências: {", ".join(erradas[:8])}' if erradas else ''))
        check(dt < 8, f'150 linhas em {dt:.2f} s')
        mede_status(pg, 'Avaliações · "Tema: …" (5 categorias)')
        pg.wait_for_timeout(600)
        pg.screenshot(path=str(SHOTS / '05-avaliacoes-tema.png'))

        # ------------------------------------------------------------ 8. Candidatos → Fit (1 clique na sugestão)
        secao('Candidatos → sugestão "Fit para a vaga" (1 clique)')
        pg.click('.pp-tab[data-id="candidatos"]')
        pg.wait_for_selector('tbody tr[data-rid="r80"]', state='attached')
        antes = len(pg.query_selector_all('th.ai'))
        pg.click('#sugs .jev-chip[data-sug="Fit para a vaga"]')
        pg.wait_for_function('(n) => document.querySelectorAll("th.ai").length > n', arg=antes, timeout=6000)
        cid = ultima_coluna(pg)
        espera_coluna(pg, cid)
        check(pg.get_attribute(f'th.ai[data-col="{cid}"]', 'data-modelo') == 'fit_vaga', 'o Jev escolheu "Fit para a vaga (0–4)"')
        fit = {r: float(v) for r, v in valores(pg, cid)}
        bons = [fit[r] for r, f in ROT['candidatos']['fit'].items() if f == 4]
        ruins = [fit[r] for r, f in ROT['candidatos']['fit'].items() if f <= 1]
        mb, mr = sum(bons) / len(bons), sum(ruins) / len(ruins)
        check(mb - mr >= 1.5, f'fit médio dos candidatos ideais {mb:.2f} vs. fora do perfil {mr:.2f}')
        mede_status(pg, 'Candidatos · "Fit para a vaga" (meta + escala 0–4)')
        pg.click(f'th.ai[data-col="{cid}"] .aih-title')
        pg.wait_for_timeout(600)
        pg.screenshot(path=str(SHOTS / '06-candidatos-fit.png'))

        # ------------------------------------------------------------ 9. importar CSV
        secao('Importar CSV (detecção de separador) + coluna na planilha importada')
        pg.click('.pp-tab[data-id="__import"]')
        pg.fill('#csvText', 'nome,comentario\n"Silva, Ana","Gostei, mas demorou"\nBruno,"Disse ""ótimo"" e foi embora"\n')
        pg.wait_for_timeout(450)
        check('vírgula' in texto_dom(pg, '#impSep') and '2 linhas × 2 colunas' in texto_dom(pg, '#impDims'), 'CSV com vírgula e aspas: 2 linhas × 2 colunas')
        pg.fill('#csvText', 'produto\tnota\tcomentário\nTênis\t5\tÓtimo\nMochila\t2\tRasgou\n')
        pg.wait_for_timeout(450)
        check('tab' in texto_dom(pg, '#impSep') and '2 linhas × 3 colunas' in texto_dom(pg, '#impDims'), 'colado do Excel (tab) detectado: 2 linhas × 3 colunas')
        pg.click('#csvExemplo')
        pg.wait_for_timeout(450)
        check('ponto e vírgula' in texto_dom(pg, '#impSep') and '12 linhas × 4 colunas' in texto_dom(pg, '#impDims'), 'exemplo: ponto e vírgula, 12 linhas × 4 colunas')
        pg.click('#impGo')
        pg.wait_for_selector('.pp-tab.active[data-id="imp1"]')
        check(len(pg.query_selector_all('tbody tr[data-rid]')) == 12, 'planilha importada aberta numa aba nova com 12 linhas')
        cid, dt = cria_por_digitacao(pg, 'Urgência')
        urg = {r: float(v) for r, v in valores(pg, cid)}
        altas = [urg['r1'], urg['r3'], urg['r6']]
        baixas = [urg['r5'], urg['r10']]
        check(len(urg) == 12 and min(altas) >= 2.5 and max(baixas) <= 1.5, f'Pix sumido/clonagem/ameaça de cancelar = alta {[round(x, 1) for x in altas]}; elogios = baixa {[round(x, 1) for x in baixas]}')
        mede_status(pg, 'Importada (12 linhas) · "Urgência"')
        pg.wait_for_timeout(500)
        pg.screenshot(path=str(SHOTS / '07-importar.png'))

        # ------------------------------------------------------------ 10. robustez
        secao('Robustez: vazio, "?", duplicada, enorme, emoji, inglês, cliques repetidos, limite de 8')
        n0 = len(pg.query_selector_all('th.ai'))
        pg.click('#newcol'); pg.keyboard.press('Enter'); pg.wait_for_timeout(200)
        pg.fill('#newcol', '?'); pg.press('#newcol', 'Enter'); pg.wait_for_timeout(200)
        pg.fill('#newcol', 'urgência'); pg.press('#newcol', 'Enter'); pg.wait_for_timeout(200)
        toasts = pg.inner_text('.jev-toasts')
        check(len(pg.query_selector_all('th.ai')) == n0 and 'Digite um título' in toasts and 'Escreva uma pergunta' in toasts and 'já existe' in toasts, 'título vazio, só "?" e duplicado não criam coluna (avisos na tela)')
        longo = 'Nível de detalhe e clareza da mensagem do cliente ' * 6
        cid, _ = cria_por_digitacao(pg, longo, colar=True)
        tit = pg.get_attribute(f'th.ai[data-col="{cid}"] .aih-title', 'title') or ''
        check(len(tit.split(' — ')[0]) <= 80 and len(valores(pg, cid)) == 12, 'título enorme cortado em 80 caracteres e coluna preenchida')
        cid, _ = cria_por_digitacao(pg, '🔥🔥🔥')
        check(all(v is not None for _, v in valores(pg, cid)), 'título só com emoji funciona (o Jev escolhe um tipo)')
        cid, _ = cria_por_digitacao(pg, 'Is the customer angry?')
        en = {r: float(v) for r, v in valores(pg, cid)}
        check(en['r3'] >= 0.7 and en['r5'] <= 0.3, f'título em inglês: cliente irritado r3={en["r3"]:.2f}, elogio r5={en["r5"]:.2f}')
        n1 = len(pg.query_selector_all('th.ai'))
        chip = pg.query_selector('#sugs .jev-chip[data-sug="Sentimento"]')
        for _ in range(5):
            chip.click(force=True)
        pg.wait_for_function('(n) => document.querySelectorAll("th.ai").length > n', arg=n1, timeout=6000)
        pg.wait_for_timeout(1200)
        cid = ultima_coluna(pg)
        espera_coluna(pg, cid)
        check(len(pg.query_selector_all('th.ai')) == n1 + 1, '5 cliques rápidos na mesma sugestão criam só 1 coluna')
        for t in ('Idioma', 'Assunto', 'Precisa de resposta hoje?'):
            cid, _ = cria_por_digitacao(pg, t)
        check(len(pg.query_selector_all('th.ai')) == 8 and not pg.query_selector('#newcol') and 'Limite de 8' in pg.inner_text('th.new'), '8 colunas IA: o cabeçalho mostra o limite')
        pg.click('#sugs .jev-chip[data-sug="Risco de cancelar"]')
        pg.wait_for_timeout(300)
        check(len(pg.query_selector_all('th.ai')) == 8 and 'Limite de 8' in pg.inner_text('.jev-toasts'), '9ª coluna recusada com aviso')
        pg.click('th.ai[data-col="' + cid + '"] .aih-menu')
        pg.click('#menu button[data-acao="remover"]')
        pg.wait_for_timeout(200)
        check(len(pg.query_selector_all('th.ai')) == 7 and pg.query_selector('#newcol') is not None, 'remover coluna libera o campo "+ Nova coluna IA"')

        # ------------------------------------------------------------ 11. exportar CSV
        secao('Exportar CSV')
        pg.click('.pp-tab[data-id="leads"]')
        pg.wait_for_selector('th.ai[data-col="c1"]')
        with pg.expect_download() as dl:
            pg.click('#export')
        raw = Path(dl.value.path()).read_bytes().decode('utf-8')
        check(raw.startswith('﻿'), 'CSV com BOM (abre certo no Excel)')
        linhas = list(csv.reader(io.StringIO(raw.lstrip('﻿')), delimiter=';'))
        cab = linhas[0]
        check('Quer comprar?' in cab and 'Quer comprar? (prob. de sim)' in cab and 'Urgência' in cab and 'Mensagem na DM' in cab, 'cabeçalho com colunas de origem + colunas do Jev')
        check(len(linhas) == 1 + n_leads, f'{len(linhas) - 1} linhas exportadas')
        i = cab.index('Quer comprar?')
        check({r[i] for r in linhas[1:]} <= {'sim', 'não', 'incerto'} and all(re.fullmatch(r'[01],\d\d', r[i + 1]) for r in linhas[1:]), 'valores sim/não/incerto + probabilidade com vírgula decimal')

        # ------------------------------------------------------------ 12. inspetor
        secao('Inspetor "Ver o que o Jev vê"')
        pg.click('.jev-topbar button:has-text("Ver o que o Jev vê")')
        pg.wait_for_selector('.jev-drawer.open')
        pg.wait_for_timeout(400)
        itxt = texto_dom(pg, '.jev-drawer')
        check('lote' in itxt and 'pergunta(s)' in itxt and 'custo' in itxt, 'inspetor lista as chamadas reais (lotes, perguntas, custo)')
        pg.screenshot(path=str(SHOTS / '08-inspetor.png'))
        pg.keyboard.press('Escape')
        topo = pg.inner_text('.jev-topbar')
        check(re.search(r'decisões\s*[\d.]+', topo) is not None, 'topbar com decisões e custo acumulados')
        ctx.close()

        # ------------------------------------------------------------ 13. celular
        secao('Celular 390×844')
        mctx = br.new_context(viewport={'width': 390, 'height': 844}, device_scale_factor=1, locale='pt-BR', is_mobile=True, has_touch=True)
        mp = mctx.new_page()
        liga_console(mp, 'mobile')
        mp.goto(BASE + '/', wait_until='networkidle')
        mp.wait_for_selector('tbody tr[data-rid]')
        mp.click('#cta')
        mp.wait_for_function('() => document.querySelectorAll("th.ai").length > 0', timeout=6000)
        espera_coluna(mp, 'c1')
        mp.wait_for_timeout(600)
        check(mp.evaluate('document.documentElement.scrollWidth') <= 391, 'sem rolagem horizontal da página no celular')
        mp.screenshot(path=str(SHOTS / 'mobile.png'))
        mp.click('tbody tr[data-rid] td.first')
        mp.wait_for_selector('#panel.open')
        mp.wait_for_timeout(450)
        mp.screenshot(path=str(SHOTS / 'mobile-painel.png'))
        mctx.close()
        br.close()

    secao('Console')
    check(not erros_console, 'zero erros/avisos de console e pageerror' + (': ' + ' | '.join(erros_console[:5]) if erros_console else ''))

    custo1 = gasto_gateway()
    print('\n== Medidas por ação (do contador da página)')
    for m in medidas:
        print(f"  {m['acao']}: {m['linhas']} linhas em {m['segundos']:.2f} s · US$ {m['custo']:.6f} · US$ {m['custo'] / m['linhas'] * 10000:.4f} por 10 mil linhas")
    if custo0 is not None and custo1 is not None:
        print(f'  gasto de Jev deste teste (gateway): US$ {custo1 - custo0:.6f}')
    print(f'\nCapturas em {SHOTS}')
    if falhas:
        print(f'\n{len(falhas)} FALHA(S):')
        for f in falhas:
            print('  - ' + f)
        sys.exit(1)
    print('\nTUDO OK ✅')


if __name__ == '__main__':
    main()
