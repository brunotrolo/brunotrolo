// Mede qualidade e latência do preenchimento em lote (1, 10, 20, 40 linhas por chamada) numa amostra rotulada à mão.
// Uso: node apps/planilha/test/bench_lotes.mjs   (chama o gateway local em :8787 — custo total ≈ US$ 0,01)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { specDaColuna, perguntaDaLinha } from '../lib/colunas.mjs';

const DIR = path.dirname(fileURLToPath(import.meta.url));
const GW = (process.env.JEV_GATEWAY_URL || 'http://127.0.0.1:8787') + '/v1/decide';
const load = (f) => JSON.parse(fs.readFileSync(path.join(DIR, f), 'utf8'));
const LEADS = load('../data/leads.json'), AVAL = load('../data/avaliacoes.json'), ROT = load('rotulos.json');

function linhaObj(ds, row) { const o = {}; for (const c of ds.colunas) o[c.label] = row[c.key]; return o; }
async function jev(state, questions) {
  const t0 = performance.now();
  const r = await fetch(GW, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ app: 'planilha', state, questions, meta: { ip: 'bench' } }) });
  const j = await r.json();
  if (!j.ok) throw new Error(JSON.stringify(j.error));
  return { ms: Math.round(performance.now() - t0), up: j.latency_ms, tokens: j.usage?.input_tokens || 0, cost: j.cost || 0, answers: j.answers };
}
async function lote(ds, spec, ids) {
  const linhas = {}; const questions = {};
  for (const id of ids) { linhas[id] = linhaObj(ds, ds.linhas[+id.slice(1) - 1]); questions[id] = perguntaDaLinha(spec, id); }
  return jev({ planilha: ds.nome, contexto: ds.descricao, coluna_nova: spec.titulo, linhas }, questions);
}
async function pool(items, n, fn) { const out = new Array(items.length); let i = 0; await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => { while (i < items.length) { const k = i++; out[k] = await fn(items[k], k); } })); return out; }
const chunk = (a, n) => { const o = []; for (let i = 0; i < a.length; i += n) o.push(a.slice(i, i + n)); return o; };
let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;

// ---------- amostras rotuladas (20 linhas cada) ----------
const cat = ROT.leads.cat;
const sim = Object.keys(cat).filter((k) => cat[k] === 'compra').slice(0, 10);
const naoCats = ['spam', 'elogio', 'parceria', 'reclamacao', 'tecnica', 'curioso'];
const nao = []; for (let round = 0; nao.length < 10; round++) for (const c of naoCats) { const k = Object.keys(cat).filter((x) => cat[x] === c)[round]; if (k && nao.length < 10) nao.push(k); }
const A = [...sim.map((id) => [id, 1]), ...nao.map((id) => [id, 0])];
const tema = ROT.avaliacoes.tema;
const B = []; for (const t of ['preço', 'entrega', 'qualidade', 'atendimento']) Object.keys(tema).filter((k) => tema[k] === t).slice(0, 5).forEach((id) => B.push([id, t]));

async function avaliar(nome, ds, titulo, amostra, acerto) {
  const spec = specDaColuna(titulo);
  const ids = amostra.map(([id]) => id);
  const filler = Object.keys(ds.linhas).map((i) => 'r' + (+i + 1)).filter((id) => !ids.includes(id));
  const res = {};
  for (const size of [1, 10, 20, 40]) {
    let grupos;
    if (size <= 20) grupos = chunk(ids, size);
    else { const g = [...ids, ...filler.slice(0, size - ids.length)]; g.sort(() => rnd() - 0.5); grupos = [g]; }
    const t0 = performance.now();
    const rs = await pool(grupos, 6, (g) => lote(ds, spec, g));
    const wall = Math.round(performance.now() - t0);
    const ans = {}; rs.forEach((r) => Object.assign(ans, r.answers));
    const lat = rs.map((r) => r.up).sort((a, b) => a - b);
    const tok = rs.reduce((s, r) => s + r.tokens, 0), cost = rs.reduce((s, r) => s + r.cost, 0), nq = grupos.reduce((s, g) => s + g.length, 0);
    const ok = amostra.filter(([id, lab]) => acerto(ans[id], lab)).length;
    res[size] = { ans, ok, lat, wall, tokPorLinha: Math.round(tok / nq), custoPorLinha: cost / nq };
  }
  console.log(`\n== ${nome} — "${titulo}" (${amostra.length} linhas rotuladas)`);
  console.log('lote | acertos | latência/chamada (ms) | concorda c/ lote=1 | tokens/linha | US$/linha');
  for (const size of [1, 10, 20, 40]) {
    const r = res[size];
    let conc = 0, dif = 0;
    for (const [id] of amostra) {
      const a = r.ans[id], b = res[1].ans[id];
      if (a.type === 'noul') { conc += (a.noul >= 0.5) === (b.noul >= 0.5); dif += Math.abs(a.noul - b.noul); }
      else conc += a.choice === b.choice;
    }
    const extra = r.ans[amostra[0][0]].type === 'noul' ? ` (|Δp| médio ${(dif / amostra.length).toFixed(3)})` : '';
    console.log(`${String(size).padStart(4)} | ${r.ok}/${amostra.length} | ${r.lat.join(', ')} | ${conc}/${amostra.length}${extra} | ${r.tokPorLinha} | ${r.custoPorLinha.toFixed(7)}`);
  }
  return res;
}

const rA = await avaliar('Leads', LEADS, 'Quer comprar?', A, (a, lab) => (a.noul >= 0.5 ? 1 : 0) === lab);
const detalhe = A.map(([id, lab]) => `${id}${lab ? '✓' : '✗'} ${[1, 10, 20, 40].map((s) => rA[s].ans[id].noul.toFixed(2)).join('/')}`);
console.log('p(sim) por linha [lote 1/10/20/40]:\n  ' + detalhe.join('\n  '));
await avaliar('Avaliações', AVAL, 'Tema: preço, entrega, qualidade, atendimento', B, (a, lab) => a.choice === lab);

// ---------- tempo de parede da planilha inteira (concorrência 6) ----------
console.log('\n== Planilha inteira, concorrência 6 (Leads, "Quer comprar?")');
const specQ = specDaColuna('Quer comprar?');
const todos = LEADS.linhas.map((_, i) => 'r' + (i + 1));
for (const size of [10, 20, 30]) {
  const t0 = performance.now();
  const rs = await pool(chunk(todos, size), 6, (g) => lote(LEADS, specQ, g));
  const wall = Math.round(performance.now() - t0);
  const lat = rs.map((r) => r.up).sort((a, b) => a - b);
  const cost = rs.reduce((s, r) => s + r.cost, 0);
  const ans = {}; rs.forEach((r) => Object.assign(ans, r.answers));
  const buyers = Object.keys(cat).filter((k) => cat[k] === 'compra');
  const baixo = buyers.filter((id) => ans[id].noul < 0.7).map((id) => `${id}=${ans[id].noul}`);
  console.log(`lote ${size}: ${rs.length} chamadas, parede ${wall} ms, latência p50 ${lat[Math.floor(lat.length / 2)]} máx ${lat.at(-1)} ms, custo US$ ${cost.toFixed(6)}, compradores <0,7: ${baixo.length ? baixo.join(' ') : 'nenhum'}`);
}
