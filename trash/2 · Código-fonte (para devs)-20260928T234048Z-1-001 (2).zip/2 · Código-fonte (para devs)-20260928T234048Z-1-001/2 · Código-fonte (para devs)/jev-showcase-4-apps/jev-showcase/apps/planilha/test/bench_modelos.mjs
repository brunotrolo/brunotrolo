// Mede se o Jev escolhe o modelo de coluna certo só pelo título (pergunta "meta").
// Uso: node apps/planilha/test/bench_modelos.mjs   (≈ 40 chamadas pequenas, custo ≈ US$ 0,003)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { perguntaMeta, MODELOS } from '../lib/colunas.mjs';

const DIR = path.dirname(fileURLToPath(import.meta.url));
const GW = (process.env.JEV_GATEWAY_URL || 'http://127.0.0.1:8787') + '/v1/decide';
const load = (f) => JSON.parse(fs.readFileSync(path.join(DIR, f), 'utf8'));
const DS = { leads: load('../data/leads.json'), avaliacoes: load('../data/avaliacoes.json'), candidatos: load('../data/candidatos.json') };

function planilha(ds) {
  const ex = {}; for (const c of ds.colunas) ex[c.label] = ds.linhas[0][c.key];
  return { nome: ds.nome, descricao: ds.descricao, colunas: ds.colunas.map((c) => c.label), exemplo: ex };
}
// [planilha, título, modelos aceitos]
const CASOS = [
  ['leads', 'Urgência', ['urgencia']], ['leads', 'Sentimento', ['sentimento']], ['leads', 'Próxima ação', ['proxima_acao']],
  ['leads', 'Intenção de compra', ['intencao_compra']], ['leads', 'Temperatura do lead', ['intencao_compra']], ['leads', 'Prioridade', ['prioridade']],
  ['leads', 'Formalidade', ['tom']], ['leads', 'Idioma', ['idioma']], ['leads', 'Spam', ['spam']], ['leads', 'Motivo do contato', ['intencao']],
  ['leads', 'Potencial', ['potencial']], ['leads', 'Criatividade', ['escala']], ['leads', 'Fala de WhatsApp', ['simnao']], ['leads', 'Toxicidade', ['toxicidade']],
  ['leads', 'Urgency', ['urgencia']], ['leads', 'Empolgação', ['escala']], ['leads', 'Quer parceria', ['simnao', 'intencao']], ['leads', 'Tipo de lead', ['intencao']],
  ['avaliacoes', 'Tema', ['assunto']], ['avaliacoes', 'Assunto', ['assunto']], ['avaliacoes', 'Problema', ['problema']], ['avaliacoes', 'Defeito', ['problema']],
  ['avaliacoes', 'Nota prevista', ['nota_prevista']], ['avaliacoes', 'Estrelas', ['nota_prevista']], ['avaliacoes', 'Risco de cancelar', ['risco_churn']],
  ['avaliacoes', 'Ironia', ['sarcasmo']], ['avaliacoes', 'Pede reembolso', ['reembolso']], ['avaliacoes', 'Concorrente', ['concorrente']],
  ['avaliacoes', 'Satisfação', ['sentimento', 'nota_prevista']], ['avaliacoes', 'Qualidade da escrita', ['qualidade_escrita']], ['avaliacoes', 'Grosseria', ['toxicidade']],
  ['avaliacoes', 'Vai comprar de novo', ['risco_churn', 'simnao']],
  ['candidatos', 'Fit para a vaga', ['fit_vaga']], ['candidatos', 'Senioridade', ['senioridade']], ['candidatos', 'Nível', ['senioridade']],
  ['candidatos', 'Match', ['fit_vaga']], ['candidatos', 'Contratar', ['fit_vaga']], ['candidatos', 'Sabe cloud', ['simnao']],
  ['candidatos', 'Experiência com liderança', ['escala', 'simnao']], ['candidatos', 'Clareza do resumo', ['qualidade_escrita']],
];

const t0 = performance.now(); let ok = 0; const lat = []; let custo = 0;
const res = await Promise.all(CASOS.map(async ([ds, titulo, aceitos], i) => {
  await new Promise((r) => setTimeout(r, i * 60));
  const { state, questions } = perguntaMeta(titulo, planilha(DS[ds]));
  const r = await fetch(GW, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ app: 'planilha', state, questions, meta: { ip: 'bench' } }) });
  const j = await r.json();
  if (!j.ok) return { ds, titulo, erro: j.error };
  const a = j.answers.modelo; lat.push(j.latency_ms); custo += j.cost;
  const rank = Object.entries(a.probabilities).sort((x, y) => y[1] - x[1]).slice(0, 3).map(([k, p]) => `${k} ${(p * 100).toFixed(0)}%`).join(', ');
  return { ds, titulo, escolha: a.choice, conf: a.confidence, ok: aceitos.includes(a.choice), rank, tokens: j.usage?.input_tokens };
}));
for (const r of res) {
  if (r.erro) { console.log('ERRO', r.titulo, JSON.stringify(r.erro)); continue; }
  ok += r.ok;
  console.log(`${r.ok ? '✓' : '✗'} [${r.ds}] "${r.titulo}" → ${r.escolha} (${(r.conf * 100).toFixed(0)}%) | ${r.rank}`);
}
lat.sort((a, b) => a - b);
console.log(`\n${ok}/${CASOS.length} corretos · latência p50 ${lat[Math.floor(lat.length / 2)]} ms · tokens/chamada ${res[0].tokens} · custo total US$ ${custo.toFixed(6)} · ${Object.keys(MODELOS).length} modelos`);
