#!/usr/bin/env python3
"""E2E do Estúdio por Voz (Playwright headless, Chromium).

Uso:  python3 apps/estudio/test/e2e.py [--url http://localhost:4116/ | https://jev-estudio.<DOMINIO>/] [--sem-ia]  (https = faz login)
Pré-requisitos: gateway do Jev em :8787 e o app rodando (PORT=4116 node apps/estudio/server.mjs), com o modelo local
configurado em LOCAL_LLM_URL / LOCAL_LLM_MODEL (produção via túnel: http://127.0.0.1:8088/v1 + qwen3-30b-a3b; ou o
Ollama do Mac: http://127.0.0.1:11434/v1 + qwen2.5:3b).

O microfone de verdade não existe no headless: o teste injeta reconhecedores de voz FALSOS antes do script da página
(um que "fala" o roteiro palavra por palavra emitindo parciais, um ausente e um com permissão negada) e prova:
  • ≥ 3 atualizações do Jev DURANTE a fala da hamburgueria, com decisões mudando enquanto ela fala;
  • as 5 peças coerentes (seção de cardápio, CTA de pedido/delivery, 3 carrosséis, e-mail com assinatura, banners);
  • trocar para a clínica de estética premium muda paleta, fontes e seções;
  • duas paráfrases (pizzaria) chegam ao mesmo segmento e objetivo;
  • "Outra versão" muda decisões mantendo o segmento; Raio-X com as 89 decisões; inspetor do kit;
  • comandos por voz: o roteador separa descrição × comando; comando do logo e das cores travam a peça; "volta as cores
    de antes" restaura a paleta anterior; comando digitado; versões guardadas no servidor, restaurar, novo negócio e
    reabrir o projeto pelo link;
  • caixa de texto (inclusive inglês, emoji, vazio, enorme) e cliques rápidos;
  • o modelo local escreve e preenche os textos (título do site, legendas, assunto do e-mail, slogan…);
  • "Baixar site" gera um HTML válido e autossuficiente; celular 390×844 sem rolagem horizontal;
  • ajustes livres de estilo: as 3 frases de referência ("background verde", "todas as fontes em caps lock", "degradê verde e
    branco") mudam os estilos calculados do site sem refazer nada, viram fitas com ✕ nos monitores, saem pelo ✕, voltam
    pelas versões e pelo "desfazer" por voz, vão no HTML baixado e somem no "Novo negócio"; pela voz, alvo "tudo"
    pergunta ao servidor antes de refazer;
  • custo por atualização < US$ 0,002 e zero erros de console.
Sai com código 0 só se tudo passar. Gasta ~US$ 0,02–0,03 de Jev por execução.
"""
import colorsys
import json
import pathlib
import re
import sys
import time
import urllib.parse
from html.parser import HTMLParser

from playwright.sync_api import sync_playwright

HERE = pathlib.Path(__file__).resolve().parent
SHOTS = HERE / 'shots'
SHOTS.mkdir(parents=True, exist_ok=True)
URL = sys.argv[sys.argv.index('--url') + 1] if '--url' in sys.argv else 'http://localhost:4116/'
SEM_IA = '--sem-ia' in sys.argv
LOGIN = URL.startswith('https://')  # produção fica atrás do login único do hub
EXEMPLOS = {e['id']: e for e in json.loads((HERE.parent / 'data' / 'exemplos.json').read_text(encoding='utf-8'))}
FALA_BURGER = EXEMPLOS['burger']['texto']

falhas = []
feitas = [0]
t_inicio = time.time()


def check(cond, msg):
    feitas[0] += 1
    print(('  ✓ ' if cond else '  ✗ ') + msg, flush=True)
    if not cond:
        falhas.append(msg)
    return cond


def secao(t):
    print(f'\n▶ {t}', flush=True)


# Reconhecedor falso: "fala" window.__roteiroVoz palavra por palavra (parciais a cada 170 ms, finais no fim de cada frase).
FALA_SR = """
window.__vozFim = false;
class FalaSR {
  constructor() { this.lang = 'pt-BR'; this.continuous = true; this.interimResults = true; this._t = []; }
  start() {
    const roteiro = window.__roteiroVoz || '';
    const frases = roteiro.match(/[^.!?]+[.!?]*/g) || [roteiro];
    const finais = []; let t = 350;
    this._t.push(setTimeout(() => this.onstart && this.onstart(), 40));
    frases.forEach((fr) => {
      const pal = fr.trim().split(/\\s+/);
      pal.forEach((_, wi) => {
        t += 170;
        const parcial = pal.slice(0, wi + 1).join(' '), fim = wi === pal.length - 1;
        this._t.push(setTimeout(() => {
          const results = finais.map((f) => { const a = [{ transcript: f + ' ', confidence: 0.92 }]; a.isFinal = true; return a; });
          const cur = [{ transcript: parcial, confidence: 0.9 }]; cur.isFinal = fim; results.push(cur);
          if (fim) finais.push(parcial);
          this.onresult && this.onresult({ resultIndex: results.length - 1, results });
        }, t));
      });
      t += 380;
    });
    this._t.push(setTimeout(() => { window.__vozFim = true; }, t + 60));
  }
  stop() { this._t.forEach(clearTimeout); setTimeout(() => this.onend && this.onend(), 30); }
  abort() { this.stop(); }
}
window.SpeechRecognition = FalaSR; window.webkitSpeechRecognition = FalaSR;
"""
SEM_SR = "for (const k of ['SpeechRecognition', 'webkitSpeechRecognition']) { try { Object.defineProperty(window, k, { value: undefined, configurable: true, writable: true }); } catch (e) {} }"
NEGA_SR = """
class NegaSR { start() { setTimeout(() => this.onerror && this.onerror({ error: 'not-allowed' }), 120); setTimeout(() => this.onend && this.onend(), 180); } stop() {} abort() {} }
window.SpeechRecognition = NegaSR; window.webkitSpeechRecognition = NegaSR;"""

# decisões do Jev que aparecem nos artefatos (a assinatura muda quando o Jev muda de ideia)
CHAVES = ['seg', 'pers', 'obj', 'paleta', 'fonte', 'icone', 'forma', 'disp', 'hero', 'titulo', 'cta', 'img', 'btn', 'carEstilo', 'oferta']


def assinatura(u):
    if not u:
        return None
    base = {k: u.get(k) for k in CHAVES}
    base['secoes'] = tuple(u.get('secoes') or [])
    base['posts'] = tuple((p['fmt'], p['gancho']) for p in (u.get('posts') or []))
    base['email'] = json.dumps(u.get('email') or {}, sort_keys=True, ensure_ascii=False)
    base['anuncios'] = json.dumps(u.get('anuncios') or {}, sort_keys=True, ensure_ascii=False)
    return json.dumps(base, sort_keys=True, ensure_ascii=False)


def estado(pg):
    return pg.evaluate('window.estudio && window.estudio.estado')


def ultimo(pg):
    return pg.evaluate('window.estudio && window.estudio.ultimo')


def esperar_quieto(pg, timeout=45, min_atu=1):
    """Espera a fala acabar e a última atualização do Jev chegar."""
    t0 = time.time()
    while time.time() - t0 < timeout:
        st = estado(pg)
        if st and not st['simulando'] and not st['voando'] and not st['pendente'] and st['atualizacoesFala'] >= min_atu and len(st['grupos']) == 6:
            pg.wait_for_timeout(700)
            st2 = estado(pg)
            if not st2['voando'] and st2['atualizacoesFala'] == st['atualizacoesFala']:
                return st2
        pg.wait_for_timeout(250)
    return estado(pg)


def toasts(pg):
    # leitura atômica: os avisos somem sozinhos, e ler um por um pode esperar 30 s por um que já saiu
    return ' | '.join(pg.locator('.jev-toast').all_inner_texts())


def simular(pg, ex_id, timeout=45):
    pg.click(f'#chips .jev-chip[data-id="{ex_id}"]')
    pg.wait_for_timeout(300)
    return esperar_quieto(pg, timeout)


# ------------------------------------------------------------------ ajustes livres: leitura dos estilos CALCULADOS do site
# roda na página do Estúdio (o iframe é do mesmo domínio); no HTML baixado, o mesmo código roda direto no documento
ESTILOS_JS = """(doc) => {
  const d = doc || document.getElementById('site-frame').contentDocument, w = d.defaultView;
  const fundo = (e) => { const c = w.getComputedStyle(e); return c.backgroundColor + ' ' + c.backgroundImage; };
  const caixa = (sel) => [...d.querySelectorAll(sel)].filter((e) => e.textContent.trim()).slice(0, 8).map((e) => w.getComputedStyle(e).textTransform);
  const st = d.querySelector('style#ajustes');
  return { fundo: fundo(d.documentElement) + ' | ' + fundo(d.body), img: w.getComputedStyle(d.body).backgroundImage + ' ' + w.getComputedStyle(d.documentElement).backgroundImage,
           titulos: caixa('h1, h2'), textos: caixa('section p'), css: st ? st.textContent : null };
}"""


def cores_css(s):
    """rgb()/rgba() de um valor calculado → [(r, g, b)], sem as transparentes."""
    out = []
    for m in re.finditer(r'rgba?\(([^)]*)\)', s or ''):
        v = [float(x) for x in re.split(r'[\s,/]+', m.group(1).strip()) if x]
        if len(v) >= 3 and (len(v) < 4 or v[3] > 0.05):
            out.append(tuple(v[:3]))
    return out


def e_verde(c):
    h, l, s = colorsys.rgb_to_hls(*(x / 255 for x in c))
    return 75 <= h * 360 <= 165 and s >= 0.25 and 0.12 <= l <= 0.88


def e_branco(c):
    return min(c) >= 235


def degrade_verde_branco(img):
    return 'linear-gradient' in (img or '') and any(map(e_verde, cores_css(img))) and any(map(e_branco, cores_css(img)))


class Validador(HTMLParser):
    def __init__(self):
        super().__init__()
        self.pilha, self.erros, self.tags = [], [], set()
        self.vazias = {'meta', 'link', 'br', 'img', 'input', 'hr', 'source', 'area', 'base', 'col', 'embed', 'param', 'track', 'wbr',
                       'path', 'circle', 'rect', 'ellipse', 'line', 'polyline', 'polygon', 'stop', 'use', 'feGaussianBlur', 'fegaussianblur', 'feturbulence'}

    def handle_starttag(self, tag, attrs):
        self.tags.add(tag)
        if tag not in self.vazias:
            self.pilha.append(tag)

    def handle_startendtag(self, tag, attrs):
        self.tags.add(tag)

    def handle_endtag(self, tag):
        if tag in self.vazias:
            return
        if not self.pilha or self.pilha[-1] != tag:
            self.erros.append(f'</{tag}> fora de ordem (esperava </{self.pilha[-1] if self.pilha else "nada"}>)')
            if tag in self.pilha:
                while self.pilha and self.pilha[-1] != tag:
                    self.pilha.pop()
                self.pilha.pop()
            return
        self.pilha.pop()


with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    erros = []
    custos = []

    def logar(ctx):
        # credenciais em .secrets/jev_login, nunca impressas
        email, senha = (HERE.parents[2] / '.secrets' / 'jev_login').read_text().splitlines()[:2]
        pg = ctx.new_page()
        # o login mora no hub do mesmo domínio: jev-estudio.<dominio> → jev.<dominio>
        hub = 'https://jev.' + urllib.parse.urlparse(URL).hostname.split('.', 1)[1]
        pg.goto(hub + '/login?next=' + urllib.parse.quote(URL, safe=''))
        pg.fill('#email', email)
        pg.fill('#password', senha)
        pg.click('button[type=submit]')
        pg.wait_for_url(URL + '**', timeout=30000)
        pg.close()

    def nova_pagina(w=1440, h=900, init=None, rotulo='', **kw):
        ctx = browser.new_context(viewport={'width': w, 'height': h}, device_scale_factor=kw.pop('dsf', 1), accept_downloads=True, **kw)
        if init:
            ctx.add_init_script(init)
        if LOGIN:
            logar(ctx)
        pg = ctx.new_page()
        pg.on('console', lambda m: erros.append(f'{rotulo}console.{m.type}: {m.text}') if m.type in ('error', 'warning') else None)
        pg.on('pageerror', lambda e: erros.append(f'{rotulo}pageerror: {e}'))
        return ctx, pg

    # ------------------------------------------------------------------ 1
    secao('Primeiro frame')
    ctx, page = nova_pagina(init=FALA_SR + f'\nwindow.__roteiroVoz = {json.dumps(FALA_BURGER, ensure_ascii=False)};')
    ctx.grant_permissions(['clipboard-read', 'clipboard-write'], origin=URL.rstrip('/'))
    decidir = []
    page.on('request', lambda r: decidir.append(r.url) if '/api/decidir' in r.url else None)
    page.goto(URL, wait_until='networkidle')
    page.wait_for_timeout(500)
    check('Estúdio por Voz' in page.title(), f'título da página: {page.title()!r}')
    check(page.locator('#mic').is_visible() and page.locator('#mic').bounding_box()['width'] >= 70, 'botão de microfone grande e visível')
    check(page.locator('#chips .jev-chip').count() >= 6, f'{page.locator("#chips .jev-chip").count()} falas prontas para “Simular fala”')
    check(page.locator('#texto').is_visible(), 'caixa de texto alternativa sempre visível')
    check(page.locator('.peca').count() == 5, '5 painéis (site, identidade, carrosséis, e-mail marketing, anúncios)')
    check(page.locator('.jev-topbar .jev-metric').count() >= 3, 'topbar com latência/decisões/custo')
    check(page.locator('#fita .gchip').count() == 6, 'fita com as 6 chamadas paralelas ao Jev')
    page.screenshot(path=str(SHOTS / '01-inicio.png'))

    # ------------------------------------------------------------------ 2
    secao('Microfone: fala da hamburgueria pelo reconhecedor (parciais palavra por palavra)')
    page.click('#mic')
    page.wait_for_timeout(200)
    check(page.get_attribute('#mic', 'aria-pressed') == 'true', 'microfone em estado “ouvindo”')
    assinaturas, t0 = [], time.time()
    atu_durante, meio_foto = 0, False
    while time.time() - t0 < 40:
        st = estado(page)
        fim = page.evaluate('window.__vozFim')
        if not fim:
            atu_durante = st['atualizacoesFala']
        u = ultimo(page)
        a = assinatura(u)
        if a and (not assinaturas or assinaturas[-1][1] != a):
            assinaturas.append((st['atualizacoesFala'], a, (u or {}).get('seg'), (u or {}).get('paleta'), (u or {}).get('hero'), (u or {}).get('cta')))
        if not meio_foto and st['atualizacoesFala'] >= 2 and not fim:
            page.wait_for_timeout(150)
            # lê a parcial ANTES da captura: a captura leva 0,2–0,5 s e a frase podia fechar no meio dela (parcial vazia)
            parcial_meio = page.inner_text('#fala-parcial')
            page.screenshot(path=str(SHOTS / '02-durante-a-fala.png'))
            meio_foto = True
        if fim:
            break
        page.wait_for_timeout(120)
    texto_ouvido = page.inner_text('#fala-final')
    check('Brasa Burger' in texto_ouvido and 'cardápio' in texto_ouvido, f'transcrição ao vivo chegou inteira: “{texto_ouvido[:70]}…”')
    check(meio_foto and len(parcial_meio) > 0, f'parcial em cinza durante a fala: “{parcial_meio[:40] if meio_foto else ""}…”')
    page.click('#mic')  # parar o microfone dispara a atualização final
    st = esperar_quieto(page, 30)
    distintas = len({a[1] for a in assinaturas})
    check(atu_durante >= 3, f'{atu_durante} atualizações do Jev DURANTE a fala (mínimo 3); {st["atualizacoesFala"]} no total')
    check(distintas >= 2, f'as decisões mudaram enquanto a pessoa falava: {distintas} versões diferentes dos artefatos')
    for n, _, seg, pal, hero, cta in assinaturas:
        print(f'      → após {n} atualização(ões): segmento={seg} paleta={pal} topo={hero} botão={cta}')
    u_burger = ultimo(page)
    check(u_burger['seg'] == 'hamburgueria', f'segmento: {u_burger["seg"]}')
    check('cardapio' in u_burger['secoes'], f'site tem a seção de cardápio: {u_burger["secoes"]}')
    check(u_burger['cta'] in ('pedir_whats', 'pedir_delivery', 'cardapio') and u_burger['obj'] == 'delivery', f'CTA de pedido/delivery: {u_burger["cta"]} (objetivo {u_burger["obj"]})')
    check(u_burger['nome'] == 'Brasa Burger' and u_burger['origemNome'] == 'fala' and u_burger['cidade'] == 'Curitiba', f'nome e cidade extraídos da fala: {u_burger["nome"]} / {u_burger["cidade"]}')
    doc = page.frame_locator('#site-frame')
    h1 = doc.locator('h1').first.inner_text()
    check(len(h1) > 5 and doc.locator('#s-cardapio .prato').count() == 4, f'site renderizado: “{h1}” + cardápio com 4 itens e preços')
    check(page.locator('#posts-grid .car').count() == 3 and page.locator('#posts-grid .car-lam').count() == 18 and len({f['fmt'] for f in u_burger['posts']}) == 3,
          f'3 carrosséis de 6 lâminas, formatos diferentes, estilo {u_burger["carEstilo"]}: {[f["fmt"] for f in u_burger["posts"]]}')
    em = u_burger['email']
    txt_email = page.inner_text('#email-corpo')
    check(em['assunto'][:24] in txt_email and em['ass']['nome'] in txt_email, f'e-mail {em["tipo"]} (cabeçalho {em["cabecalho"]}, destaque {em["hero"]}): “{em["assunto"]}” + assinatura de {em["ass"]["nome"]} ({em["ass"]["layout"]})')
    ad = u_burger['anuncios']
    check(page.locator('#ads-corpo .ad').count() >= 3, f'{page.locator("#ads-corpo .ad").count()} banners no painel: {ad["conceito"]}/{ad["estilo"]} “{ad["titulo"]}” → {ad["cta"]}')
    check(page.locator('#marca-corpo svg.logo-id').count() == 1 and page.locator('#marca-corpo .sw').count() == 5, f'identidade: logo ({u_burger["disp"]}/{u_burger["forma"]}/{u_burger["icone"]}), paleta {u_burger["paleta"]}, fontes {u_burger["fonte"]}')
    page.screenshot(path=str(SHOTS / '03-hamburgueria.png'))

    # ------------------------------------------------------------------ 3
    secao('Trocar para a clínica de estética premium (fala simulada pelo mesmo caminho do microfone)')
    st = simular(page, 'clinica')
    u_cli = ultimo(page)
    check(u_cli['seg'] == 'estetica', f'segmento: {u_cli["seg"]}')
    check(u_cli['paleta'] != u_burger['paleta'], f'paleta mudou: {u_burger["paleta"]} → {u_cli["paleta"]}')
    check(u_cli['fonte'] != u_burger['fonte'], f'fontes mudaram: {u_burger["fonte"]} → {u_cli["fonte"]}')
    so_b, so_c = set(u_burger['secoes']), set(u_cli['secoes'])
    check(so_b != so_c and 'cardapio' not in so_c, f'seções mudaram: saiu {sorted(so_b - so_c)}, entrou {sorted(so_c - so_b)}')
    check(st['atualizacoesFala'] >= 3, f'{st["atualizacoesFala"]} atualizações durante a fala simulada')
    page.screenshot(path=str(SHOTS / '04-clinica-premium.png'))

    # ------------------------------------------------------------------ 4
    secao('Paráfrases: mesma coisa com outras palavras')
    simular(page, 'pizzaA')
    ua = ultimo(page)
    simular(page, 'pizzaB')
    ub = ultimo(page)
    check(ua['seg'] == ub['seg'] == 'pizzaria', f'mesmo segmento: {ua["seg"]} = {ub["seg"]}')
    check(ua['obj'] == ub['obj'] == 'delivery', f'mesmo objetivo: {ua["obj"]} = {ub["obj"]}')
    iguais = [k for k in CHAVES if ua[k] == ub[k]]
    print(f'      → {len(iguais)}/{len(CHAVES)} decisões iguais entre as paráfrases: {", ".join(iguais)}')
    check(len(iguais) >= len(CHAVES) * 0.6, 'resultados equivalentes (a maioria das decisões coincide)')

    # ------------------------------------------------------------------ 5
    secao('🎲 Outra versão (sorteio pelas probabilidades do Jev, sem nova chamada)')
    simular(page, 'virada')
    antes = ultimo(page)
    n_req = len(decidir)
    page.click('#b-versao')
    page.wait_for_timeout(700)
    depois = ultimo(page)
    mudou = [k for k in ['paleta', 'fonte', 'icone', 'forma', 'disp', 'hero', 'titulo', 'img', 'btn', 'carEstilo', 'slogan'] if antes[k] != depois[k]]
    mudou += [k for k in ['email', 'anuncios'] if antes[k] != depois[k]]
    mudou += ['posts'] if [x['fmt'] for x in antes['posts']] != [x['fmt'] for x in depois['posts']] else []
    check(depois['seg'] == antes['seg'] and depois['obj'] == antes['obj'], f'segmento e objetivo mantidos: {depois["seg"]} / {depois["obj"]}')
    check(len(mudou) >= 1, f'mudou: {", ".join(mudou)}')
    check(len(decidir) == n_req, 'nenhuma chamada nova ao Jev para a outra versão')
    t = toasts(page)
    check('opção do Jev' in t, f'mostra que as sorteadas foram opções boas do Jev: {t[:150]!r}')
    check(depois['overrides'] > 0 and page.locator('#b-voltar').is_visible(), f'{depois["overrides"]} decisões sorteadas + botão “versão do Jev”')
    page.wait_for_timeout(400)
    page.screenshot(path=str(SHOTS / '05-outra-versao.png'))

    # ------------------------------------------------------------------ 6
    secao('🩻 Raio-X e inspetor')
    page.click('#b-raiox')
    page.wait_for_selector('#raiox.aberto')
    page.wait_for_timeout(400)
    linhas = page.locator('#rx-corpo .rx-l').count()
    txt = page.inner_text('#rx-corpo')
    check(linhas == 89, f'{linhas} decisões listadas (pergunta, escolha, probabilidade, 2º lugar)')
    check('Segmento' in txt and '2º:' in txt and page.locator('#rx-corpo .rx-l.dado').count() > 0, 'mostra 2º lugar e marca as sorteadas com 🎲')
    page.screenshot(path=str(SHOTS / '06-raio-x.png'))
    page.click('#rx-fechar')
    page.wait_for_timeout(300)
    page.locator('.jev-topbar button', has_text='Ver o que o Jev vê').click()
    page.wait_for_selector('.jev-drawer.open')
    page.wait_for_timeout(300)
    ti = page.inner_text('.jev-drawer')
    check('pergunta' in ti and 'latência' in ti, 'inspetor do kit lista as chamadas reais (5 por atualização)')
    page.screenshot(path=str(SHOTS / '07-inspetor.png'))
    page.keyboard.press('Escape')
    page.wait_for_timeout(200)

    # ------------------------------------------------------------------ 5b
    secao('🎯 Comandos por voz, travas e versões')
    page.click('#chips .jev-chip[data-id="comandos"]')
    page.wait_for_timeout(400)
    esperar_quieto(page, 90)
    page.evaluate('() => window.estudio.filaComandos')
    page.wait_for_timeout(2500)
    esperar_quieto(page, 30)
    tr = page.evaluate('() => window.estudio.trechos')
    tipos = [(t['tipo'], t['alvo']) for t in tr]
    print('      → trechos:', tipos)
    check(tr and tr[0]['tipo'] == 'descricao', 'a primeira frase é descrição do negócio')
    check(('comando_de_edicao', 'logo') in tipos, 'o roteador reconheceu o comando do logo')
    check(('fixar', 'logo') in tipos, '“gostei, pode manter” virou fixar o logo')
    check(('comando_de_edicao', 'cores') in tipos, 'o roteador reconheceu o comando das cores')
    check(('desfazer', 'cores') in tipos, '“volta as cores de antes” virou desfazer as cores')
    u = ultimo(page)
    check('logo' in u['pecasTravadas'] and 'cores' in u['pecasTravadas'], f'logo e cores travados: {u["pecasTravadas"]}')
    print(f'      → estilo do logo depois do comando: {u["estiloLogo"]} · paleta final: {u["paleta"]}')
    # a versão do último comando é gravada depois que o comando termina (POST assíncrono): espera até 10 s por ela
    try:
        page.wait_for_function("() => (window.estudio.versoes.lista || []).some((v) => v.motivo === 'desfazer')", timeout=10000)
    except Exception:
        pass
    vs = page.evaluate('() => window.estudio.versoes')
    motivos = [v['motivo'] for v in vs['lista']]
    # "volta as cores de antes" só grava versão quando há o que desfazer: se o Jev manteve a paleta no comando das cores
    # (ex.: "mais escuro" sobre uma paleta que já é escura), não existe versão "desfazer" (a restauração é conferida abaixo)
    pal = {v['id']: (v.get('sel') or {}).get('paleta') for v in page.evaluate("() => fetch(`/api/projetos/${window.estudio.versoes.projeto}`).then(r => r.json()).then(j => j.projeto.versoes)")}
    ids = [v['id'] for v in vs['lista']]
    i_cor = next((i for i, v in enumerate(vs['lista']) if v['motivo'] == 'comando' and v.get('alvo') == 'cores'), None)
    mudou_cores = i_cor is not None and i_cor > 0 and pal.get(ids[i_cor]) != pal.get(ids[i_cor - 1])
    check(vs['n'] >= 4 and 'comando' in motivos and ('desfazer' in motivos or not mudou_cores),
          f'{vs["n"]} versões guardadas ({", ".join(motivos)})' + ('' if mudou_cores else ' · o Jev manteve a paleta: nada a desfazer'))
    antes_cores = None
    for v in vs['lista']:
        if v['motivo'] == 'comando' and v['alvo'] == 'cores':
            break
        antes_cores = v
    sel = page.evaluate("(id) => fetch(`/api/projetos/${window.estudio.versoes.projeto}`).then(r => r.json()).then(j => j.projeto.versoes.find(v => v.id === id))", antes_cores['id']) if antes_cores else None
    check(bool(sel) and sel['sel'].get('paleta') == u['paleta'], f'“volta as cores de antes” restaurou a paleta da {antes_cores and antes_cores["id"]}: {u["paleta"]}')
    page.screenshot(path=str(SHOTS / '05b-comandos.png'))
    # comando digitado
    page.fill('#cmd', 'muda as fontes pra algo mais divertido')
    page.click('#cmd-form button[type="submit"]')
    page.wait_for_timeout(500)
    page.evaluate('() => window.estudio.filaComandos')
    page.wait_for_timeout(1500)
    u2 = ultimo(page)
    check('fontes' in u2['pecasTravadas'] and 'fonte' in u2['travas'], f'comando digitado travou as fontes: {u2["fonte"]}')
    # restaurar a v1 pelo painel de versões
    page.click('#b-versoes')
    page.wait_for_selector('#versoes.aberto')
    page.wait_for_timeout(1200)
    page.screenshot(path=str(SHOTS / '05c-versoes.png'))
    v1 = page.evaluate("() => fetch(`/api/projetos/${window.estudio.versoes.projeto}`).then(r => r.json()).then(j => j.projeto.versoes[0])")
    page.locator(f'#vs-corpo [data-v="{v1["id"]}"] button[data-acao="tudo"]').click()
    page.wait_for_timeout(1500)
    u3 = ultimo(page)
    check(u3['paleta'] == v1['sel'].get('paleta') and not u3['pecasTravadas'], f'↩ Tudo voltou para a v1 (paleta {u3["paleta"]}, sem travas)')
    projeto = page.evaluate('() => window.estudio.versoes.projeto')
    page.click('#vs-fechar')
    page.click('#b-novo')
    page.wait_for_timeout(400)
    check(page.evaluate('() => window.estudio.versoes.n') == 0, 'novo negócio começa um projeto novo')
    page.goto(URL.rstrip('/') + f'/?projeto={projeto}', wait_until='networkidle')
    page.wait_for_timeout(2500)
    check(page.evaluate('() => window.estudio.versoes.n') >= vs['n'], f'reabrir pelo link ?projeto={projeto} traz as versões de volta')

    # ------------------------------------------------------------------ 7
    secao('Caixa de texto (e entradas difíceis)')
    def digitar(txt, espera=True):
        page.fill('#texto', txt)
        page.click('#digitar button[type="submit"]')
        page.wait_for_timeout(300)
        return esperar_quieto(page, 25) if espera else None

    digitar('Tenho uma barbearia clássica no centro de Porto Alegre, com navalha, toalha quente e cerveja para os clientes.')
    u = ultimo(page)
    check(u['seg'] == 'barbearia' and u['cidade'] == 'Porto Alegre', f'texto digitado → {u["seg"]} em {u["cidade"]}')
    digitar('I run a small specialty coffee shop and bakery in São Paulo and I want more people to visit us.')
    u = ultimo(page)
    check(u['seg'] == 'cafeteria', f'em inglês → {u["seg"]} ({u["cidade"]})')
    digitar('🍕🍕🍕 🔥🔥')
    check(len(estado(page)['grupos']) == 6 and not page.locator('.jev-toast.err').count(), 'só emojis: não quebra (o Jev ainda decide)')
    n_req = len(decidir)
    page.fill('#texto', '   ')
    page.click('#digitar button[type="submit"]')
    page.wait_for_timeout(400)
    check(len(decidir) == n_req and 'algumas palavras' in toasts(page), 'texto vazio: aviso amigável e nenhuma chamada ao Jev')
    r = page.request.post(URL.rstrip('/') + '/api/decidir', data={'texto': 'a' * 3500})
    check(r.status == 400 and 'longo' in r.json().get('error', ''), f'texto enorme → 400 amigável: {r.json().get("error")!r}')
    r = page.request.post(URL.rstrip('/') + '/api/decidir', data={'texto': ''})
    check(r.status == 400, 'texto vazio na API → 400')
    r = page.request.post(URL.rstrip('/') + '/api/escrever', data={'texto': ''})
    check(r.status == 400, 'IA local sem fala → 400 amigável')
    # nome editável
    page.fill('#nome', 'Barba Negra')
    page.wait_for_timeout(500)
    check('Barba Negra' in page.frame_locator('#site-frame').locator('.nav').inner_text() or ultimo(page)['nome'] == 'Barba Negra', 'nome editado pelo usuário vai para os artefatos sem nova chamada')

    # ------------------------------------------------------------------ 8
    secao('Cliques rápidos repetidos')
    for ex in ['pet', 'b2b', 'ingles', 'pet', 'b2b']:
        page.click(f'#chips .jev-chip[data-id="{ex}"]')
        page.wait_for_timeout(90)
    st = esperar_quieto(page, 40)
    check(st['texto'].startswith(EXEMPLOS['b2b']['texto'][:40]), 'só a última fala segue (as outras foram canceladas)')
    check(ultimo(page)['seg'] == 'consultoria', f'resultado final coerente: {ultimo(page)["seg"]}')
    for _ in range(4):
        page.click('#b-versao')
    page.wait_for_timeout(500)
    check(ultimo(page)['seg'] == 'consultoria' and not page.locator('.jev-toast.err').count(), '4 “Outra versão” seguidas mantêm o segmento e não quebram')
    page.screenshot(path=str(SHOTS / '08-consultoria-b2b.png'))

    # ------------------------------------------------------------------ 9
    secao('✍️ Modelo local (botão): escreve e preenche os textos')
    info = page.request.get(URL.rstrip('/') + '/api/local').json()
    print(f'      → modelo local: {info.get("label")} · pronto={info.get("pronto")}')
    if SEM_IA:
        print('      (pulado com --sem-ia)')
    elif not info.get('pronto'):
        check(False, 'modelo local indisponível (LOCAL_LLM_URL) — não deu para provar a escrita')
    else:
        simular(page, 'burger')
        t_ia = time.time()
        page.click('#b-ia')
        meio = False
        while time.time() - t_ia < 170:
            st = estado(page)
            botao = page.inner_text('#b-ia')
            if not meio and 'tok/s' in botao and st['escrevendo'] and page.locator('.ia-escrevendo').count():
                page.screenshot(path=str(SHOTS / '09-ia-local-escrevendo.png'))
                meio = True
            if not st['escrevendo'] and time.time() - t_ia > 1.5:
                break
            page.wait_for_timeout(250)
        page.wait_for_timeout(800)
        ia = ultimo(page)['ia']
        status = page.inner_text('#ia-status')
        print(f'      → {status.splitlines()[0] if status else ""}')
        check(len(ia) >= 8, f'{len(ia)}/11 campos escritos: {", ".join(ia.keys())}')
        check(meio, 'texto aparece sendo digitado dentro dos artefatos (cursor vermelho) com tok/s ao vivo no botão')
        h1 = page.frame_locator('#site-frame').locator('h1').first.inner_text()
        check(bool(ia.get('titulo')) and ia['titulo'].strip()[:20].lower() in h1.lower(), f'título do site reescrito: “{h1}”')
        leg = page.locator('#posts-grid [data-campo="legenda1"]').first.inner_text()
        check(bool(ia.get('legenda1')) and ia['legenda1'].split('\n')[0][:20] in leg, f'legenda do carrossel 1: “{leg[:60]}…”')
        ass = page.locator('#email-corpo [data-campo="assunto"]').first.inner_text()
        check(bool(ia.get('assunto')) and ia['assunto'][:18] in ass, f'assunto do e-mail reescrito: “{ass[:60]}”')
        check('tok/s' in status and 'R$ 0' in status, 'mostra tok/s e “R$ 0 por uso” do modelo no nosso servidor')
        page.screenshot(path=str(SHOTS / '10-ia-local.png'))

    # ------------------------------------------------------------------ 9b
    secao('⤢ Ampliar, ⬇️ e-mail e banners, 📋 assinatura')
    page.click('#b-amp-posts'); page.wait_for_selector('#modal-peca:not([hidden])')
    n_lam = page.locator('#mp-corpo .car-lam').count()
    check(n_lam >= 18, f'carrosséis ampliados: {n_lam} lâminas grandes')
    page.screenshot(path=str(SHOTS / '09b-carrosseis.png'))
    page.keyboard.press('Escape'); page.wait_for_timeout(200)
    check(page.locator('#modal-peca').is_hidden(), 'Esc fecha a visão ampliada')
    page.click('#b-amp-email'); page.wait_for_selector('#modal-peca:not([hidden])')
    t_amp = page.inner_text('#mp-corpo')
    u9 = ultimo(page)
    check(u9['email']['ass']['nome'] in t_amp and u9['email']['cta'] in t_amp, 'e-mail ampliado: template master com o botão e a assinatura em uso')
    page.screenshot(path=str(SHOTS / '09b-email.png'))
    page.click('#mp-fechar')
    page.click('#b-amp-ads'); page.wait_for_selector('#modal-peca:not([hidden])')
    n_ads = page.locator('#mp-corpo .ad').count()
    tam = page.evaluate("[...document.querySelectorAll('#mp-corpo .ad[data-w]')].map(a => a.dataset.w + 'x' + a.dataset.h)")
    check(n_ads >= 6 and {'300x250', '728x90', '160x600', '320x50'} <= set(tam), f'banners ampliados: {n_ads} peças, tamanhos {sorted(set(tam))}')
    page.screenshot(path=str(SHOTS / '09b-anuncios.png'))
    page.click('#mp-fechar')
    with page.expect_download() as dl:
        page.click('#b-email-html')
    html_email = pathlib.Path(dl.value.path()).read_text(encoding='utf-8')
    corpo_email = html_email.split('<body', 1)[-1]
    check(html_email.lower().startswith('<!doctype html') and corpo_email.count('<table') >= 4 and '<svg' not in corpo_email and 'data:' not in corpo_email and u9['email']['cta'] in html_email,
          f'e-mail baixado: HTML de tabelas ({corpo_email.count("<table")} tabelas), sem SVG nem data: no corpo, com o botão')
    with page.expect_download() as dl:
        page.click('#b-ads-baixar')
    html_ads = pathlib.Path(dl.value.path()).read_text(encoding='utf-8')
    check(html_ads.lower().startswith('<!doctype html') and all(f'data-w="{w}"' in html_ads for w in ('300', '728', '160', '320')), 'kit de banners baixado com os tamanhos padrão')
    page.click('#b-ass-copiar'); page.wait_for_timeout(400)
    try:
        clip = page.evaluate("navigator.clipboard.readText()")
    except Exception:
        clip = ''
    check(u9['email']['ass']['nome'] in clip, f'assinatura copiada para colar no Gmail: “{clip[:50].strip()}…”')

    # ------------------------------------------------------------------ 10
    secao('⬇️ Baixar site')
    with page.expect_download() as dl:
        page.click('#b-baixar')
    d = dl.value
    destino = SHOTS / 'site-baixado.html'
    d.save_as(str(destino))
    html = destino.read_text(encoding='utf-8')
    v = Validador()
    v.feed(html)
    check(d.suggested_filename.startswith('site-') and d.suggested_filename.endswith('.html'), f'arquivo: {d.suggested_filename} ({len(html) // 1024} KB)')
    check(html.lower().startswith('<!doctype html>') and '</html>' in html and '<title>' in html and 'lang="pt-BR"' in html, 'HTML completo com doctype, <title> e lang pt-BR')
    check(not v.erros and not v.pilha, f'tags balanceadas ({len(v.tags)} tipos de tag){": " + "; ".join(v.erros[:3]) if v.erros else ""}')
    externos = re.findall(r'(?:src|href)="(https?://[^"]+)"', html)
    check(not externos and 'url("/fonts' not in html, 'autossuficiente: nenhum recurso externo (fontes embutidas em base64)')
    check(len(html) < 600_000, 'tamanho razoável (< 600 KB)')
    ctx_dl, pg_dl = nova_pagina(rotulo='[baixado] ')
    pg_dl.goto(destino.as_uri())
    pg_dl.wait_for_timeout(600)
    check(pg_dl.locator('h1').count() >= 1 and pg_dl.locator('section').count() >= 5, f'o site baixado abre sozinho: {pg_dl.locator("section").count()} seções')
    pg_dl.screenshot(path=str(SHOTS / '11-site-baixado.png'), full_page=False)
    ctx_dl.close()

    # custo por atualização (tudo que esta página fez)
    hist = estado(page)['historico']
    custos = [h['custo'] for h in hist if not h.get('cache')]
    lats = [h['ms'] for h in hist if not h.get('cache')]
    ctx.close()

    # ------------------------------------------------------------------ 10b
    secao('Link com ?texto= (página nova)')
    cl, pl = nova_pagina(rotulo='[link] ')
    pl.goto(URL.rstrip('/') + '/?texto=' + urllib.parse.quote('Tenho uma floricultura no centro de Belo Horizonte e faço entregas para casamentos.'), wait_until='networkidle')
    try:
        pl.wait_for_function('() => (window.estudio.estado.grupos || []).length === 6', timeout=30000)
        ul = ultimo(pl)
        check(ul and ul['seg'] and 'Belo Horizonte' in (ul.get('cidade') or ''), f'o link já gera tudo sem clicar: {ul and ul["seg"]} em {ul and ul.get("cidade")}')
    except Exception:
        check(False, 'o link com ?texto= não gerou as 6 decisões em 30 s')
    cl.close()

    # ------------------------------------------------------------------ 11
    secao('Microfone: degradação amigável')
    c2, p2 = nova_pagina(init=SEM_SR, rotulo='[sem-voz] ')
    p2.goto(URL, wait_until='networkidle')
    p2.click('#mic')
    p2.wait_for_timeout(400)
    t = toasts(p2)
    check('não tem reconhecimento de voz' in t and 'Simular' in t, f'navegador sem Web Speech API → {t[:90]!r}')
    check(p2.get_attribute('#mic', 'aria-pressed') == 'false' and 'indisponível' in p2.inner_text('#mic-estado'), 'botão explica que o microfone está indisponível')
    c2.close()
    c3, p3 = nova_pagina(init=NEGA_SR, rotulo='[negado] ')
    p3.goto(URL, wait_until='networkidle')
    p3.click('#mic')
    p3.wait_for_timeout(700)
    t = toasts(p3)
    check('bloqueou o microfone' in t, f'permissão negada → {t[:90]!r}')
    check(p3.get_attribute('#mic', 'aria-pressed') == 'false', 'microfone volta ao estado desligado')
    c3.close()

    # ------------------------------------------------------------------ 12
    secao('Celular 390×844')
    mctx, m = nova_pagina(390, 844, rotulo='[mobile] ', dsf=2, is_mobile=True, has_touch=True)
    m.goto(URL, wait_until='networkidle')
    m.wait_for_timeout(300)
    check(m.evaluate('document.documentElement.scrollWidth') <= 390, 'sem rolagem horizontal no primeiro frame')
    m.click('#chips .jev-chip[data-id="pet"]')
    esperar_quieto(m, 45)
    m.wait_for_timeout(600)
    larg = m.evaluate('document.documentElement.scrollWidth')
    check(larg <= 390, f'com as 5 peças montadas, sem estourar a largura (scrollWidth={larg})')
    check(ultimo(m)['seg'] == 'pet', f'segmento no celular: {ultimo(m)["seg"]}')
    m.evaluate("window.scrollTo(0, 0)")
    m.wait_for_timeout(200)
    m.screenshot(path=str(SHOTS / 'mobile.png'))
    m.evaluate("document.getElementById('painel-site').scrollIntoView({block: 'start'})")
    m.wait_for_timeout(300)
    m.screenshot(path=str(SHOTS / 'mobile-2.png'))
    mctx.close()

    # ------------------------------------------------------------------ 12b
    secao('🎨 Ajustes livres de estilo: as 3 frases de referência no campo de ajuste')
    ca, pa = nova_pagina(rotulo='[ajustes] ')
    dec_aj, cmd_aj = [], []
    pa.on('request', lambda r: dec_aj.append(r.url) if '/api/decidir' in r.url else (cmd_aj.append(r.post_data_json) if '/api/comando' in r.url else None))
    pa.goto(URL, wait_until='networkidle')
    pa.fill('#texto', FALA_BURGER)
    pa.click('#digitar button[type="submit"]')
    pa.wait_for_timeout(300)
    esperar_quieto(pa, 45)
    pa.wait_for_function("() => { const d = document.getElementById('site-frame').contentDocument; return d && d.querySelector('section p'); }", timeout=15000)
    est0 = pa.evaluate(ESTILOS_JS)
    seg0, fonte0 = ultimo(pa)['seg'], ultimo(pa)['fonte']
    n_dec = len(dec_aj)
    print(f'      → site gerado ({seg0}); fundo antes: {est0["fundo"]} · títulos {est0["titulos"][:3]} · textos {est0["textos"][:3]}')

    def ajustar(frase):
        pa.fill('#cmd', frase)
        pa.click('#cmd-form button[type="submit"]')
        pa.wait_for_timeout(300)
        pa.evaluate('() => window.estudio.filaComandos')
        pa.wait_for_timeout(1000)  # o fundo do site tem transição de .6 s: lê o estilo depois dela
        aviso = pa.inner_text('#cmd-vivo') if pa.locator('#cmd-vivo').is_visible() else ''
        return pa.evaluate('() => window.estudio.ajustes'), pa.evaluate(ESTILOS_JS), aviso

    def do_prop(lista, prop):
        return next((a for a in lista if a['prop'] == prop), None)

    def chip_ok(a):
        if not a:
            return False
        c = pa.locator(f'.ajuste-chip:not(.ajuste-chip--mini)[data-id="{a["id"]}"]')
        return c.count() == 1 and c.is_visible() and a['rotulo'] in c.inner_text()

    # 1) "background verde"
    aj1, est1, aviso1 = ajustar('agora quero mudar o background para verde')
    f1 = do_prop(aj1, 'fundo')
    print(f'      → aviso: “{aviso1}” · ajustes: {[(a["id"], a["rotulo"], a["p"]) for a in aj1]}')
    check(bool(f1) and f1['valor'].get('tipo') == 'solida' and 'site' in f1['pecas'], f'“background para verde” virou ajuste de fundo sólido no site: {f1 and f1["rotulo"]}')
    check(any(map(e_verde, cores_css(est1['fundo']))), f'estilo calculado: o fundo do site ficou verde ({est1["fundo"]})')
    check('Ajuste aplicado' in aviso1 and bool(f1) and f1['rotulo'] in aviso1 and '%' in aviso1, f'aviso na tela com o rótulo e a probabilidade do Jev: “{aviso1}”')
    check(chip_ok(f1), 'fita do ajuste com ✕ no monitor do site')
    cores_marca = ((((cmd_aj[-1] if cmd_aj else None) or {}).get('marca') or {}).get('cores') or {})
    pri_tela = pa.locator('#marca-corpo .sw').first.inner_text().strip().lower()  # 1ª amostra da identidade = cor principal
    check(len(cores_marca) >= 5 and str(cores_marca.get('pri', '')).lower() == pri_tela, f'o comando leva a paleta atual (marca.cores): {sorted(cores_marca)} · principal {cores_marca.get("pri")}')

    # 2) "todas as fontes em caps lock": NÃO pode refazer tudo
    aj2, est2, aviso2 = ajustar('agora faça todas as fontes mudarem para caps lock')
    c2 = do_prop(aj2, 'caixa')
    print(f'      → aviso: “{aviso2}” · ajustes: {[(a["id"], a["rotulo"], a["p"]) for a in aj2]}')
    check(bool(c2) and c2['valor'] == 'maiusculas', f'“todas as fontes em caps lock” virou ajuste de caixa alta: {c2 and c2["rotulo"]} ({c2 and "+".join(c2["pecas"])})')
    check(est2['titulos'] and est2['textos'] and all(t == 'uppercase' for t in est2['titulos'] + est2['textos']),
          f'estilo calculado: títulos {est2["titulos"][:4]} e textos {est2["textos"][:4]} em uppercase')
    check(len(dec_aj) == n_dec and ultimo(pa)['seg'] == seg0, f'não refez tudo: nenhuma chamada nova ao /api/decidir, segmento mantido ({seg0})')
    u2 = ultimo(pa)
    check(u2['fonte'] == fonte0 and 'fontes' not in u2['pecasTravadas'], f'nem caiu no fluxo antigo das fontes: o par de fontes ficou ({u2["fonte"]}) e nada foi travado ({u2["pecasTravadas"]})')
    check(chip_ok(c2) and chip_ok(do_prop(aj2, 'fundo')), f'as duas fitas no monitor do site: {pa.locator("#tv-site .ajuste-chip").all_inner_texts()}')

    # 3) "degradê verde e branco": substitui o fundo (mesmo id) e mantém a caixa alta
    aj3, est3, aviso3 = ajustar('agora insira degradê verde e branco no background')
    f3 = do_prop(aj3, 'fundo')
    print(f'      → aviso: “{aviso3}” · ajustes: {[(a["id"], a["rotulo"], a["p"]) for a in aj3]}')
    check(bool(f3) and f3['valor'].get('tipo') == 'degrade' and len([a for a in aj3 if a['id'] == f3['id']]) == 1 and f3['id'] == f1['id'],
          f'degradê substituiu o fundo verde (mesmo id {f3 and f3["id"]}): {f3 and f3["rotulo"]}')
    check(degrade_verde_branco(est3['img']), f'estilo calculado: fundo com linear-gradient verde e branco ({est3["img"]})')
    check(bool(do_prop(aj3, 'caixa')) and all(t == 'uppercase' for t in est3['titulos'] + est3['textos']), 'a caixa alta continua valendo')
    check(len(dec_aj) == n_dec and chip_ok(f3) and chip_ok(do_prop(aj3, 'caixa')), 'as 3 frases sem refazer nada, com as fitas atualizadas')
    pa.wait_for_timeout(700)
    pa.screenshot(path=str(SHOTS / '12b-ajustes.png'))
    pa.locator('#painel-site').screenshot(path=str(SHOTS / '12b-ajustes-painel-site.png'))
    try:
        pa.wait_for_function("() => window.estudio.versoes.lista.filter((v) => v.motivo === 'ajuste').length >= 3", timeout=10000)
    except Exception:
        pass
    vs_aj = pa.evaluate('() => window.estudio.versoes')
    v_aj = [v for v in vs_aj['lista'] if v['motivo'] == 'ajuste']
    rc = pa.evaluate("(id) => fetch(`/api/projetos/${window.estudio.versoes.projeto}/versoes/${id}`).then((r) => r.json()).then((j) => j.receita)", v_aj[-1]['id']) if v_aj else {}
    check(len(v_aj) >= 3 and {a['id'] for a in (rc.get('ajustes') or [])} == {a['id'] for a in aj3}, f'cada ajuste gravou uma versão ({len(v_aj)}) e a receita guarda os ajustes')

    # 4) o HTML baixado traz os ajustes (e eles valem quando o arquivo abre sozinho)
    with pa.expect_download() as dl:
        pa.click('#b-baixar')
    html_aj = pathlib.Path(dl.value.path()).read_text(encoding='utf-8')
    m_aj = re.search(r'<style id="ajustes">(.*?)</style>', html_aj, re.S)
    check(bool(m_aj) and 'linear-gradient' in m_aj.group(1) and 'uppercase' in m_aj.group(1), f'HTML baixado com <style id="ajustes"> ({len(m_aj.group(1)) if m_aj else 0} caracteres de CSS)')
    destino_aj = SHOTS / 'site-baixado-ajustes.html'
    destino_aj.write_text(html_aj, encoding='utf-8')
    cdl, pdl = nova_pagina(rotulo='[baixado-ajustes] ')
    pdl.goto(destino_aj.as_uri())
    pdl.wait_for_timeout(600)
    est_dl = pdl.evaluate(f'() => ({ESTILOS_JS})(document)')
    check(degrade_verde_branco(est_dl['img']) and all(t == 'uppercase' for t in est_dl['titulos'] + est_dl['textos']), 'o site baixado abre com o degradê verde e branco e tudo em caixa alta')
    pdl.screenshot(path=str(SHOTS / '12b-site-com-3-ajustes.png'))
    cdl.close()

    # 5) celular: as fitas não estouram a largura
    pa.set_viewport_size({'width': 390, 'height': 844})
    pa.wait_for_timeout(700)
    larg = pa.evaluate('document.documentElement.scrollWidth')
    fita = pa.locator('#tv-site .ajuste-chip').first.bounding_box()
    check(larg <= 390 and bool(fita) and fita['x'] >= 0 and fita['x'] + fita['width'] <= 390, f'celular 390 px com as fitas: scrollWidth={larg}, fita em x={fita and round(fita["x"])}–{fita and round(fita["x"] + fita["width"])}')
    pa.evaluate("window.scrollTo(0, document.getElementById('painel-site').getBoundingClientRect().top + window.scrollY - 64)")
    pa.wait_for_timeout(300)
    pa.screenshot(path=str(SHOTS / '12b-ajustes-mobile.png'))
    pa.set_viewport_size({'width': 1440, 'height': 900})
    pa.wait_for_timeout(400)

    # 6) tirar a caixa alta pelo ✕: o estilo volta ao de antes
    c3 = do_prop(aj3, 'caixa')
    pa.locator(f'#tv-site .ajuste-chip[data-id="{c3["id"]}"] .aj-x').click()
    pa.wait_for_timeout(1000)
    aj4, est4 = pa.evaluate('() => window.estudio.ajustes'), pa.evaluate(ESTILOS_JS)
    check(not do_prop(aj4, 'caixa') and pa.locator(f'.ajuste-chip[data-id="{c3["id"]}"]').count() == 0, 'o ✕ tirou o ajuste e as fitas dele em todos os monitores')
    check(est4['titulos'] == est0['titulos'] and est4['textos'] == est0['textos'] and degrade_verde_branco(est4['img']),
          f'o estilo voltou ao de antes (textos {est4["textos"][:3]}) e o degradê ficou')

    # 7) pela voz, com alvo "tudo": o /api/comando vem ANTES de decidir refazer tudo
    n_dec = len(dec_aj)
    pa.evaluate("() => window.estudio.comando('agora faça todas as fontes mudarem para caps lock', 'comando_de_edicao', 'tudo')")
    pa.wait_for_timeout(300)
    pa.evaluate('() => window.estudio.filaComandos')
    pa.wait_for_timeout(1000)
    aj5, est5 = pa.evaluate('() => window.estudio.ajustes'), pa.evaluate(ESTILOS_JS)
    ult_cmd = (cmd_aj[-1] if cmd_aj else None) or {}
    check(ult_cmd.get('alvo') == 'tudo' and bool(do_prop(aj5, 'caixa')) and len(dec_aj) == n_dec and all(t == 'uppercase' for t in est5['textos']),
          f'voz com alvo “tudo”: perguntou ao /api/comando, aplicou a caixa alta e não refez tudo ({len(dec_aj) - n_dec} chamadas ao /api/decidir)')

    # 7b) desfazer pela voz: "volta o site como estava antes" desfaz a última mudança do site (a caixa alta que voltou)
    pa.evaluate("() => window.estudio.comando('volta o site como estava antes', 'desfazer', 'site')")
    pa.wait_for_timeout(300)
    pa.evaluate('() => window.estudio.filaComandos')
    pa.wait_for_timeout(1000)
    aj5b, est5b = pa.evaluate('() => window.estudio.ajustes'), pa.evaluate(ESTILOS_JS)
    check([a['id'] for a in aj5b] == [f3['id']] and do_prop(aj5b, 'fundo')['valor'].get('tipo') == 'degrade' and est5b['textos'] == est0['textos'] and degrade_verde_branco(est5b['img']),
          f'desfazer pela voz tirou só a caixa alta (a última mudança do site) e manteve o degradê: {[a["rotulo"] for a in aj5b]}')

    # 8) desfazer pelas versões: volta a versão do 1º ajuste (só o fundo verde sólido)
    pa.wait_for_function("() => window.estudio.versoes.lista.some((v) => v.motivo === 'ajuste' && v.rotulo.includes('background para verde'))", timeout=10000)
    v_verde = next(v for v in pa.evaluate('() => window.estudio.versoes')['lista'] if v['motivo'] == 'ajuste' and 'background para verde' in v['rotulo'])
    pa.click('#b-versoes')
    pa.wait_for_selector('#versoes.aberto')
    pa.wait_for_timeout(700)
    pa.locator(f'#vs-corpo [data-v="{v_verde["id"]}"] button[data-acao="tudo"]').click()
    pa.wait_for_timeout(1500)
    aj6, est6 = pa.evaluate('() => window.estudio.ajustes'), pa.evaluate(ESTILOS_JS)
    pa.click('#vs-fechar')
    check([a['id'] for a in aj6] == [f1['id']] and do_prop(aj6, 'fundo')['valor'].get('tipo') == 'solida', f'↩ Tudo da v{v_verde["n"]} trouxe de volta só o fundo verde: {[a["rotulo"] for a in aj6]}')
    check(est6['fundo'] == est1['fundo'] and est6['img'] == est1['img'] and est6['titulos'] == est1['titulos'] and est6['textos'] == est1['textos']
          and pa.locator('.ajuste-chip:not(.ajuste-chip--mini)').count() == 1, f'o site voltou junto, igual a logo depois da 1ª frase: fundo {est6["fundo"]}, uma fita só')
    # 8b) o botão "site" de uma versão traz o site como era nela, com os ajustes do site (o degradê e a caixa alta)
    v_deg = next(v for v in pa.evaluate('() => window.estudio.versoes')['lista'] if v['motivo'] == 'ajuste' and 'degradê' in v['rotulo'])
    pa.click('#b-versoes')
    pa.wait_for_selector('#versoes.aberto')
    pa.wait_for_timeout(700)
    pa.locator(f'#vs-corpo [data-v="{v_deg["id"]}"] button[data-acao="site"]').click()
    pa.wait_for_timeout(1500)
    aj6b, est6b = pa.evaluate('() => window.estudio.ajustes'), pa.evaluate(ESTILOS_JS)
    pa.click('#vs-fechar')
    check({a['id'] for a in aj6b} == {f3['id'], c3['id']} and degrade_verde_branco(est6b['img']) and all(t == 'uppercase' for t in est6b['textos']),
          f'o botão “site” da v{v_deg["n"]} trouxe o site daquela versão, com os ajustes dele: {[a["rotulo"] for a in aj6b]}')

    # 9) "Novo negócio" limpa: nada de ajuste no próximo site
    pa.click('#b-novo')
    pa.wait_for_timeout(400)
    check(pa.evaluate('() => window.estudio.ajustes.length') == 0 and pa.locator('.ajuste-chip').count() == 0, '“Novo negócio” limpa os ajustes e as fitas')
    pa.fill('#texto', 'Tenho um pet shop de bairro em Belo Horizonte com banho e tosa.')
    pa.click('#digitar button[type="submit"]')
    pa.wait_for_timeout(300)
    esperar_quieto(pa, 45)
    pa.wait_for_timeout(800)
    est7 = pa.evaluate(ESTILOS_JS)
    check(ultimo(pa)['seg'] != seg0 and not est7['css'], f'o site do negócio novo ({ultimo(pa)["seg"]}) nasce sem os ajustes do anterior')
    ca.close()

    # ------------------------------------------------------------------ 13
    secao('Custo, latência e console')
    if custos:
        print(f'      → {len(custos)} atualizações ao vivo: custo médio US$ {sum(custos) / len(custos):.6f}, máximo US$ {max(custos):.6f}; '
              f'latência (6 chamadas em paralelo) p50 {sorted(lats)[len(lats) // 2]} ms, máx {max(lats)} ms')
    check(bool(custos) and max(custos) < 0.002, f'custo por atualização < US$ 0,002 (máx US$ {max(custos) if custos else 0:.6f})')
    for e in erros:
        print('      ' + e)
    check(not erros, f'{len(erros)} erro(s)/aviso(s) de console')
    browser.close()

print(f'\n{"=" * 60}\n{"FALHOU" if falhas else "PASSOU"} — {len(falhas)} falha(s) em {feitas[0]} verificações, {time.time() - t_inicio:.0f} s')
for f in falhas:
    print('  ✗ ' + f)
sys.exit(1 if falhas else 0)
