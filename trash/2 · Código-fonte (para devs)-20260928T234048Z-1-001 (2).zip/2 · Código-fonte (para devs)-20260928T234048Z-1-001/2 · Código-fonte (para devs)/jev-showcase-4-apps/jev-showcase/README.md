# Jev Showcase — código-fonte (plataforma + 4 apps)

Código completo de quatro demos do **Jev** e da plataforma que os coloca no ar, pronto para rodar no seu computador e
para publicar numa VPS com HTTPS e login.

O Jev (`typesafe/jev-1.13`, da TypeSafe, acessado pelo OpenRouter) é um modelo de **decisões**, não de texto: recebe um
estado (os dados do momento) e perguntas tipadas — escolha (`choice`), nota numa escala (`score`) ou sim/não (`noul`) —
e devolve **probabilidades** em ~0,2–0,5 s, com dezenas de perguntas por chamada. Todo texto que a pessoa lê vem do
próprio app (ou, no Estúdio, de um modelo local, no clique).

| app | endereço | porta local | o que faz |
|---|---|---|---|
| Índice dos demos (hub) | `https://jev.<DOMINIO>` (e o login) | 4100 | os cartões dos demos, os números ao vivo do gateway e os diagramas |
| Planilha Preditiva | `https://jev-planilha.<DOMINIO>` | 4101 | Crie uma coluna escrevendo só o título — o Jev preenche centenas de linhas em segundos. |
| Busca que Entende | `https://jev-busca.<DOMINIO>` | 4111 | O Jev avalia o catálogo inteiro a cada busca: “presente pra mãe que ama jardinagem até R$ 150”. |
| Site que Lê Intenções (versão genérica) | `https://jev-site.<DOMINIO>` | 4115 | A página de Casa Grão em que tudo abre por clique — e se monta para você conforme o que você abre. |
| Estúdio por Voz | `https://jev-estudio.<DOMINIO>` | 4116 | Fale do seu negócio e veja site, marca, carrosséis, e-mail marketing e anúncios nascerem juntos — depois peça ajustes por voz e volte a qualquer versão. |

Gerado em 24/09/2026. A pasta **“Prompts (para quem não programa)”**, ao lado desta, tem um prompt por app que gera o
mesmo resultado com o Claude Code, sem precisar mexer em código: quem não programa usa os prompts; quem programa usa
este pacote.

## Estrutura

```
jev-showcase/
├── README.md · configurar-dominio.sh · apps.json · .gitignore · .dockerignore
├── gateway/          o único lugar com a chave do OpenRouter: orçamento, limites, cache e métricas (1 arquivo)
├── auth/             login único (SSO) que o Caddy consulta a cada pedido (forward_auth) (2 arquivos)
├── shared/server/    kit.mjs (servidor HTTP, rotas, SSE, chamada ao Jev) e llm.mjs (cliente do modelo local) (2 arquivos)
├── shared/ui/        jev-kit.js + jev.css (topbar, inspetor, diagramas), jev-chamadas.js e diagramas/ (16 arquivos)
├── deploy/           gen.mjs → Caddyfile + docker-compose.yml, deploy.sh, smoke.sh, authcheck.sh, setup-vps.sh, Dockerfiles, llm.json, ready.json (12 arquivos)
├── apps/hub/         índice dos demos: cartões, números ao vivo, capturas e arquiteturas.html (14 arquivos)
├── apps/planilha/    Planilha Preditiva (17 arquivos)
├── apps/busca/       Busca que Entende (13 arquivos)
├── apps/site/        Site que Lê Intenções (versão genérica, com um negócio fictício de exemplo) (21 arquivos)
├── apps/estudio/     Estúdio por Voz (78 arquivos)
└── report/exemplos/  captura de exemplos reais para os diagramas (9 arquivos)
```

- **Zero dependências npm.** Tudo é Node 22 com os módulos nativos (`node:http`, `node:crypto`…); não há `npm install`.
- **Um contêiner por app** (`deploy/Dockerfile.app`), mais o `gateway`, o `auth`, o `caddy` e, se ligado, o `llm`.
- **O gateway é o único lugar que conhece a chave do OpenRouter.** Os apps chamam `POST /v1/decide` nele; o gateway
  aplica orçamento, limite por IP, cache opcional e nova tentativa, e registra custo e latência de cada decisão
  (`GET /v1/stats`).
- **Login único:** o Caddy pergunta ao `auth` (`forward_auth`) a cada pedido; quem não entrou vai para
  `https://jev.<DOMINIO>/login`, e uma sessão vale para todos os subdomínios.
- **O kit** (`shared/ui/jev-kit.js` + `jev.css`) dá a todos os apps a barra do topo com latência, decisões e custo, o
  inspetor «Ver o que o Jev vê» (o estado, as perguntas e as respostas reais de cada chamada) e o botão «Arquitetura».
- `<DOMINIO>` é um marcador: o `configurar-dominio.sh` troca pelo hostname da sua VPS (veja “Publicar”).

## Requisitos

- **Node 22** (no seu computador para rodar local; na VPS ele roda dentro dos contêineres).
- **Docker com Compose** na VPS (o `deploy/setup-vps.sh` instala). No seu computador, só `ssh` e `rsync`.
- **Python 3 + Playwright** para os testes: `python3 -m pip install playwright pillow` e
  `python3 -m playwright install chromium` (use um venv se o seu Python recusar instalar fora de um).
- **Uma chave do OpenRouter com crédito** (https://openrouter.ai/keys). Dica: ponha um limite de gasto na própria chave.
- Opcional, para a “IA local” do Estúdio no seu computador: [Ollama](https://ollama.com) com `ollama pull qwen2.5:3b`.

## Rodar localmente

Na raiz do pacote (localmente não há login: o login é do Caddy + `auth`, só na VPS).

```bash
# 1. a chave do OpenRouter num arquivo fora do código (nunca no git, nunca na linha de comando)
mkdir -p .secrets && chmod 700 .secrets
read -rsp 'Chave do OpenRouter: ' K; echo; printf '%s' "$K" > .secrets/openrouter_key; unset K
chmod 600 .secrets/openrouter_key

# 2. o gateway do Jev (deixe rodando; em outro terminal ou com & no fim)
OPENROUTER_KEY_FILE=.secrets/openrouter_key PORT=8787 DATA_DIR=scratch/gateway node gateway/server.mjs
curl -s localhost:8787/healthz          # {"ok":true,"model":"typesafe/jev-1.13"}

# 3. os apps (cada um num terminal, ou com & no fim)
JEV_GATEWAY_URL=http://127.0.0.1:8787 PORT=4100 node apps/hub/server.mjs        # índice dos demos
JEV_GATEWAY_URL=http://127.0.0.1:8787 PORT=4101 node apps/planilha/server.mjs
JEV_GATEWAY_URL=http://127.0.0.1:8787 PORT=4111 node apps/busca/server.mjs
JEV_GATEWAY_URL=http://127.0.0.1:8787 PORT=4115 node apps/site/server.mjs
JEV_GATEWAY_URL=http://127.0.0.1:8787 PORT=4116 node apps/estudio/server.mjs
```

Abra `http://localhost:<porta>/` de cada app (os cartões do hub apontam para os endereços `https://…<DOMINIO>` da VPS).
Cada app guarda o que precisa em `apps/<id>/data-runtime/` (ou em `DATA_DIR`). O gasto aparece em
`curl -s localhost:8787/v1/stats`.

**IA local do Estúdio no computador:** sem `LOCAL_LLM_URL`, o app usa o Ollama em `http://127.0.0.1:11434/v1` com o
`qwen2.5:3b` (o formato sai certo, mas o texto é fraco). Para usar o modelo da VPS, abra um túnel e aponte para ele:

```bash
ssh -N -L 8088:127.0.0.1:8088 root@<DOMINIO> &
LOCAL_LLM_URL=http://127.0.0.1:8088/v1 LOCAL_LLM_MODEL=qwen3-30b-a3b \
  JEV_GATEWAY_URL=http://127.0.0.1:8787 PORT=4116 node apps/estudio/server.mjs
```

## Publicar numa VPS (Ubuntu 24.04, Hostinger)

1. **VPS.** Ubuntu 24.04. Com o modelo local do Estúdio ligado, **KVM 8** (8 vCPU, 32 GB de RAM, ~25 GB livres de
   disco); sem ele, um **KVM 2** basta (veja “Modelo local do Estúdio”). Na Hostinger, o hostname da VPS (hPanel → VPS
   → Visão geral, no formato `srv123456.hstgr.cloud`) **já resolve qualquer subdomínio** (`*.srv123456.hstgr.cloud`
   aponta para a VPS): não há DNS para criar. Confira: `dig +short jev-planilha.srv123456.hstgr.cloud`.
   Com um domínio próprio, crie um registro A curinga (`*.seudominio.com.br` → IP da VPS).
2. **Acesso SSH por chave:** `ssh-copy-id root@<DOMINIO>`, com o hostname da sua VPS no lugar de `<DOMINIO>` (a
   senha de root fica no hPanel).
3. **Domínio no pacote**, uma vez, na raiz:
   ```bash
   ./configurar-dominio.sh srv123456.hstgr.cloud
   ```
   Troca `<DOMINIO>` em todos os arquivos (o endereço do SSH no `deploy/deploy.sh`, o `gen.mjs`, o login, o kit, o
   hub, os READMEs) e regera `deploy/Caddyfile` e `deploy/docker-compose.yml`. Os endereços ficam
   `https://jev.srv123456.hstgr.cloud` (login e índice) e `https://jev-planilha.…`, `jev-busca`, `jev-site`,
   `jev-estudio`.
4. **Preparar a VPS** (Docker, firewall `ufw` só com 22/80/443, fail2ban, teto de log do Docker, `/etc/jev` e
   `/opt/jev`):
   ```bash
   scp deploy/setup-vps.sh root@<DOMINIO>:/tmp/ && ssh root@<DOMINIO> 'bash /tmp/setup-vps.sh'
   ```
   No painel da Hostinger, confira que o firewall da VPS (se você ativou um) libera 80 e 443: sem elas o Let's Encrypt
   não emite os certificados.
5. **Login (usuário e senha).** A plataforma espera `AUTH_PASS_HASH=scrypt:<sal em hex>:<hash em hex>` (scrypt do
   Node com os parâmetros padrão, 32 bytes) e um `AUTH_SECRET` com 32 caracteres ou mais. Gere tudo sem a senha
   aparecer na tela nem no histórico:
   ```bash
   mkdir -p .secrets && chmod 700 .secrets
   read -rp 'E-mail do login: ' JEV_EMAIL; read -rsp 'Senha do login: ' JEV_SENHA; echo
   JEV_EMAIL="$JEV_EMAIL" JEV_SENHA="$JEV_SENHA" node --input-type=module -e '
   import crypto from "node:crypto";
   const sal = crypto.randomBytes(16), hash = crypto.scryptSync(process.env.JEV_SENHA, sal, 32);
   console.log(`AUTH_USER=${process.env.JEV_EMAIL.trim().toLowerCase()}`);
   console.log(`AUTH_PASS_HASH=scrypt:${sal.toString("hex")}:${hash.toString("hex")}`);
   console.log(`AUTH_SECRET=${crypto.randomBytes(32).toString("hex")}`);' > .secrets/auth.env
   printf '%s\n%s\n' "$JEV_EMAIL" "$JEV_SENHA" > .secrets/jev_login; unset JEV_SENHA
   chmod 600 .secrets/auth.env .secrets/jev_login
   ```
   `.secrets/jev_login` (linha 1 = e-mail, linha 2 = senha) é o que o `deploy/authcheck.sh` e os e2e usam para entrar
   em produção. Opcionais no `auth.env`: `SESSION_DAYS` (30), `HUB_HOST`, `ALLOWED_HOST_RE`, `COOKIE_NAME`.
6. **Arquivos de ambiente na VPS** (`/etc/jev/*.env`; os valores saem de `.secrets/` e não aparecem na tela):
   ```bash
   { printf 'OPENROUTER_API_KEY=%s\n' "$(cat .secrets/openrouter_key)"
     printf 'BUDGET_TOTAL_USD=12\nBUDGET_DAILY_USD=3\nAPP_DAILY_USD=1\nRATE_PER_MIN=240\n'
   } | ssh root@<DOMINIO> 'umask 077 && cat > /etc/jev/gateway.env'
   ssh root@<DOMINIO> 'umask 077 && cat > /etc/jev/auth.env' < .secrets/auth.env
   # variáveis que todo app recebe; aqui, onde o Estúdio acha o modelo local (deixe vazio se ele estiver desligado)
   printf 'LOCAL_LLM_URL=http://llm:8080/v1\nLOCAL_LLM_MODEL=qwen3-30b-a3b\n' \
     | ssh root@<DOMINIO> 'umask 077 && cat > /etc/jev/apps.env'
   ```
   Depois de mudar um `.env`, recrie o contêiner: `ssh root@<DOMINIO> 'cd /opt/jev/deploy && docker compose up -d
   --force-recreate gateway'` (o `restart` não relê o arquivo).
7. **Modelo local do Estúdio** (só com ele ligado em `deploy/llm.json`; ~18,6 GB, alguns minutos):
   ```bash
   ssh root@<DOMINIO> 'mkdir -p /opt/models && curl -fL --retry 3 -C - \
     -o /opt/models/qwen3-30b-a3b-instruct-2507-q4km.gguf \
     https://huggingface.co/unsloth/Qwen3-30B-A3B-Instruct-2507-GGUF/resolve/main/Qwen3-30B-A3B-Instruct-2507-Q4_K_M.gguf \
     && sha256sum /opt/models/qwen3-30b-a3b-instruct-2507-q4km.gguf'
   # esperado: 6c997b8af17debdfb01d890214400ccbab00db6acc0ba8da5de1cc906c4774d0
   ```
8. **Publicar** (gera o Caddyfile e o compose, envia o pacote para `/opt/jev` com `rsync` e sobe tudo com
   `docker compose up -d --build`):
   ```bash
   ACME_EMAIL=voce@exemplo.com deploy/deploy.sh        # o ACME_EMAIL (opcional) recebe os avisos do Let's Encrypt
   deploy/deploy.sh app-estudio app-hub                 # depois: só os serviços que mudaram
   ```
   O `deploy.sh` usa `root@<DOMINIO>`; para outro acesso, `HOST=usuario@host deploy/deploy.sh`. Na primeira subida o
   Caddy emite um certificado por endereço (5, um por app); acompanhe com
   `ssh root@<DOMINIO> 'cd /opt/jev/deploy && docker compose logs caddy | grep -iE "certificate obtained|error"'`.
9. **Verificar:**
   ```bash
   deploy/smoke.sh       # cada endereço: HTTPS, raiz protegida (302 para o login) e /healthz público
   deploy/authcheck.sh   # entra com .secrets/jev_login: sem sessão bloqueia, com sessão abre (5/5)
   ```
   Os dois saem com código 0 quando está tudo certo. Para testar outro domínio sem reconfigurar:
   `DOMAIN=outro.host deploy/smoke.sh`. Rode também os e2e contra produção (veja “Testes”).

Os dados de cada app ficam em volumes do Docker (`jev_<app>_data`); o gateway guarda `stats.json` e `usage.jsonl` (IP
só como hash) no volume `jev_gateway_data`.

## Modelo local do Estúdio

O botão azul **“Escrever textos com IA local”** do Estúdio reescreve 11 textos com as decisões do Jev como briefing, em
streaming. Na VPS isso é o **Qwen3-30B-A3B-Instruct-2507 (Q4_K_M)** no `llama-server` do llama.cpp, serviço `llm` do
compose, gerado a partir de `deploy/llm.json` (só na rede interna; `127.0.0.1:8088` na VPS, para túnel):

- **Recursos:** arquivo de 18,6 GB; ~17 GiB de RAM em uso (teto de 24 GB no contêiner); `cpus: 8.0` com 5 threads de
  geração. Com a plataforma e os outros apps, precisa de **8 vCPU e 32 GB (KVM 8)**; um KVM 4 (16 GB) não comporta.
  Leva alguns minutos para carregar depois de reiniciar; enquanto isso a tecla avisa que o modelo está carregando.
  Medido na KVM 8: a 1ª palavra sai em 5–11 s e os 11 textos em ~30 s a ~1,5 min, sem custo por uso.
- **Sem o modelo** (VPS menor, ou arquivo não baixado), ponha `"enabled": false` em `deploy/llm.json`, deixe
  `/etc/jev/apps.env` sem as duas linhas `LOCAL_LLM_*` e publique de novo. Todo o resto do Estúdio (voz, as 6 chamadas
  ao Jev, peças, Raio-X, versões e downloads) funciona igual; só a tecla azul avisa que o modelo local não está
  disponível, e os textos continuam vindo da biblioteca escolhida pelo Jev. Atenção: o Docker recusa `cpus: 8.0` numa
  VPS com menos de 8 vCPU, então em VPS menor o `llm` precisa ficar desligado.

## Custos e orçamento do Jev

- **Preço:** o Jev cobra por token de entrada (US$ 0,042 por milhão, na época da medição); a resposta são só
  probabilidades. Medido por ação: Planilha **US$ 0,0005–0,0013 por coluna** (~150 linhas em 0,4–0,7 s); Busca
  **~US$ 0,0009 por busca** (6 chamadas paralelas, 125 perguntas); Estúdio **~US$ 0,0008–0,001 por atualização**
  (89 decisões em 6 chamadas paralelas); Site **~US$ 0,00014 por decisão** (7–9 perguntas).
- **Orçamento no gateway** (`/etc/jev/gateway.env` na VPS; variáveis de ambiente no local): `BUDGET_TOTAL_USD` (teto de
  toda a vida da instalação, padrão 12), `BUDGET_DAILY_USD` (por dia UTC, padrão 3), `APP_DAILY_USD` (por app por dia,
  padrão 1), `APP_CAPS_JSON` (tetos por app, ex.: `{"estudio": 2}`) e `RATE_PER_MIN` (chamadas por IP por minuto,
  padrão 240). Estourado o teto, os apps mostram «O orçamento de demonstração do Jev acabou por hoje».
  Os contadores ficam em `stats.json` no volume do gateway; para zerar, apague o arquivo e recrie o gateway.
- **Acompanhar:** o hub mostra decisões, chamadas, custo total e latência ao vivo; o detalhe por app está em
  `GET /v1/stats` do gateway (na VPS: `cd /opt/jev/deploy && docker compose exec gateway wget -qO- localhost:8787/v1/stats`).
  Opcionais do
  gateway: `JEV_MODEL` (padrão `typesafe/jev-1.13`) e `JEV_URL` (padrão, o endpoint de decisões do OpenRouter).
- **Testes** (medido): um e2e completo gasta ~US$ 0,01 (Planilha, Busca e Site, cada um) e ~US$ 0,06 (Estúdio).

## Testes

Cada app tem `apps/<id>/test/e2e.py` (Playwright, Chromium headless): percorre os fluxos como uma pessoa, confere que o
Jev decidiu (textos, estados e números na tela), exige zero erros de console e salva capturas em `test/shots/`. Sai com
código 0 só sem falhas. O endereço entra de um jeito diferente em cada um:

```bash
APP_URL=http://localhost:4101  python3 apps/planilha/test/e2e.py       # ~40 s
BUSCA_URL=http://localhost:4111 python3 apps/busca/test/e2e.py         # ~30 s
python3 apps/estudio/test/e2e.py --url http://localhost:4116/ [--sem-ia]   # 3–7 min; --sem-ia pula o modelo local
python3 apps/site/test/e2e.py --url http://127.0.0.1:4115/ [--sem-sims | --sims a,b]   # ~5 min com as simulações
```

Com `--url https://…`, os e2e do Estúdio e do Site fazem login com `.secrets/jev_login` (sem imprimir). Os da Planilha e
da Busca não fazem login: rode-os contra a instância local. O e2e do Estúdio tem checagens de tempo (≥ 3 atualizações
do Jev durante a fala simulada) e, sem `--sem-ia`, espera o modelo local escrever os 11 textos em até 120 s: numa
máquina muito carregada, ou com o Ollama lento, rode com `--sem-ia` e confira a IA local na VPS. A Planilha também
tem `test/bench_lotes.mjs` e `test/bench_modelos.mjs` (medem qualidade e custo; usam `JEV_GATEWAY_URL`).

## Diagramas

- `shared/ui/diagramas/` tem os diagramas prontos (servidos em `/_jev/diagramas/`, abertos pelo botão «Arquitetura»):
  a visão geral (`plataforma`) e os da Planilha, da Busca e do Estúdio, cada um com a arquitetura, um exemplo real
  «entrada → Jev → saída» e o JSON das chamadas. A visão geral foi desenhada para a vitrine completa (19 apps, com
  outros serviços): vale como referência do caminho navegador → Caddy → app → gateway → OpenRouter → Jev.
  O Site genérico ainda não tem diagrama próprio: o botão mostra a visão geral.
- `apps/hub/public/arquiteturas.html` junta esses diagramas numa página.
- `report/exemplos/` captura exemplos reais para os diagramas: `python3 report/exemplos/capturar.py <id>` sobe o app
  contra um gateway local (`GW=http://127.0.0.1:8787`), dispara a receita `report/exemplos/apps/<id>.py` e grava
  `report/exemplos/dados/<id>.json` e o recorte da tela; `python3 report/exemplos/previa.py <id>` desenha o diagrama em
  `scratch/exemplos-run/previa-<id>.png`.
- O gerador que monta todos os SVGs e o `index.json` (`report/build_arquiteturas.py`) **não vem neste pacote**: a lista
  de especificações dele descreve a vitrine inteira (19 apps) e não dá para reduzi-la aos 5 serviços daqui sem
  reescrevê-la. O formato dos arquivos e a especificação completa do gerador estão na seção 2.4 dos prompts da pasta
  “Prompts”.

## Fontes e licenças

Todas as fontes `.woff2` são livres, sob a **SIL Open Font License 1.1** (https://openfontlicense.org), e ficam dentro de
cada app (nenhuma requisição a servidores de fontes): baixadas do **Fontsource** (subconjunto latino) — Fraunces, Public
Sans e DM Mono (hub), Spline Sans e Spline Sans Mono (Planilha), Bricolage Grotesque e Figtree (Busca), Fraunces e
Inter (Site) — e, no Estúdio, 21 famílias baixadas do Google Fonts (lista em `apps/estudio/public/fonts/OFL.txt`).
Cada família pertence aos seus autores.

## O que não vem no pacote

- Segredos (`.secrets/`: a chave do OpenRouter, o login), dados de execução (`data-runtime/`, volumes), logs,
  capturas de teste, `node_modules/` e documentos internos de construção.
- Os outros apps da vitrine e o que só eles usam (o script de intenções do `shared/`, os modelos locais do Mini Cluely).
- O domínio, os IPs e os e-mails da instalação original: tudo que dependia deles virou `<DOMINIO>` ou variável.
