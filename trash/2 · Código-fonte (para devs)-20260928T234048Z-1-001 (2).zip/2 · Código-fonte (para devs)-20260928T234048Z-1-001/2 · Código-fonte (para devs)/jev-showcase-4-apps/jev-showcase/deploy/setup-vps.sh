#!/bin/bash
# Configuração inicial da VPS (Ubuntu 24.04), rodada como root na própria VPS. Idempotente.
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq ca-certificates curl rsync ufw fail2ban htop jq >/dev/null
if ! command -v docker >/dev/null; then curl -fsSL https://get.docker.com | sh >/dev/null; fi
systemctl enable --now docker >/dev/null
docker compose version
# firewall: só SSH, HTTP e HTTPS
ufw --force reset >/dev/null
ufw default deny incoming >/dev/null; ufw default allow outgoing >/dev/null
ufw allow 22/tcp >/dev/null; ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null; ufw allow 443/udp >/dev/null
ufw --force enable >/dev/null
systemctl enable --now fail2ban >/dev/null
# logs do docker com teto
mkdir -p /etc/docker
cat > /etc/docker/daemon.json <<'J'
{ "log-driver": "json-file", "log-opts": { "max-size": "10m", "max-file": "3" } }
J
systemctl restart docker
mkdir -p /etc/jev /opt/jev && chmod 700 /etc/jev
timedatectl set-timezone UTC || true
echo "setup ok: $(docker --version)"
