#!/bin/bash
# Publica o Jev Showcase na VPS. Uso: deploy/deploy.sh [serviço ...]  (sem argumentos = todos)
set -euo pipefail
HOST="${HOST:-root@<DOMINIO>}"  # troque com HOST=usuario@host deploy/deploy.sh
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
node "$ROOT/deploy/gen.mjs"
rsync -az --delete --exclude .secrets --exclude scratch --exclude node_modules --exclude 'test/' --exclude 'data-runtime/' --exclude '.git' "$ROOT/" "$HOST:/opt/jev/"
if [ $# -gt 0 ]; then
  ssh "$HOST" "cd /opt/jev/deploy && docker compose up -d --build $* && { docker compose restart caddy >/dev/null 2>&1 || true; }"  # falha do build sai com erro
else
  ssh "$HOST" "cd /opt/jev/deploy && docker compose up -d --build --remove-orphans"
fi
ssh "$HOST" "cd /opt/jev/deploy && docker compose ps --format 'table {{.Service}}\t{{.State}}\t{{.Status}}'"
