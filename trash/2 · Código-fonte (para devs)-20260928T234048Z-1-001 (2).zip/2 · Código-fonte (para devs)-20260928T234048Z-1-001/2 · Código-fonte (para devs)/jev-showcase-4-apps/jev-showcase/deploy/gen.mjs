// Gera deploy/docker-compose.yml e deploy/Caddyfile a partir de apps.json (só apps que já têm server.mjs).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
// Só vão ao ar os apps aprovados em deploy/ready.json (lista de ids) e que têm server.mjs.
const READY = JSON.parse(fs.readFileSync(path.join(ROOT, 'deploy', 'ready.json'), 'utf8'));
const apps = JSON.parse(fs.readFileSync(path.join(ROOT, 'apps.json'), 'utf8'))
  .filter(a => READY.includes(a.id) && fs.existsSync(path.join(ROOT, 'apps', a.id, 'server.mjs')));
const DOMAIN = '<DOMINIO>';
const limits = { qa: { mem: '1536m', cpus: '2.0' }, cidade: { mem: '384m', cpus: '1.0' }, tron: { mem: '384m', cpus: '1.0' }, cluely: { mem: '768m', cpus: '2.0' } };
let y = `# GERADO por deploy/gen.mjs — não edite à mão\nname: jev\nservices:\n`;
y += `  caddy:\n    image: caddy:2-alpine\n    restart: unless-stopped\n    ports: ["80:80", "443:443"]\n    volumes:\n      - ./Caddyfile:/etc/caddy/Caddyfile:ro\n      - caddy_data:/data\n      - caddy_config:/config\n    depends_on: [auth, ${apps.map(a => 'app-' + a.id).join(', ')}]\n`;
y += `  auth:\n    build: { context: .., dockerfile: deploy/Dockerfile.auth }\n    restart: unless-stopped\n    env_file: /etc/jev/auth.env\n    volumes: [auth_data:/data]\n    mem_limit: 128m\n    cpus: 0.5\n`;
const LLM = fs.existsSync(path.join(ROOT, 'deploy', 'llm.json')) ? JSON.parse(fs.readFileSync(path.join(ROOT, 'deploy', 'llm.json'), 'utf8')) : { enabled: false };
if (LLM.enabled) {
  // Modelo local (recurso extra dos apps de voz). Só na rede interna; 5 de 8 núcleos para não disparar o estrangulamento da Hostinger.
  y += `  llm:\n    image: ghcr.io/ggml-org/llama.cpp:server\n    restart: unless-stopped\n    command: ["-m", "/models/${LLM.file}", "--alias", "${LLM.alias}", "-c", "${LLM.ctx}", "-np", "1", "-t", "${LLM.threads}", "-tb", "8", "--host", "0.0.0.0", "--port", "8080", "--jinja", "--temp", "0.7", "--top-p", "0.8", "--top-k", "20", "--repeat-penalty", "1.05"]\n    volumes: ["/opt/models:/models:ro"]\n    ports: ["127.0.0.1:8088:8080"]\n    cpus: 8.0\n    mem_limit: 24g\n`;
}
if (LLM.fast && LLM.fast.enabled !== false) {
  // Modelo local RÁPIDO (Mini Cluely): 4B denso, flash attention e cache de prompt em RAM para a 1ª palavra sair em <1 s.
  const F = LLM.fast;
  y += `  llm-fast:\n    image: ghcr.io/ggml-org/llama.cpp:server\n    restart: unless-stopped\n    command: ["-m", "/models/${F.file}", "--alias", "${F.alias}", "-c", "${F.ctx}", "-np", "${F.parallel || 1}",${(F.parallel || 1) > 1 ? ' "-kvu",' : ''} "-t", "${F.threads}", "-tb", "8", "-fa", "on", "-cram", "${F.cache_ram || 2048}", "--host", "0.0.0.0", "--port", "8080", "--jinja", "--temp", "0.4", "--top-p", "0.8", "--top-k", "20"]\n    volumes: ["/opt/models:/models:ro"]\n    ports: ["127.0.0.1:${F.host_port || 8089}:8080"]\n    cpus: 8.0\n    mem_limit: ${F.mem || '6g'}\n`;
}
if (LLM.stt && LLM.stt.enabled !== false) {
  // Transcrição robusta (Mini Cluely): whisper.cpp com prompt de contexto (glossário de IA/programação), só na rede interna
  const T = LLM.stt;
  y += `  stt:\n    image: ghcr.io/ggml-org/whisper.cpp:main\n    restart: unless-stopped\n    command: ["/app/build/bin/whisper-server -m /models/${T.model} -l pt -t ${T.threads} -nt --host 0.0.0.0 --port 8080"]\n    volumes: ["/opt/models:/models:ro"]\n    ports: ["127.0.0.1:${T.host_port || 8090}:8080"]\n    cpus: 8.0\n    mem_limit: ${T.mem || '2g'}\n`;
}
y += `  gateway:\n    build: { context: .., dockerfile: deploy/Dockerfile.gateway }\n    restart: unless-stopped\n    env_file: /etc/jev/gateway.env\n    volumes: [gateway_data:/data]\n    mem_limit: 256m\n    cpus: 1.0\n`;
for (const a of apps) {
  const l = limits[a.id] || { mem: '320m', cpus: '1.0' };
  const df = a.dockerfile || 'Dockerfile.app';
  y += `  app-${a.id}:\n    build: { context: .., dockerfile: deploy/${df}, args: { APP: ${a.id} } }\n    restart: unless-stopped\n    env_file: ${a.env_file ? '[/etc/jev/apps.env, ' + a.env_file + ']' : '/etc/jev/apps.env'}\n    environment: { JEV_GATEWAY_URL: "http://gateway:8787", PORT: "3000", DATA_DIR: /data, PUBLIC_URL: "https://${a.sub}.${DOMAIN}"${Object.entries(a.env || {}).map(([k, v]) => `, ${k}: ${JSON.stringify(String(v))}`).join('')} }\n    volumes: [${a.id}_data:/data]\n    depends_on: [gateway]\n    mem_limit: ${l.mem}\n    cpus: ${l.cpus}\n`;
  if (a.id === 'qa') y += `    shm_size: 512m\n    init: true\n`;
}
y += `volumes:\n  caddy_data:\n  caddy_config:\n  gateway_data:\n  auth_data:\n${apps.map(a => `  ${a.id}_data:\n`).join('')}`;
fs.writeFileSync(path.join(ROOT, 'deploy', 'docker-compose.yml'), y);
const HUB = 'jev.' + DOMAIN;
// e-mail opcional da conta no Let's Encrypt (avisos de certificado): ACME_EMAIL=voce@exemplo.com node deploy/gen.mjs
const ACME_EMAIL = (process.env.ACME_EMAIL || '').trim();
let c = `# GERADO por deploy/gen.mjs — não edite à mão
{
${ACME_EMAIL ? `\temail ${ACME_EMAIL}\n` : ''}	servers {
		protocols h1 h2
	}
}

(common) {
	@compress {
		not header Accept *text/event-stream*
		not path /api/*
	}
	encode @compress zstd gzip
	header {
		-Server
		X-Content-Type-Options nosniff
		Referrer-Policy strict-origin-when-cross-origin
		X-Robots-Tag "noindex, nofollow"
	}
	handle /robots.txt {
		respond "User-agent: *
Disallow: /
" 200
	}
	handle /_auth/* {
		reverse_proxy auth:3000
	}
}

(protected) {
	forward_auth auth:3000 {
		uri /verify
		copy_headers X-Jev-User
	}
}

`;
for (const a of apps) {
  const host = `${a.sub}.${DOMAIN}`;
  const up = `app-${a.id}:3000`;
  c += `${host} {\n\timport common\n`;
  if (host === HUB) c += `\thandle /login {\n\t\treverse_proxy auth:3000\n\t}\n\thandle /logout {\n\t\treverse_proxy auth:3000\n\t}\n`;
  c += `\thandle /healthz {\n\t\treverse_proxy ${up}\n\t}\n\thandle {\n\t\timport protected\n\t\treverse_proxy ${up}\n\t}\n}\n\n`;
}
fs.writeFileSync(path.join(ROOT, 'deploy', 'Caddyfile'), c);
console.log(`gerado para ${apps.length} apps: ${apps.map(a => a.id).join(', ')}`);
