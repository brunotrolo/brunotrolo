#!/bin/bash
# Verifica cada domínio publicado: HTTPS 200 na raiz e /healthz ok.
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DOMAIN="${DOMAIN:-<DOMINIO>}"  # troque com DOMAIN=seudominio.com.br
python3 - "$ROOT/apps.json" "$DOMAIN" <<'PY'
import json, sys, subprocess, os
apps = json.load(open(sys.argv[1]))
root = os.path.dirname(sys.argv[1])
domain = sys.argv[2]
falhas = 0
ok = 0
for a in apps:
    if a['id'] not in json.load(open(os.path.join(root, 'deploy', 'ready.json'))):
        print(f"  --  {a['sub']:18s} (sem server.mjs)"); continue
    url = f"https://{a['sub']}.{domain}"
    # raiz protegida por login (302 para o hub); /healthz é público
    code = subprocess.run(['curl', '-s', '-o', '/dev/null', '-w', '%{http_code} %{time_total}', '--max-time', '15', '-H', 'Accept: text/html', url + '/'], capture_output=True, text=True).stdout
    h = subprocess.run(['curl', '-s', '--max-time', '10', url + '/healthz'], capture_output=True, text=True).stdout
    good = code.startswith('302') and '"ok":true' in h
    ok += good
    falhas += not good
    print(f"  {'OK' if good else 'XX'}  {a['sub']:18s} {code:14s} {h[:60]}")
print(f"{ok} domínios ok")
sys.exit(1 if falhas else 0)
PY
