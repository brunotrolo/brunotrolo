#!/bin/bash
# Faz login como usuário e confere que todos os apps prontos abrem (200) com a sessão, e que sem sessão são bloqueados.
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DOMAIN="${DOMAIN:-<DOMINIO>}"  # troque com DOMAIN=seudominio.com.br
EMAIL=$(sed -n 1p "$ROOT/.secrets/jev_login"); PASS=$(sed -n 2p "$ROOT/.secrets/jev_login")
JAR=$(mktemp); trap 'rm -f "$JAR"' EXIT
curl -s -o /dev/null -c "$JAR" -b "$JAR" --data-urlencode "email=$EMAIL" --data-urlencode "password=$PASS" --data-urlencode "next=https://jev.$DOMAIN/" "https://jev.$DOMAIN/login"
python3 - "$ROOT" "$JAR" "$DOMAIN" <<'PY'
import json, os, subprocess, sys
root, jar, domain = sys.argv[1], sys.argv[2], sys.argv[3]
ready = json.load(open(os.path.join(root, 'deploy', 'ready.json')))
apps = [a for a in json.load(open(os.path.join(root, 'apps.json'))) if a['id'] in ready]
ok = 0
for a in apps:
    url = f"https://{a['sub']}.{domain}/"
    anon = subprocess.run(['curl', '-s', '-o', '/dev/null', '-w', '%{http_code}', '-H', 'Accept: text/html', url], capture_output=True, text=True).stdout
    auth = subprocess.run(['curl', '-s', '-L', '-o', '/dev/null', '-w', '%{http_code} %{url_effective}', '-c', jar, '-b', jar, '-H', 'Accept: text/html', url], capture_output=True, text=True).stdout
    good = anon == '302' and auth.startswith('200') and 'login' not in auth.split(' ')[1]
    ok += good
    print(f"  {'OK' if good else 'XX'}  {a['sub']:18s} sem login={anon}  com login={auth}")
print(f"{ok}/{len(apps)} apps protegidos e acessíveis com login")
sys.exit(0 if ok == len(apps) else 1)
PY
