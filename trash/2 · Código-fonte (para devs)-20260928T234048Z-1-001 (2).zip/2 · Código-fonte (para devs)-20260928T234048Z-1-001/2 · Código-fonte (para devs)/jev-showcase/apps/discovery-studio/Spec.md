EU ATUO EM UMA ENGENHARIA DE TECNOLOGIA E QUERO USAR ESTE APP PARA ADAPTAR AOS CENARIOS REAIS DE CERIMONIAS DE DISCOVERY PARA DESENVOLVIMENTO DE UMA MELHORIA OU NOVO FLUXO EM UMA APLICACAO

PRECISO USAR O APP DE DISCOVERY STUDIO PARA:

1 - Desenhar o fluxo funcional da melhoria ou de uma nova jornada que será desenvolvida
2 - Escrever uma user story com base na jornada que foi descrita ou na melhoria e ajuste necessario para a plataforma
3 - Ao inves de prototipar uma pagina, preciso prototipar uma tela, conjunto de telas ou fluxo funcional de uma aplicacao/software
4 - Criar uma lista de criterios de aceite com base na descricao deste fluxo

Este app será utilizado por um Product Owner ou Product Manager para coletar os requisitos e objetivos estratégicos e funcionais para desenvolvimento em uma engenharia de tecnologia/softare




Plano — Discovery Studio para cerimônias de discovery (PO/PM)
Decisões fechadas com você: telas = mockups estilizados navegáveis, fluxo = diagrama + etapas, entrada = voz + texto como hoje, evolução progressiva sem refatoração (cada passo homologável, nada do atual se perde no caminho).
1. O que será o novo app (4 artefatos, 1 por necessidade)
Sua necessidade	Artefato
1. Desenhar o fluxo funcional	Fluxo: diagrama (atores, etapas, decisões/branches, sistemas) + etapas numeradas
2. Escrever a user story	História: Como/Quero/Para + contexto, escopo/fora de escopo
3. Prototipar telas/fluxo funcional	Telas: mockups estilizados clicáveis (navegação entre telas), com ampliar + baixar HTML
4. Critérios de aceite	Critérios: lista Given/When/Then por etapa (feliz, bordas, erros, permissões)
2. Por que é evolução, não rewrite
O motor atual é genérico e continua intacto: voz→texto→estado()→ N chamadas Jev paralelas via gateway (server.mjs, orçamento/limite) → SSE por grupo → montar(ctx) (contexto.mjs) → painéis + fita + Raio-X (automático via META) + versões/projetos (receita {R,…} genérica, sem mudança) + comandos/voz + IA local + downloads + Docker/Caddy/auth/kit. Só trocamos o que o Jev decide (grupos em perguntas.mjs + listas em biblioteca.mjs) e o que cada decisão desenha (4 renderers + 4 painéis no index.html).
3. Passos progressivos (cada um entrega algo testável)
1. Biblioteca discovery — novas listas em biblioteca.mjs (B.FLUXO_*: atores, eventos, gateways de decisão; B.TELAS_*: tipos de tela, componentes, navegação; B.HISTORIA_*: formatos, personas; B.CRITERIOS_*: categorias de cobertura). Zero impacto no rodando.
2. Grupos Jev — GRUPOS/META/PERGUNTAS: entender (adaptar CONTEXTO para produto/sistema em vez de negócio local), fluxo (~20 perguntas), telas (~20), historia (8), criterios (12). Estimativa: ~70 perguntas/pausa (hoje 89) → US$0,0008/pausa, latência similar (0,5 s, paralelo).
3. Painel Fluxo — fluxo.mjs (diagrama + etapas) ocupando um slot de painel; fita e placar passam a ler os novos grupos.
4. Painel Telas — telas.mjs reaproveitando browser/ampliar/baixar; mockups estilizados com paleta neutra fixa (sem discussão de marca).
5. Painel História + IA local — historia.mjs + CAMPOS novos no escritor.mjs (persona, objetivo, escopo, fora de escopo).
6. Painel Critérios — criterios.mjs, cruzando etapas × categorias (feliz/borda/erro/permissão).
7. Router/comandos — ROTA/ALVOS/PAINEL_ALVO para fluxo|telas|historia|criterios; travas por artefato; ajustes livres reaproveitados só para as telas. Nesta fase os 5 painéis marketing saem (já substituídos um a um nos passos 3–6).
8. Fixtures + e2e — trocar os 12 negócios por cenários reais (ex: “checkout com Pix”, “aprovação de reembolso”, “onboarding de lojista”); novo roteiro e2e.py (fala → 4 artefatos coerentes → comando “adiciona etapa de aprovação” → versões).
9. Deploy/docs — registrar discovery-studio em apps.json/ready.json + subdomínio; README do app reescrito para o uso PO/PM.
4. Riscos e travas
- Fala vaga de PO gera fluxo genérico → mitigado com entender forte (sistema, atores, objetivo, restrições) e exemplos-guia nos fixtures.
- Mockup estilizado pode sugerir “layout final” → wireframe com estética neutra fixa + rótulo “protótipo de fluxo, não layout”.
- Custo/latência sob controle via tetos do gateway (já existem).
Critério de aceite do plano: ao fim do passo 8, falar “quero checkout com Pix com aprovação do gerente” gera fluxo com branch de aprovação, 3–5 telas navegáveis, 1 US e ≥6 critérios G/W/T — com e2e verde.