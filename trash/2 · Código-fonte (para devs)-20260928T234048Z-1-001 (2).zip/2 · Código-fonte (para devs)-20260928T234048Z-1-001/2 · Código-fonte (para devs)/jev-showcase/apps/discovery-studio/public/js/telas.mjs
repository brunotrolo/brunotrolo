// Painel Telas: protótipo de telas mockadas e navegável, montado só com as 4 decisões do grupo
// `telas` (tamanho, tipos, componentes, navegação) — mesma regra dos demais painéis: o Jev escolheu
// (argmax ou sorteio do "Outra versão"); aqui a gente só desenha o wireframe e o encadeia.
import * as B from '../lib/biblioteca.mjs';
import { escolha } from './contexto.mjs';
import { esc } from './util.mjs';

const achar = (L, id) => L.find((x) => x.id === id) || L[0];

function decidir(R) {
  return {
    tam: achar(B.TELAS_TAMANHO, escolha(R, {}, 'tamanho')),
    tipo: achar(B.TELAS_TIPOS, escolha(R, {}, 'tipos')),
    comp: achar(B.TELAS_COMPONENTES, escolha(R, {}, 'componentes')),
    nav: achar(B.TELAS_NAVEGACAO, escolha(R, {}, 'navegacao')),
  };
}

// sequência: tela de entrada → telas do tipo principal → tela de conclusão
function sequencia(d) {
  const n = { curto: 3, medio: 5, longo: 7 }[d.tam.id] || 3;
  const naEntrada = ['lista', 'busca', 'dashboard', 'acesso'];
  const entrada = naEntrada.includes(d.tipo.id) ? d.tipo.id : (d.nav.id === 'menu' ? 'dashboard' : 'lista');
  const saida = d.tipo.id === 'confirmacao' ? 'detalhe' : 'confirmacao';
  const tipos = [entrada];
  while (tipos.length < n - 1) tipos.push(d.tipo.id);
  tipos.push(saida);
  return tipos;
}

// ---------------- primitivas do wireframe ----------------
const barra = (w = '70%') => `<i class="tl-ln" style="width:${w}"></i>`;
const campo = (rot, val, erro) => `<div class="tl-campo${erro ? ' is-erro' : ''}"><span class="tl-rot">${esc(rot)}</span><span class="tl-inp">${esc(val)}</span>${erro ? '<em class="tl-aviso">Campo obrigatório</em>' : ''}</div>`;
const ctit = (t, btn) => `<div class="tl-ctit"><b>${esc(t)}</b>${btn ? `<span class="tl-btn">${esc(btn)}</span>` : ''}</div>`;

// ---------------- conteúdo por tipo de tela ----------------
function cLista() {
  const linhas = [['ok', 'Aprovado'], ['warn', 'Em análise'], ['ok', 'Aprovado'], ['err', 'Reprovado']];
  return ctit('Pedidos', 'Novo')
    + `<div class="tl-busca"><span class="tl-inp tl-inp--busca">Buscar por nome ou número</span><span class="tl-chip on">Filtros</span><span class="tl-chip">Este mês</span></div>`
    + `<div class="tl-tbl"><div class="tl-th"><span>Cliente</span><span>Status</span><span>Valor</span><span></span></div>`
    + linhas.map(([st, s]) => `<div class="tl-tr"><span><i class="tl-av"></i>${barra('62%')}</span><span><em class="tl-pir tl-${st}">${s}</em></span><span>${barra('48%')}</span><span class="tl-hd">···</span></div>`).join('')
    + `</div><div class="tl-pag"><b>1</b> 2 3 …8</div>`;
}
function cForm() {
  return ctit('Dados da solicitação')
    + campo('Cliente', 'Ana Beatriz Lima')
    + campo('Valor', 'R$ 1.250,00')
    + campo('Motivo', 'Selecione…', true)
    + `<div class="tl-acoes"><span class="tl-btn2">Voltar</span><span class="tl-btn">Avançar</span></div>`;
}
function cDetalhe() {
  return `<div class="tl-dhead"><i class="tl-av tl-av--g"></i><div class="tl-dnome">${barra('118px')}${barra('76px')}</div><em class="tl-pir tl-warn">Em análise</em><span class="tl-btn2">Aprovar</span></div>`
    + `<div class="tl-abasint"><b>Resumo</b><span>Anexos</span><span>Histórico</span></div>`
    + `<div class="tl-info">${[['Solicitante', 'Ana Beatriz Lima'], ['Setor', 'Financeiro'], ['Data', '12/03'], ['Prazo', '3 dias']].map(([k, v]) => `<div><span>${k}</span><b>${v}</b></div>`).join('')}</div>`
    + `<div class="tl-drop tl-drop--fixo">📎 anexo-solicitacao.pdf · 240 KB</div>`;
}
function cWizard() {
  return `<div class="tl-stepper"><span class="ok">1</span><i></i><span class="on">2</span><i></i><span>3</span></div>`
    + `<div class="tl-passo">Etapa 2 de 3 · Dados</div>`
    + campo('Nome', 'Ana Beatriz Lima')
    + campo('E-mail', 'ana@empresa.com.br')
    + `<div class="tl-acoes"><span class="tl-btn2">Voltar</span><span class="tl-btn">Avançar</span></div>`;
}
function cDash() {
  return ctit('Visão geral')
    + `<div class="tl-kpis">${[['Pendentes', '12'], ['No mês', 'R$ 48k'], ['Prazo méd.', '2,3 d']].map(([k, v]) => `<div class="tl-card"><b>${v}</b><span>${k}</span></div>`).join('')}</div>`
    + `<div class="tl-graf">${[38, 64, 45, 80, 55, 72, 92, 60].map((h) => `<i style="height:${h}%"></i>`).join('')}</div>`
    + `<div class="tl-lista">${[['Reembolso #1042', 'Hoje'], ['Aprovação de férias', 'Ontem'], ['Nota fiscal #883', '12/03']].map(([t, dt]) => `<div><span>${t}</span><em>${dt}</em></div>`).join('')}</div>`;
}
function cConf() {
  return `<div class="tl-ok"><i>✓</i><b>Solicitação enviada</b><span>Nº 1042 · protocolo 88341</span></div>`
    + `<div class="tl-comp">${barra('58%')}${barra('78%')}${barra('44%')}</div>`
    + `<div class="tl-acoes"><span class="tl-btn2">Voltar ao início</span><span class="tl-btn">Ver comprovante</span></div>`;
}
function cAcesso() {
  return `<div class="tl-login"><div class="tl-logo"></div>${campo('E-mail', 'ana@empresa.com.br')}${campo('Senha', '••••••••')}<span class="tl-btn">Entrar</span><span class="tl-ajuda">Esqueci a senha · Ajuda</span></div>`;
}
function cBusca() {
  return `<div class="tl-busca tl-busca--g"><span class="tl-inp tl-inp--busca">reembolso</span><span class="tl-btn">Buscar</span></div>`
    + `<div class="tl-res">${[1, 2, 3].map(() => `<div class="tl-rcard"><i class="tl-av tl-av--g"></i><div>${barra('68%')}${barra('42%')}</div><em class="tl-pir tl-ok">Aprovado</em></div>`).join('')}</div>`
    + `<div class="tl-pag">12 resultados</div>`;
}
const CONTEUDO = {
  lista: cLista, formulario: cForm, detalhe: cDetalhe, wizard: cWizard,
  dashboard: cDash, confirmacao: cConf, acesso: cAcesso, busca: cBusca,
};

// ---------------- componente recorrente escolhido pelo Jev ----------------
function widget(compId) {
  switch (compId) {
    case 'tabela':
      return `<div class="tl-tbl tl-mini"><div class="tl-th"><span>Título</span><span>Status</span></div>${['ok', 'warn', 'ok'].map((st) => `<div class="tl-tr"><span>${barra('66%')}</span><span><em class="tl-pir tl-${st}">${st === 'ok' ? 'Ativo' : 'Rascunho'}</em></span></div>`).join('')}</div>`;
    case 'cards':
      return `<div class="tl-kpis"><div class="tl-card"><b>28</b><span>Em fila</span></div><div class="tl-card"><b>96%</b><span>No prazo</span></div></div>`;
    case 'stepper':
      return `<div class="tl-stepper"><span class="ok">1</span><i></i><span class="on">2</span><i></i><span>3</span></div>`;
    case 'upload':
      return `<div class="tl-drop">＋ Arraste os arquivos aqui ou clique para enviar</div>`;
    case 'timeline':
      return `<div class="tl-time"><div><i></i><span>Solicitação criada · 09:12</span></div><div><i></i><span>Enviado ao gestor · 09:13</span></div><div><i></i><span>Aguardando aprovação</span></div></div>`;
    case 'filtros':
      return `<div class="tl-filtros"><span class="tl-chip on">Urgente</span><span class="tl-chip">Este mês</span><span class="tl-chip">Financeiro</span></div>`;
    case 'vazio':
      return `<div class="tl-vazio"><i></i>${barra('42%')}${barra('64%')}<span class="tl-btn2">Criar o primeiro</span></div>`;
    default:
      return '';
  }
}
// o componente que o próprio tipo de tela já desenha não é repetido
const pula = (tipoId, compId) =>
  (compId === 'tabela' && tipoId === 'lista') || (compId === 'stepper' && tipoId === 'wizard')
  || (compId === 'cards' && tipoId === 'dashboard') || (compId === 'filtros' && (tipoId === 'lista' || tipoId === 'busca'));

// ---------------- uma tela (chrome + app + legenda) ----------------
const DIALOGO = `<div class="tl-dialog"><b>Confirmar ação</b><p>Confira os dados antes de seguir. Esta ação não pode ser desfeita.</p><div class="tl-dlg-acoes"><span class="tl-btn2" data-tel-fecha>Cancelar</span><span class="tl-btn" data-tel-fecha>Confirmar</span></div></div>`;

function wrapHTML(seq, i, d) {
  const tipoId = seq[i], n = seq.length;
  const tipo = achar(B.TELAS_TIPOS, tipoId);
  const meio = i > 0 && i < n - 1;
  let corpo = (CONTEUDO[tipoId] || cLista)();
  if (!pula(tipoId, d.comp.id)) corpo += widget(d.comp.id);
  if (d.nav.id === 'modal') corpo = corpo.replace(/class="tl-btn"/g, 'class="tl-btn" data-tel-modal');
  const menu = d.nav.id === 'menu'
    ? `<aside class="tl-menu">${seq.map((t, j) => `<button type="button" class="tl-mi" data-tel-ir="${j}">${j + 1} · ${esc(achar(B.TELAS_TIPOS, t).rotulo)}</button>`).join('')}<span class="tl-mi off">Configurações</span></aside>`
    : '';
  const scrimFixo = d.comp.id === 'modal' && meio ? `<div class="tl-scrim">${DIALOGO}</div>` : '';
  return `<div class="tl-tela-wrap" data-tel="${i}">
    <div class="tl-chrome"><span class="tl-pontos"><i></i><i></i><i></i></span><span class="tl-url">${esc(tipoId)}/tela-${i + 1}-de-${n}</span></div>
    <div class="tl-app">${menu}<div class="tl-corpo">${corpo}</div>${scrimFixo}</div>
    <footer class="tl-legenda"><b>${i + 1} · ${esc(tipo.rotulo)}</b>${i === 0 ? '<em class="tl-tag">entrada</em>' : i === n - 1 ? '<em class="tl-tag">saída</em>' : ''}<span>${esc(tipo.jev)}</span></footer>
  </div>`;
}

// barra de navegação acima do protótipo: setas + abas (ou só números no linear; escondida no menu lateral)
function ferramenta(seq, navId) {
  const abas = seq.map((t, i) => {
    const r = achar(B.TELAS_TIPOS, t).rotulo;
    return `<button type="button" class="tl-aba" data-tel-ir="${i}" title="${esc(r)}"><b>${i + 1}</b><span>${esc(r)}</span></button>`;
  }).join('');
  return `<div class="tl-ferramenta" data-nav="${navId}">
    <button type="button" class="tl-seta" data-tel-dir="-1" aria-label="Tela anterior">‹</button>
    <div class="tl-abas">${abas}</div>
    <button type="button" class="tl-seta" data-tel-dir="1" aria-label="Próxima tela">›</button>
    <span class="tl-cont">1/${seq.length}</span>
  </div>`;
}
const chip = (i, v) => `<span class="fx-chip"><i>${i}</i><b>${esc(v)}</b></span>`;

// ---------------- corpo do painel (e versão ampliada) ----------------
export function telasPainelHTML(R, amp = false) {
  const d = decidir(R);
  const seq = sequencia(d);
  return `<div class="fx-topo">${chip('Tamanho', d.tam.rotulo)}${chip('Tipo', d.tipo.rotulo)}${chip('Componente', d.comp.rotulo)}${chip('Navegação', d.nav.rotulo)}</div>
    ${ferramenta(seq, d.nav.id)}
    <div class="tl-telas${amp ? ' tl--amp' : ''}">
      ${seq.map((_, i) => wrapHTML(seq, i, d)).join('')}
      <div class="tl-scrim tl-modal" hidden>${DIALOGO}</div>
    </div>`;
}

// rótulo curto para o cabeçalho do painel (lat-telas)
export function telasResumo(R) {
  const d = decidir(R);
  return `${esc(d.tam.rotulo.toLowerCase())} · ${esc(d.nav.rotulo.toLowerCase())}`;
}

// ---------------- exportação: um HTML autocontido com todas as telas (storyboard) ----------------
// o CSS vai junto colhido das folhas da própria página — não há cópia para manter em sincronia.
function cssTelas() {
  let out = '';
  for (const sh of document.styleSheets) {
    try {
      for (const r of sh.cssRules) {
        const t = r.cssText || '';
        const sel = t.slice(0, t.indexOf('{') < 0 ? t.length : t.indexOf('{'));
        if (/\.(tl-|fx-chip|fx-topo)/.test(sel)) out += t + '\n';
      }
    } catch { /* folha cross-origin: ignora */ }
  }
  return out;
}

export function telasExportavel(R) {
  const d = decidir(R);
  const seq = sequencia(d);
  const telas = seq.map((_, i) => wrapHTML(seq, i, d)).join('\n');
  const chips = [chip('Tamanho', d.tam.rotulo), chip('Tipo', d.tipo.rotulo), chip('Componente', d.comp.rotulo), chip('Navegação', d.nav.rotulo)].join('');
  return `<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Telas · protótipo navegável</title>
<style>
:root{--font:"Instrument Sans","Helvetica Neue",Arial,sans-serif}
body{margin:0;background:#f6f5f4;color:#000;font-family:var(--font)}
.tl-export{max-width:980px;margin:26px auto;padding:0 18px 40px;display:flex;flex-direction:column;gap:26px}
.tl-export h1{font:700 17px/1.3 inherit;margin:0 0 10px}
.tl-export .fx-topo{margin-bottom:4px}
.tl-export .tl-tela-wrap{display:flex}
.tl-export .tl-secaoh{display:flex;align-items:center;gap:8px;margin:0 0 8px;font:700 13px/1.2 inherit}
.tl-export .tl-secaoh em{font:700 9px/1 inherit;font-style:normal;letter-spacing:.07em;text-transform:uppercase;color:#0075de;background:rgba(0,117,222,.08);border-radius:999px;padding:3px 7px}
.tl-export .tl-legenda{display:none}
${cssTelas()}
</style></head>
<body><main class="tl-export">
<h1>Protótipo de telas · ${seq.length} telas</h1>
<div class="fx-topo">${chips}</div>
${seq.map((t, i) => {
  const tipo = achar(B.TELAS_TIPOS, t);
  return `<h2 class="tl-secaoh">${i + 1} · ${esc(tipo.rotulo)}${i === 0 ? ' <em>entrada</em>' : i === seq.length - 1 ? ' <em>saída</em>' : ''}</h2>${wrapHTML(seq, i, d)}`;
}).join('\n')}
</main></body></html>`;
}

// ---------------- navegação (delegação; o índice fica no contêiner, como as abas do e-mail) ----------------
function aplicarTelas(raiz) {
  const wraps = raiz.querySelectorAll('.tl-tela-wrap');
  const n = wraps.length;
  if (!n) return;
  let i = parseInt(raiz.dataset.tel || '0', 10);
  if (!Number.isFinite(i)) i = 0;
  i = Math.max(0, Math.min(n - 1, i));
  raiz.dataset.tel = String(i);
  wraps.forEach((w) => w.classList.toggle('ativa', Number(w.dataset.tel) === i));
  raiz.querySelectorAll('.tl-aba').forEach((b, j) => b.classList.toggle('ativa', j === i));
  raiz.querySelectorAll('.tl-menu .tl-mi[data-tel-ir]').forEach((b) => b.classList.toggle('on', Number(b.dataset.telIr) === i));
  const c = raiz.querySelector('.tl-cont');
  if (c) c.textContent = `${i + 1}/${n}`;
}

export function ativarTelas(raiz) {
  if (!raiz || !raiz.querySelectorAll) return;
  if (!raiz.__tl) {
    raiz.__tl = true;
    raiz.addEventListener('click', (ev) => {
      const t = ev.target.closest && ev.target.closest('[data-tel-ir],[data-tel-dir],[data-tel-modal],[data-tel-fecha]');
      if (!t || !raiz.contains(t)) return;
      if (t.hasAttribute('data-tel-fecha')) { const s = t.closest('.tl-scrim'); if (s) s.hidden = true; return; }
      if (t.hasAttribute('data-tel-modal')) { const m = raiz.querySelector('.tl-modal'); if (m) m.hidden = false; return; }
      const n = raiz.querySelectorAll('.tl-tela-wrap').length;
      if (!n) return;
      let i = parseInt(raiz.dataset.tel || '0', 10) || 0;
      if (t.hasAttribute('data-tel-dir')) i += Number(t.dataset.telDir);
      else i = parseInt(t.dataset.telIr, 10);
      raiz.dataset.tel = String(Math.max(0, Math.min(n - 1, i)));
      aplicarTelas(raiz);
    });
  }
  aplicarTelas(raiz);
}
