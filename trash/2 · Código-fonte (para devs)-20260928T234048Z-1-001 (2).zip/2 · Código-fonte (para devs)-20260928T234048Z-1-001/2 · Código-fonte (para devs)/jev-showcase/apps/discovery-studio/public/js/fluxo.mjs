// Painel Fluxo: diagrama SVG (gatilho → ator → decisão → sistemas → resultado) + etapas numeradas.
// Só lê as 6 decisões do grupo `fluxo` (biblioteca FLUXO_*). Nenhuma regra "palavra → opção" aqui: o Jev escolheu.
import * as B from '../lib/biblioteca.mjs';
import { escolha } from './contexto.mjs';
import { esc } from './util.mjs';

const achar = (L, id) => L.find((x) => x.id === id) || L[0];

// quebra o rótulo em até `n` linhas de `max` caracteres (guloso, com reticências)
function quebrar(txt, max = 18, n = 2) {
  const palavras = String(txt || '').split(/\s+/);
  const linhas = []; let cur = '';
  for (const p of palavras) {
    if (!cur) { cur = p; continue; }
    if ((cur + ' ' + p).length <= max) cur += ' ' + p;
    else { linhas.push(cur); cur = p; if (linhas.length === n) break; }
  }
  if (linhas.length < n && cur) linhas.push(cur);
  if (linhas.length === n) {
    const resto = palavras.join(' ');
    const fim = linhas.join(' ').length;
    if (resto.length > fim) linhas[n - 1] = linhas[n - 1].replace(/\s*\S*$/, '') + '…';
  }
  return linhas.slice(0, n);
}

function decidir(R) {
  return {
    tipo: achar(B.FLUXO_TIPO, escolha(R, {}, 'tipo')),
    ator: achar(B.FLUXO_ATORES, escolha(R, {}, 'atores')),
    gat: achar(B.FLUXO_GATILHOS, escolha(R, {}, 'gatilhos')),
    dec: achar(B.FLUXO_DECISOES, escolha(R, {}, 'decisoes')),
    sis: achar(B.FLUXO_SISTEMAS, escolha(R, {}, 'sistemas')),
    res: achar(B.FLUXO_RESULTADOS, escolha(R, {}, 'resultados')),
  };
}

// ---------------- diagrama ----------------
function diagramaSVG(d) {
  const nos = [
    { forma: 'pill', topo: 'GATILHO', rot: d.gat.rotulo },
    { forma: 'caixa', topo: 'ATOR', rot: d.ator.rotulo },
    d.dec.id === 'linear'
      ? { forma: 'caixa', topo: 'PERCURSO', rot: 'Linear, sem decisão' }
      : { forma: 'diamante', topo: 'DECISÃO', rot: d.dec.rotulo },
  ];
  if (d.sis.id !== 'app_proprio') nos.push({ forma: 'caixa', topo: 'SISTEMA', rot: d.sis.rotulo });
  nos.push({ forma: 'pill', topo: 'RESULTADO', rot: d.res.rotulo });

  const ALT = 116, Y = 14, GAP = 52, MARGEM = 8;
  const RAMO = d.dec.id === 'aprovacao';
  const H = Y + ALT + (RAMO ? 60 : 12); // folga de baixo: o ramo de reprovação ocupa ~60px a mais
  let x = MARGEM; const pos = [];
  for (const n of nos) { const w = n.forma === 'diamante' ? 156 : 164; pos.push({ x, w, n }); x += w + GAP; }
  const W = Math.max(720, x - GAP + MARGEM);
  const cx = (i) => pos[i].x + pos[i].w / 2;
  let s = `<defs><marker id="fx-seta" viewBox="0 0 10 10" refX="8.5" refY="5" markerWidth="6.5" markerHeight="6.5" orient="auto"><path d="M0 0 10 5 0 10z" fill="#615d59"/></marker></defs><svg class="fx-svg" viewBox="0 0 ${W} ${H}" role="img" aria-label="Diagrama do fluxo funcional">`;

  // setas entre nós
  for (let i = 0; i < pos.length - 1; i++) {
    const x1 = pos[i].x + pos[i].w, x2 = pos[i + 1].x, cy = Y + ALT / 2;
    const rot = d.dec.id === 'aprovacao' && pos[i].n.forma === 'diamante' ? '✓ aprova' : '';
    s += `<line x1="${x1 + 3}" y1="${cy}" x2="${x2 - 6}" y2="${cy}" stroke="#615d59" stroke-width="1.6" marker-end="url(#fx-seta)"/>`;
    if (rot) s += `<text x="${(x1 + x2) / 2}" y="${cy - 9}" class="fx-rot" text-anchor="middle">${rot}</text>`;
  }
  // ramo de reprovação (só quando há aprovação humana)
  if (d.dec.id === 'aprovacao') {
    const di = pos.findIndex((p) => p.n.forma === 'diamante');
    const al = pos.findIndex((p) => p.n.forma === 'caixa' && p.n.topo === 'ATOR');
    if (di > 0 && al >= 0) {
      const dx = cx(di), dy = Y + ALT, ax = cx(al), ay = Y + ALT, bY = Y + ALT + 26;
      s += `<path d="M${dx} ${dy} Q${(dx + ax) / 2} ${bY + 14} ${ax} ${ay + 4}" fill="none" stroke="#a39e98" stroke-width="1.4" stroke-dasharray="5 4" marker-end="url(#fx-seta)"/>`;
      s += `<text x="${(dx + ax) / 2}" y="${bY + 30}" class="fx-rot fx-rot--dev" text-anchor="middle">✗ reprova · devolve ao ator</text>`;
    }
  }

  // nós
  pos.forEach(({ x, w, n }) => {
    const cy = Y + ALT / 2;
    if (n.forma === 'diamante') {
      const m = 10;
      s += `<polygon points="${x + w / 2},${Y + m} ${x + w - m},${cy} ${x + w / 2},${Y + ALT - m} ${x + m},${cy}" fill="#fff" stroke="#1B1B1B" stroke-width="1.6"/>`;
    } else if (n.forma === 'pill') {
      s += `<rect x="${x}" y="${Y}" width="${w}" height="${ALT}" rx="${ALT / 2}" fill="#000" stroke="#000"/>`;
    } else {
      s += `<rect x="${x}" y="${Y}" width="${w}" height="${ALT}" rx="10" fill="#fff" stroke="#d0cfcb" stroke-width="1.5"/>`;
    }
    const corTopo = n.forma === 'pill' ? '#a39e98' : '#615d59';
    const corRot = n.forma === 'pill' ? '#fff' : '#000';
    const linhas = quebrar(n.rot, 17, 2);
    const yTopo = cy - (linhas.length > 1 ? 20 : 13);
    s += `<text x="${x + w / 2}" y="${yTopo}" class="fx-topo" fill="${corTopo}" text-anchor="middle">${esc(n.topo)}</text>`;
    linhas.forEach((l, i) => {
      s += `<text x="${x + w / 2}" y="${yTopo + 18 + i * 17}" class="fx-rotulo" fill="${corRot}" text-anchor="middle">${esc(l)}</text>`;
    });
  });
  return s + '</svg>';
}

// ---------------- etapas numeradas ----------------
function etapasHTML(d) {
  const passos = [
    ['Gatilho', d.gat.jev, 'início'],
    ['Atores', d.ator.jev, 'quem executa'],
  ];
  if (d.dec.id !== 'linear') passos.push(['Decisão', d.dec.jev, 'bifurcação']);
  if (d.sis.id !== 'app_proprio') passos.push(['Integração', d.sis.jev, 'externo']);
  passos.push(['Resultado', d.res.jev, 'fim']);
  return `<ol class="fx-etapas">${passos.map(([t, d2, tag], i) =>
    `<li class="fx-etapa"><span class="fx-num">${i + 1}</span><div><b>${esc(t)}</b><span class="fx-tag">${esc(tag)}</span><p>${esc(d2)}</p></div></li>`).join('')}</ol>`;
}

// ---------------- corpo do painel ----------------
// Zona fixa (chips + diagrama) fica sempre visível; só as etapas rolam.
export function fluxoPainelHTML(R) {
  const d = decidir(R);
  return `<div class="fx-fixo">
      <div class="fx-topo">
        <span class="fx-chip"><i>Tipo</i><b>${esc(d.tipo.rotulo)}</b></span>
        <span class="fx-chip"><i>Decisão</i><b>${esc(d.dec.rotulo)}</b></span>
        <span class="fx-chip"><i>Resultado</i><b>${esc(d.res.rotulo)}</b></span>
      </div>
      <div class="fx-diag">${diagramaSVG(d)}</div>
    </div>
    <div class="fx-rolo">${etapasHTML(d)}</div>`;
}

// rótulo curto para o cabeçalho do painel (lat-fluxo)
export function fluxoResumo(R) {
  const d = decidir(R);
  return `${esc(d.tipo.rotulo.toLowerCase())} · ${esc(d.dec.rotulo.toLowerCase())}`;
}
