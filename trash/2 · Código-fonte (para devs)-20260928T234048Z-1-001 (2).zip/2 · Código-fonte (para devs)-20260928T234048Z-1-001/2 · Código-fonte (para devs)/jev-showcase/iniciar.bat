@echo off
rem ---------------------------------------------------------------------------
rem  iniciar.bat - Jev Showcase: sobe o gateway + um app e abre no navegador.
rem    iniciar.bat                  pergunta o nome do app na tela
rem    iniciar.bat busca            sobe direto (tambem: discovery-studio, ...)
rem    iniciar.bat status           mostra o que esta rodando
rem    iniciar.bat parar            para tudo do showcase
rem ---------------------------------------------------------------------------
setlocal
chcp 65001 >nul 2>nul
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js nao encontrado. Instale em https://nodejs.org e tente de novo.
  pause
  exit /b 1
)

node "%~dp0iniciar.mjs" %*
set "ERRO=%errorlevel%"

if not "%~1"=="" exit /b %ERRO%
echo.
pause
exit /b %ERRO%
