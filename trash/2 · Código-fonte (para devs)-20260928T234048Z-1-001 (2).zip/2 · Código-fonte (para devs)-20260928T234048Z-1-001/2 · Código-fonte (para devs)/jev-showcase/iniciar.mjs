// ---------------------------------------------------------------------------
// iniciar.mjs — Jev Showcase: sobe o gateway + um app e abre no navegador.
//   node iniciar.mjs                    pergunta o nome do app na tela
//   node iniciar.mjs busca              sobe direto
//   node iniciar.mjs status             mostra o que está rodando
//   node iniciar.mjs parar              para tudo do showcase (portas conhecidas)
//   ... --sem-navegador                 não abre o navegador (útil em teste)
// Cada servidor fica na sua janela (cmd /k): fechar essa janela derruba só ele.
// ---------------------------------------------------------------------------
import { spawn, execSync } from 'node:child_process';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import path from 'node:path';
import readline from 'node:readline/promises';
import { fileURLToPath } from 'node:url';

const RAIZ = path.dirname(fileURLToPath(import.meta.url));
const GATEWAY = 8787;
const CHAVE = path.join(RAIZ, '.secrets', 'openrouter_key');
const win = process.platform === 'win32';
const SEM_NAV = process.argv.includes('--sem-navegador');

// id → porta padrão (apps.json manda; discovery-studio é o clone novo na 4116)
const APPS = {};
try {
  for (const a of JSON.parse(readFileSync(path.join(RAIZ, 'apps.json'), 'utf8'))) APPS[a.id] = a.port;
} catch {}
APPS['discovery-studio'] = APPS['discovery-studio'] || 4116;
const ALIAS = { ds: 'discovery-studio', discovery: 'discovery-studio', studio: 'discovery-studio', est: 'estudio', indice: 'hub', idx: 'hub' };

const dormir = (ms) => new Promise((r) => setTimeout(r, ms));

// portas dinâmicas (app que caiu numa porta alternativa) — o "parar" precisa delas
const ESTADO = path.join(RAIZ, '.iniciar.json');
function lerEstado() { try { return JSON.parse(readFileSync(ESTADO, 'utf8')); } catch { return { dinamicas: [] }; } }
function gravarDinamica(porta) {
  const e = lerEstado();
  if (!e.dinamicas.includes(porta)) e.dinamicas.push(porta);
  try { writeFileSync(ESTADO, JSON.stringify(e)); } catch {}
}

async function healthz(porta, ms = 800) {
  try {
    const c = new AbortController();
    const t = setTimeout(() => c.abort(), ms);
    const r = await fetch(`http://127.0.0.1:${porta}/healthz`, { signal: c.signal });
    clearTimeout(t);
    if (!r.ok) return null;
    return await r.json();
  } catch { return null; }
}

// janela de console própria; o servidor continua vivo depois que este script sai
function janela(titulo, comando, env = {}) {
  const linha = win ? `start "${titulo.replace(/"/g, '')}" cmd /k ${comando}` : comando;
  const p = spawn(win ? 'cmd' : 'sh', win ? ['/c', linha] : ['-c', linha], {
    cwd: RAIZ, env: { ...process.env, ...env },
    detached: true, stdio: 'ignore', windowsHide: false,
    windowsVerbatimArguments: win,
  });
  p.unref();
}

function abrirNavegador(url) {
  if (SEM_NAV) return;
  const p = spawn(win ? 'cmd' : 'xdg-open', win ? ['/c', `start "" ${url}`] : [url], {
    detached: true, stdio: 'ignore', windowsHide: false,
    windowsVerbatimArguments: win,
  });
  p.unref();
}

async function subirGateway() {
  const h = await healthz(GATEWAY);
  if (h) return h;
  if (!existsSync(CHAVE)) console.log(`atencao: chave nao encontrada em ${CHAVE} — o gateway sobe sem chave.`);
  console.log(`▶ subindo o gateway (${GATEWAY})…`);
  janela('Jev gateway', 'node gateway/server.mjs', { OPENROUTER_KEY_FILE: CHAVE });
  for (let i = 0; i < 25; i++) {
    await dormir(400);
    const g = await healthz(GATEWAY, 600);
    if (g) return g;
  }
  return null;
}

// primeira porta livre a partir de `base`, sem sobrepor a porta padrão de outro app
async function acharLivre(base) {
  const usadas = new Set([...Object.values(APPS), GATEWAY]);
  for (let p = base; p < base + 30; p++) {
    if (usadas.has(p)) continue;
    if (!(await healthz(p, 500))) return p;
  }
  return 0;
}

async function startId(id, porta) {
  if (porta !== APPS[id]) gravarDinamica(porta);
  const gw = await subirGateway();
  if (!gw) console.log('atencao: gateway nao respondeu; o app sobe, mas as decisoes do Jev vao falhar.');
  console.log(`▶ subindo ${id} em ${porta}…`);
  janela(`Jev ${id}`, `node apps/${id}/server.mjs`, { PORT: String(porta) });
  for (let i = 0; i < 30; i++) {
    await dormir(400);
    const h = await healthz(porta, 600);
    if (h) {
      console.log(`✓ ${id} no ar → http://localhost:${porta}/`);
      abrirNavegador(`http://localhost:${porta}/`);
      return;
    }
  }
  console.log(`✗ ${id} não respondeu em ~12 s — veja a janela "Jev ${id}".`);
}

async function subirApp(id) {
  const porta = APPS[id];
  const atual = await healthz(porta);
  if (atual) {
    if (atual.app === id) {
      console.log(`✓ ${id} já está rodando em ${porta}.`);
      abrirNavegador(`http://localhost:${porta}/`);
      return;
    }
    const alvo = await acharLivre(porta);
    if (!alvo) return console.log(`✗ a porta ${porta} está ocupada por ${atual.app} e não achei outra livre.`);
    console.log(`porta ${porta} está com ${atual.app} → ${id} vai para ${alvo}.`);
    return startId(id, alvo);
  }
  return startId(id, porta);
}

async function status() {
  const gw = await healthz(GATEWAY);
  console.log(gw ? `✓ gateway    ${GATEWAY}  modelo=${gw.model}` : `✗ gateway    ${GATEWAY}  parado`);
  const feitos = new Set();
  for (const [id, porta] of Object.entries(APPS)) {
    if (feitos.has(porta)) continue;
    feitos.add(porta);
    const h = await healthz(porta);
    if (!h) console.log(`✗ ${id.padEnd(17)} ${porta}  parado`);
    else console.log(`✓ ${id.padEnd(17)} ${porta}  rodando${h.app && h.app !== id ? ` (é ${h.app})` : ''}`);
  }
  for (const p of lerEstado().dinamicas) {
    if (feitos.has(p)) continue;
    const h = await healthz(p);
    console.log(`${h ? '✓' : '✗'} ${String(h?.app || '?').padEnd(17)} ${p}  ${h ? 'rodando (porta alternativa)' : 'parado'}`);
  }
}

function pidsNaPorta(p) {
  if (win) {
    const saida = execSync(`netstat -ano | findstr LISTENING | findstr ":${p} "`, {
      encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'],
    });
    return saida.split(/\r?\n/)
      .map((l) => l.trim().split(/\s+/).pop())
      .filter((x) => /^\d+$/.test(x));
  }
  return execSync(`lsof -ti :${p} || true`, { encoding: 'utf8' })
    .split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
}

async function parar() {
  const portas = [...new Set([GATEWAY, ...Object.values(APPS), ...lerEstado().dinamicas])];
  let n = 0;
  for (const p of portas) {
    if (!(await healthz(p, 400))) continue; // se não responde healthz, não é servidor nosso
    let pids = [];
    try { pids = pidsNaPorta(p); } catch { continue; }
    for (const pid of new Set(pids)) {
      if (+pid === process.pid) continue;
      try { execSync(win ? `taskkill /f /pid ${pid}` : `kill -9 ${pid}`, { stdio: 'ignore' }); n++; } catch {}
    }
    await dormir(150);
  }
  // fecha as janelas de console que sobraram (só o cmd; o node já foi morto acima)
  if (win) {
    try { execSync('taskkill /f /fi "WINDOWTITLE eq Jev*"', { stdio: 'ignore' }); } catch {}
  }
  try { writeFileSync(ESTADO, JSON.stringify({ dinamicas: [] })); } catch {}
  console.log(n ? `■ ${n} servidor(es) parado(s).` : '■ nada estava rodando.');
}

async function menu() {
  const ids = Object.keys(APPS);
  console.log('Jev Showcase — qual app quer abrir?\n');
  ids.forEach((id, i) => console.log(`  ${i + 1}. ${id.padEnd(17)} porta ${APPS[id]}`));
  console.log('\n  s. status    p. parar tudo\n');
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  // stdin fechado (EOF) não pode deixar a promise pendente: resolve vazio
  const r = await Promise.race([
    rl.question('> ').then((s) => s.trim().toLowerCase()),
    new Promise((res) => rl.once('close', () => res(''))),
  ]);
  rl.close();
  if (!r) return;
  if (r === 's' || r === 'status') return status();
  if (r === 'p' || r === 'parar') return parar();
  const n = Number(r);
  const id = n >= 1 && n <= ids.length ? ids[n - 1] : (ALIAS[r] || r);
  if (!APPS[id]) return console.log(`✗ não conheço "${r}". Nomes: ${ids.join(', ')}.`);
  await subirApp(id);
}

const arg = process.argv.slice(2).find((a) => !a.startsWith('--')) || '';
const cmd = arg.toLowerCase();
if (cmd === 'status') await status();
else if (cmd === 'parar' || cmd === 'stop') await parar();
else if (cmd === 'help' || cmd === 'h') console.log(`uso: iniciar.bat [app|status|parar]\napps: ${Object.keys(APPS).join(', ')}`);
else if (cmd) {
  const id = ALIAS[cmd] || cmd;
  if (!APPS[id]) console.log(`✗ não conheço "${cmd}". Nomes: ${Object.keys(APPS).join(', ')}.`);
  else await subirApp(id);
} else await menu();

// sai sozinho (sem process.exit: evita a assertion do libuv no Windows);
// se alguma coisa segurar o event loop por mais de 2 s, aí força a saída.
const t = setTimeout(() => process.exit(0), 2000);
t.unref();
