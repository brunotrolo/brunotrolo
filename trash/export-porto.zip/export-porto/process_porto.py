import os
import json
import zipfile
import logging
import re
import base64
import requests
import time
from bs4 import BeautifulSoup
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Helper to get numeric or null env vars
def get_env_id(key, default=None):
    val = os.getenv(key)
    if val is None:
        return default
    if val.lower() == 'null':
        return None
    if val == '':
        return ""
    try:
        return int(val)
    except ValueError:
        return val # Return as string if not int (like empty string)

# Constants for the output JSON (now from ENV)
CATEGORY_ID = get_env_id("EXPORT_CATEGORY_ID", 4)
COVER_ID = get_env_id("EXPORT_COVER_ID")
STATUS = os.getenv("EXPORT_STATUS", "true").lower() == "true"
EDITION_MODE = os.getenv("EXPORT_EDITION_MODE", "true").lower() == "true"
SHARE_MOBILE = os.getenv("EXPORT_SHARE_MOBILE", "true").lower() == "true"
PERMISSION_DOWNLOAD = os.getenv("EXPORT_PERMISSION_DOWNLOAD", "true").lower() == "true"
SHOW_RELATIONS = os.getenv("EXPORT_SHOW_RELATIONS", "true").lower() == "true"
GROUPS_ID = json.loads(os.getenv("EXPORT_GROUPS_ID", "[1]"))
COLOR_DEFAULT = os.getenv("COLOR_DEFAULT", "default")

# API Configuration (now from ENV)
LOGIN_URL = os.getenv("BEEDOO_LOGIN_URL", "https://apiz.beedoo.io/beehub/v1/user/accessToken")
ARTICLE_URL = os.getenv("BEEDOO_ARTICLE_URL", "https://apiz.beedoo.io/admin/api/v1/wiki/articles")
CLIENT_ID = os.getenv("BEEDOO_CLIENT_ID")
CLIENT_SECRET = os.getenv("BEEDOO_CLIENT_SECRET")

# Logging Configuration (now from ENV)
PROCESS_LOG_FILE = os.getenv("PROCESS_LOG_FILE", "process_porto.log")
API_LOG_FILE = os.getenv("API_LOG_FILE", "api_responses.log")

# Setup Process Logger
logging.basicConfig(
    filename=PROCESS_LOG_FILE,
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Setup API Logger
api_logger = logging.getLogger('api_logger')
api_handler = logging.FileHandler(API_LOG_FILE)
api_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
api_logger.addHandler(api_handler)
api_logger.setLevel(logging.INFO)
api_logger.propagate = False

def get_base64_auth(client_id, client_secret):
    """Encodes credentials for Basic Auth."""
    auth_str = f"{client_id}:{client_secret}"
    encoded_bytes = base64.b64encode(auth_str.encode('utf-8'))
    return encoded_bytes.decode('utf-8')

def get_auth_token():
    """Authenticates with the API and returns the access token."""
    # New format: Authorization: Basic <CLIENT_SECRET>
    # And clientId as query param
    # Based on working curl: curl --location 'URL?clientId=...' --header 'Authorization: Basic <SECRET>'
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Basic {CLIENT_SECRET}"
    }
    params = {
        "clientId": CLIENT_ID
    }
    
    try:
        api_logger.info(f"Attempting login to {LOGIN_URL} with clientId {CLIENT_ID}")
        # The working curl is a GET request
        response = requests.get(LOGIN_URL, headers=headers, params=params)
        
        # Log response
        api_logger.info(f"Login Response Status: {response.status_code}")
        api_logger.info(f"Login Response Body: {response.text}")
        
        response.raise_for_status()
        result = response.json()
        
        # New structure: {"status":"success","data":[{"type":"accessToken","attributes":{"token":"..."}}]}
        token = None
        if result.get('status') == 'success' and 'data' in result:
            data_list = result['data']
            if len(data_list) > 0:
                attributes = data_list[0].get('attributes', {})
                token = attributes.get('token')
        
        # Fallback to old structures just in case
        if not token:
            token = result.get('access_token') or result.get('token')
            if not token and 'data' in result and isinstance(result['data'], dict):
                token = result['data'].get('token') or result['data'].get('access_token')
            
        if not token:
            api_logger.error("Token not found in login response.")
            return None
            
        return token
    except Exception as e:
        api_logger.error(f"Error during authentication: {e}")
        return None

def create_article(token, payload, zip_filename):
    """Sends the JSON payload to create an article in the API."""
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}",
        "User-Agent": "Insomnia/2023.5.1"
    }
    
    try:
        api_logger.info(f"Sending article creation request for {zip_filename}")
        response = requests.post(ARTICLE_URL, headers=headers, json=payload)
        
        # Log response
        api_logger.info(f"Article API Response for {zip_filename}: Status {response.status_code}")
        api_logger.info(f"Article API Response Body for {zip_filename}: {response.text}")
        
        return response.status_code, response.text
    except Exception as e:
        api_logger.error(f"Error sending article for {zip_filename}: {e}")
        return None, str(e)

def get_title_map(json_path):
    """Reads title.json and returns a mapping from filename to title content."""
    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            mapping = {}
            for item in data:
                file_name = item.get('Arquivo')
                title = item.get('Conteúdo')
                if file_name and title:
                    mapping[file_name] = title
                    mapping[os.path.splitext(file_name)[0]] = title
            return mapping
    except Exception as e:
        logging.error(f"Error reading title.json: {e}")
        return {}

def extract_inner_html(element):
    """
    Extracts the inner HTML of a BeautifulSoup element and applies EXTREME cleaning.
    """
    if not element:
        return ""
    
    content_str = "".join([str(child) for child in element.contents])
    content_str = content_str.replace('\u00a0', ' ').replace('&nbsp;', ' ')
    
    soup = BeautifulSoup(content_str, 'html.parser')
    
    # 2. Strict Whitelist (Safe Mode)
    allowed_tags = ['p', 'br', 'strong', 'b', 'em', 'i', 'u', 'hr', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'ul', 'li']
    
    # Process tags (Bottom-up to avoid unwrap issues)
    tags = soup.find_all(True)
    for tag in reversed(tags):
        if tag.name not in allowed_tags:
            if tag.name == 'img' or tag.name == 'table':
                tag.decompose()
            else:
                tag.unwrap()
            continue
            
        # 3. Strip ALL attributes
        tag.attrs = {}

    # 4. Remove empty tags
    for tag in soup.find_all(True):
        if tag.name not in ['br', 'hr']:
            if not tag.get_text(strip=True) and not tag.find_all():
                tag.decompose()

    return str(soup).strip()

def process_index_html(html_content):
    """Parses index.html and extracts sections and subsections."""
    soup = BeautifulSoup(html_content, 'html.parser')
    for c in soup.find_all('div', class_=re.compile(r'carousel.*')):
        c.decompose()
        
    subsections_list = []
    all_panels = soup.find_all('div', class_='panel')
    top_level_panels = [p for p in all_panels if not p.find_parent('div', class_='panel')]
    
    for panel in top_level_panels:
        title_tag = panel.find('h4', class_='panel-title') or panel.find(class_='panel-heading')
        if not title_tag: continue
        
        section_title = title_tag.get_text(strip=True)
        panel_body_div = panel.find('div', class_='panel-body')
        
        level3_subsections = []
        section_content = ""
        
        if panel_body_div:
            btn_abas = panel_body_div.find(id='btnAbas')
            nested_panels = panel_body_div.find_all('div', class_='panel')
            
            if btn_abas:
                tab_content_container = panel_body_div.find('div', class_='tab-content')
                for a_tag in btn_abas.find_all('a'):
                    tab_title = a_tag.get_text(strip=True)
                    target_id = a_tag.get('href', '').replace('#', '')
                    if not target_id: continue
                    tab_pane = None
                    if tab_content_container:
                        tab_pane = tab_content_container.find(id=target_id)
                    if not tab_pane:
                        tab_pane = panel_body_div.find(id=target_id)
                    if tab_pane:
                        level3_subsections.append({
                            "title": tab_title,
                            "content": extract_inner_html(tab_pane),
                            "color": COLOR_DEFAULT,
                            "subsection": []
                        })
            elif nested_panels:
                for np in nested_panels:
                    if np.find_parent('div', class_='panel') == panel:
                        nt_tag = np.find('h4', class_='panel-title') or np.find(class_='panel-heading')
                        if not nt_tag: continue
                        nt_title = nt_tag.get_text(strip=True)
                        nb_div = np.find('div', class_='panel-body')
                        if nb_div:
                            level3_subsections.append({
                                "title": nt_title,
                                "content": extract_inner_html(nb_div),
                                "color": COLOR_DEFAULT,
                                "subsection": []
                            })
            
            if not level3_subsections:
                section_content = extract_inner_html(panel_body_div)
            else:
                section_content = ""
                
        subsections_list.append({
            "title": section_title,
            "content": section_content,
            "color": COLOR_DEFAULT,
            "subsection": level3_subsections
        })
        
    return subsections_list

def process_file(zip_filename, title_map):
    """Processes a single zip file and returns the JSON payload."""
    zip_path = os.path.join(os.getcwd(), zip_filename)
    basename = os.path.basename(zip_filename)
    filename_no_ext = os.path.splitext(basename)[0]
    title = title_map.get(basename) or title_map.get(filename_no_ext) or filename_no_ext
    
    try:
        with zipfile.ZipFile(zip_path, 'r') as z:
            index_name = None
            for name in z.namelist():
                if name.lower().endswith('index.html'):
                    index_name = name
                    break
            
            if not index_name:
                logging.error(f"No index.html found in {zip_filename}")
                return None
            
            html_content = z.read(index_name).decode('utf-8', errors='ignore')
            level2_subsections = process_index_html(html_content)
            
            # Structure the sections:
            # First section is the Title (Level 1)
            # Subsequent sections are the accordions (Level 2), which can have subsections (Level 3)
            sections = [
                {
                    "title": title,
                    "content": "",
                    "color": COLOR_DEFAULT,
                    "synonyms": "",
                    "summary": "",
                    "subsection": []
                }
            ]
            
            # Add Level 2 sections (which may contain Level 3 subsections)
            sections.extend(level2_subsections)

            payload = {
                "categoryId": CATEGORY_ID,
                "coverId": COVER_ID,
                "status": STATUS,
                "editionMode": EDITION_MODE,
                "shareMobile": SHARE_MOBILE,
                "permissionDownload": PERMISSION_DOWNLOAD,
                "showRelations": SHOW_RELATIONS,
                "surveyId": None,
                "customBeetcoins": None,
                "groupsId": GROUPS_ID,
                "sections": sections
            }
            return payload
    except Exception as e:
        logging.error(f"Error processing {zip_filename}: {e}")
        return None

def main():
    title_map = get_title_map('title.json')
    input_dir = 'html'
    
    if not os.path.exists(input_dir):
        logging.error(f"Input directory '{input_dir}' does not exist.")
        print(f"ERROR: Directory '{input_dir}' not found.")
        return

    zip_files = [f for f in os.listdir(input_dir) 
                 if f.endswith('.zip') and not f.lower().startswith('informativo')]
    zip_files.sort()
    
    logging.info(f"Starting processing of {len(zip_files)} files from '{input_dir}'.")
    
    # 1. Authenticate once
    token = get_auth_token()
    if not token:
        print("FAILED to authenticate. Check api_responses.log for details.")
        return

    # 2. Sequential processing (All files)
    for zip_file in zip_files:
        full_path = os.path.join(input_dir, zip_file)
        logging.info(f"LOG: Processing file {full_path}")
        payload = process_file(full_path, title_map)
        
        if payload:
            print(f"--- Envio de {zip_file} ---")
            payload_json = json.dumps(payload, indent=4, ensure_ascii=False)
            logging.info(f"PAYLOAD for {zip_file}:\n{payload_json}")
            
            # 3. Send to API
            status_code, response_text = create_article(token, payload, zip_file)
            print(f"Status: {status_code} | Zip: {zip_file}")
            
            if status_code and 200 <= status_code < 300:
                logging.info(f"SUCCESS: {zip_file} sent to API. ID: {response_text}")
            else:
                logging.error(f"FAILURE: {zip_file} failed to send. Status: {status_code}")
                # Log payload here again or just rely on the log above
        else:
            logging.error(f"Failed to generate JSON for {zip_file}")
            print(f"FAILED to process {zip_file}")
            
        # Delay to avoid API overload
        time.sleep(0.5)

    logging.info("Processing finished.")

if __name__ == "__main__":
    main()
