# Exportador de Conteúdo: Porto Bank para Beedoo

Este projeto consiste em um script de automação em Python desenvolvido para processar arquivos de documentação técnica (formato `.zip`) e integrá-los automaticamente à plataforma **Beedoo**. O script realiza a extração, sanitização de HTML e o envio estruturado dos dados via API.

## 📋 Pré-requisitos

*   **Python 3.10+**
*   Biblioteca `requests` para chamadas de API.
*   Biblioteca `BeautifulSoup4` para processamento e limpeza de HTML.
*   Biblioteca `python-dotenv` para gestão de variáveis de ambiente.

## 🚀 Instalação e Configuração

1.  **Criar Ambiente Virtual (Recomendado):**
    ```bash
    python3 -m venv .venv
    source .venv/bin/activate
    ```

2.  **Instalar Dependências:**
    ```bash
    pip install requests beautifulsoup4 python-dotenv
    ```

3.  **Configurar Variáveis de Ambiente:**
    Crie um arquivo `.env` na raiz do projeto com base nas seguintes chaves:
    ```env
    BEEDOO_LOGIN_URL=https://api.beedoo.io/beehub/v1/user/accessToken
    BEEDOO_ARTICLE_URL=https://api.beedoo.io/admin/api/v1/wiki/articles
    BEEDOO_CLIENT_ID=seu_client_id
    BEEDOO_CLIENT_SECRET=seu_client_secret

    EXPORT_CATEGORY_ID=ID_DA_CATEGORIA_DESTINO
    EXPORT_GROUPS_ID=[LISTA_DE_GRUPOS]
    ```

## 🔐 Autenticação (Fluxo Customizado)

O processo de autenticação deste script foge do padrão OAuth2 convencional. Ele utiliza um fluxo baseado em **Client Credentials** adaptado para a API Beedoo:

1.  **Solicitação de Token**: É realizada uma requisição `GET` para a URL de login.
2.  **Headers**: O campo `Authorization` utiliza o padrão `Basic` enviando diretamente o `CLIENT_SECRET`.
3.  **Parâmetros**: O `CLIENT_ID` é enviado como um parâmetro de consulta (`query parameter`) na URL.
4.  **Uso**: O token retornado é então utilizado como `Bearer Token` em todas as requisições subsequentes de criação de artigos.

## 🛠️ Funcionamento do Script

### 1. Mapeamento de Títulos (`title.json`)
O script utiliza um arquivo `title.json` que funciona como um "De-Para". Como muitos arquivos `.zip` possuem nomes numéricos ou codificados, este JSON mapeia o nome do arquivo para o título real que será exibido no Beedoo.

### 2. Processamento de Arquivos Localizados em `/html`
O script busca automaticamente por todos os arquivos `.zip` dentro da subpasta `html/`. Arquivos que começam com "informativo" são ignorados por padrão.

### 3. Extração e Sanitização de HTML
A parte mais crítica do processo é a função `extract_inner_html`. Ela opera em um "Modo Seguro":
- **Whitelist**: Apenas tags básicas de formatação são permitidas (`p`, `br`, `strong`, `ul`, `li`, etc.).
- **Limpeza de Atributos**: Todos os atributos (classes CSS, estilos inline, IDs) são removidos para garantir que o conteúdo se adapte ao layout do Beedoo sem quebras.
- **Imagens e Tabelas**: No modo atual, imagens e tabelas são removidas para evitar erros de referência de caminho relativo (404) ou erros `500` na API causados por HTML mal-formado.

### 4. Estruturação em Seções
O script lê o arquivo `index.html` dentro de cada ZIP e identifica a hierarquia de conteúdo (Títulos, Accordions e Subseções), transformando-os no formato de seções exigido pelo Beedoo.

## 🏃 Como Executar

Para iniciar o processamento em lote de todos os arquivos na pasta `html/`:

```bash
python3 process_porto.py
```

## 📊 Logs e Monitoramento

O script gera dois arquivos de log para facilitar a auditoria:
*   **`process_porto.log`**: Registra o fluxo de execução, quais arquivos foram iniciados e se houve falha no processamento lógico.
*   **`api_responses.log`**: Registra detalhadamente cada chamada de API, incluindo os payloads enviados e as respostas brutas retornadas pelo servidor da Beedoo (muito importante para debugar erros de validação).
